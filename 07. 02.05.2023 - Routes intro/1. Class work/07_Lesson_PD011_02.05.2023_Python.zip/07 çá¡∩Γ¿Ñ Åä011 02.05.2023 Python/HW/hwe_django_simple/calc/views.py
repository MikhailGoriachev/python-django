from django.shortcuts import render

# Методы действия - переходы на страницы по маршрутам


# маршрут localhost:p/ или localhost:p/index
def index(request):
    return render(request, 'index.html')


# маршрут localhost:p/euclid
def euclid(request):
    return render(request, 'euclid.html')


# маршрут localhost:p/about
def about(request):
    return render(request, 'about.html')
