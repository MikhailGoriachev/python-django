from django.conf import settings
from django.shortcuts import render


# Главная страница
def index(request):
    # Пришлось задать имя таким образом, поскольку
    # в нескольких приложениях могут быть представления с именем index
    template_path = f"{settings.BASE_DIR}/calc/templates/index.html"

    return render(request, template_path)


# Информация о Евклиде
def euclide(request):
    return render(request, "euclide.html")


# Информация о разработчике
def about(request):
    return render(request, "about.html")
