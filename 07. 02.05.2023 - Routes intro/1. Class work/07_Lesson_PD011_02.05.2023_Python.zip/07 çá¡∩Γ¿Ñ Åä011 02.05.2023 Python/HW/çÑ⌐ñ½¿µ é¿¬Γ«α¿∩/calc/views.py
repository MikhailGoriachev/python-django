from django.shortcuts import render
from django.http import HttpResponse


# маршрут localhost:p/
# маршрут localhost:p/index
def index(request):
    return render(request, 'index.html')


# маршрут localhost:p/euclide
def euclide(request):
    return render(request, 'euclide.html')


# маршрут localhost:p/about
def about(request):
    return render(request, 'about.html')

