from django.shortcuts import render


# маршрут /
# def seasons_with_months(request):
#     return render(request, 'index.html')


# маршрут index/
def index(request):
    return render(request, 'index.html')


#маршрут euclide/
def euclide(request):
    return render(request, 'euclide.html')


# маршрут about/
def about(request):
    return render(request, 'about.html')