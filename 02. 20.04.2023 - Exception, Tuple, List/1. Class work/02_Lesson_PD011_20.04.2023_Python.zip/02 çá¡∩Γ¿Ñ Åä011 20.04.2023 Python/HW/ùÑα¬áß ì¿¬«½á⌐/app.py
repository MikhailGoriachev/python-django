from random import randint
import functions


def proc17():
    for i in range(3):
        a = randint(1, 9)
        b = randint(1, 9)
        c = randint(1, 9)
        print(f'уравнение: {a} * x2 + {b} * x + {c} = 0')
        functions.roots_count(a, b, c)


def proc21():
    lo = -10
    hi = 19
    for i in range(5):
        a = randint(-lo, hi)
        b = randint(-lo, hi)
        functions.sum_range(a, b)


def prog28():
    for i in range(15):
        n = randint(-120, 250)
        print(f'число {n} простое число? - {functions.is_prime(n)}')


if __name__ == '__naim__':
    from main import main

    main()
