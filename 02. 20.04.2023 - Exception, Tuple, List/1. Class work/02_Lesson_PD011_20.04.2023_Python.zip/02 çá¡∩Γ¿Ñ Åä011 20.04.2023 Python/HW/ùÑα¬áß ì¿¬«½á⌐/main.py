import app


def main():
    print('задача Proc17\n')
    app.proc17()
    print('___________________________________________')
    print('задача Proc21\n')
    app.proc21()
    print('___________________________________________')
    app.prog28()


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    main()

