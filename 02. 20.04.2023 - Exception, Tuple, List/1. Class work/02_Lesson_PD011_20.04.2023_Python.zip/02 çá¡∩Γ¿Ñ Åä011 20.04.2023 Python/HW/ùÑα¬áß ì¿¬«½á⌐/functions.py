# функция, определяющая количество корней квадратного уравнения
def roots_count(a, b, c):
    x = b ** 2 - 4 * a * c
    if x > 0:
        print(f'два корня')
    elif x < 0:
        print(f'нет корней')
    else:
        print(f'один корень')


def sum_range(a, b):
    suma = 0
    if a > b:
        print(f'ошибка {a} > {b}')
    else:

        for i in range(a, b):
            suma += i
        print(f'сумма чисел от {a} до {b} = {suma}')


def is_prime(n):
    if n < 2:
        return False
    for i in range(2, int(n ** 0.5 + 1)):
        if n % i == 0:
            return False

    return True


if __name__ == '__main__':
    import main

    main.main()
