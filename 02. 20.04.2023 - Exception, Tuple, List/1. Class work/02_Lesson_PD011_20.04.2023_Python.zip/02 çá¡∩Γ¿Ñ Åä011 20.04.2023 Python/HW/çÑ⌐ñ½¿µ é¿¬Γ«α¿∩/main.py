import app


def main():

    print(f'\n\033[34;1m Proc17. Количество корней квадратного уравнения a·x2 + b·x + c = 0 \033[0m\n')

    app.proc17()

    print(f'\n\033[34;1m Proc21. Сумма всех целых чисел от A до B включительно \033[0m\n')

    app.proc21()

    print(f'\n\033[34;1m Proc28. Является ли N простым числом \033[0m\n')

    app.proc28()

    print()


# end main


# запуск функции main()
if __name__ == '__main__':
    main()
# end if
