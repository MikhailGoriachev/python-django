
import random
import functions


# решение Proc17
def proc17():

    for i in range(0, 3):
        a = random.randrange(-10, 10)
        b = random.randrange(-10, 10)
        c = random.randrange(-10, 10)
        print(f' A = {a}  B = {b}  C = {c}  Количество корней: {functions.roots_count(a, b, c)}')


# решение Proc21
def proc21():

    for i in range(0, 5):
        a = random.randrange(1, 10)
        b = random.randrange(1, 10)
        print(f' Сумма от A = {a} до B = {b}  равна: {functions.sum_range(a, b)}')


# решение Proc28
def proc28():
    for i in range(0, 15):
        n = random.randrange(-120, 250)
        print(f' Число N = {n}   - {functions.is_prime(n)}')


if __name__ == '__main__':
    import main

    main.main()
# end if
