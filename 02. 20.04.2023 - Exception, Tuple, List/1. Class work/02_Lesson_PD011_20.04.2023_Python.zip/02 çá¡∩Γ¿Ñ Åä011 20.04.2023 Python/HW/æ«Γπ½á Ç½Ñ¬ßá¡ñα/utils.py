# region proc17_table

# заголовок таблицы
def print_proc17_header():
    print('┌─────┬─────┬─────┬────────────────────────────┐')
    print('│  A  │  B  │  C  │       Кол-во корней        │')
    print('├─────┼─────┼─────┼────────────────────────────┤')

# строка таблицы
def print_proc17_row(a, b, c, result):
    print(f'│{a:4} │{b:4} │{c:4} │ {result: >26} │')

# подвал таблицы
def print_proc17_footer():
    print('└─────┴─────┴─────┴────────────────────────────┘\n')


# endregion

# region proc21_table

# заголовок таблицы
def print_proc21_header():
    print('┌─────┬─────┬─────────────────┐')
    print('│  A  │  B  │      Сумма      │')
    print('├─────┼─────┼─────────────────┤')

# строка таблицы
def print_proc21_row(a, b, result):
    print(f'│{a:4} │{b:4} │ {result: >15} │')

# подвал таблицы
def print_proc21_footer():
    print('└─────┴─────┴─────────────────┘\n')


# endregion

# region proc28_table

# заголовок таблицы
def print_proc28_header():
    print('┌─────┬───────────────────────────┐')
    print('│  N  │         Результат         │')
    print('├─────┼───────────────────────────┤')

# строка таблицы
def print_proc28_row(n, result):
    if result is True:
        text_result = 'Простое'
    elif result is False:
        text_result = 'Составное'
    else:
        text_result = result

    print(f'│{n:4} │ {text_result: >25} │')


# подвал таблицы
def print_proc28_footer():
    print('└─────┴───────────────────────────┘\n')

# endregion
