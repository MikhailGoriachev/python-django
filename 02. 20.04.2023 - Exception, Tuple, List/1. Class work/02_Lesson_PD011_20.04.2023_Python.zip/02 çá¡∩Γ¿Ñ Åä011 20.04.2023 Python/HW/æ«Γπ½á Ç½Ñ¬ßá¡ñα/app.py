import random
import functions
import utils

'''
Proc17. Описать функцию roots_count(a, b, c),
определяющую количество корней квадратного уравнения
a•x2 + b•x + c = 0 (a, b, c – параметры).
Если коэффициент a равен нулю, то сообщите об ошибке.
С помощью функции roots_count() найти количество корней
для каждого из трех квадратных уравнений с данными коэффициентами.
Коэффициенты a, b, c формировать генератором случайных чисел.
Количество корней определять по значению дискриминанта: d = b2 − 4•a•c.
'''


def proc17():
    # значения для генерации
    min_value = -10  # минимальное значение
    max_value = 10  # максимальное значение

    # кол-во итераций
    count_iteration = 3

    print('Proc17')

    # заголовок таблицы
    utils.print_proc17_header()

    for i in range(0, count_iteration):
        # генерация случайных значений
        a = random.randint(min_value, max_value)
        b = random.randint(min_value, max_value)
        c = random.randint(min_value, max_value)

        # результат
        result = functions.roots_count(a, b, c)

        # вывод результата
        utils.print_proc17_row(a, b, c, result)

    # подвал таблицы
    utils.print_proc17_footer()


'''
Proc21. Описать функцию sum_range(a, b), находящую сумму всех
целых чисел от A до B включительно (a и b – целые).
Если a > b, то сообщите об ошибке.
С помощью функции sum_range() найти суммы для пяти пар случайных чисел.
'''


def proc21():
    # значения для генерации
    min_value = -10  # минимальное значение
    max_value = 10  # максимальное значение

    # кол-во итераций
    count_iteration = 5

    print('Proc21')

    utils.print_proc21_header()
    for i in range(0, count_iteration):
        # генерация случайных значений
        a = random.randint(min_value, max_value)
        b = random.randint(min_value, max_value)

        # результат обработки
        result = functions.sum_range(a, b)

        # вывод строки таблицы
        utils.print_proc21_row(a, b, result)

    # подвал таблицы
    utils.print_proc21_footer()


def proc28():
    # значения для генерации
    min_value = 120  # минимальное значение
    max_value = 250  # максимальное значение

    # кол-во итераций
    count_iteration = 15

    # кол-во простых чисел
    count_prime_value = 0

    print('Proc28')

    utils.print_proc28_header()
    for i in range(0, count_iteration):
        # генерация случайного значения
        n = random.randint(min_value, max_value)

        # условие для генерации ошибки
        if 120 <= n <= 130:
            n = 0

        # результат обработки
        result = functions.is_prime(n)

        # увеличить счетчик простых чисел
        if result is True:
            count_prime_value += 1

        # вывод строки таблицы
        utils.print_proc28_row(n, result)

    # подвал таблицы
    utils.print_proc28_footer()

    # вывод результат
    print(f'Простых чисел: {count_prime_value}')
