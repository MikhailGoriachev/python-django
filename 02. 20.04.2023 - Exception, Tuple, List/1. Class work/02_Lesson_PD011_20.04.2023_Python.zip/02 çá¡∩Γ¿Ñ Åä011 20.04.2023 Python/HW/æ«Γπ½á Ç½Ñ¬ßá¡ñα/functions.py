import math


# определяющую количество корней квадратного уравнения a•x2 + b•x + c = 0
def roots_count(a, b, c):
    if a == 0:
        return 'Коэффициент A равен 0'

    d = b ** 2 - 4 * a * c

    if d < 0:
        return 'Нет действительных корней'

    return 2 if d > 0 else 1


# end roots_count

# находящую сумму всех целых чисел от A до B включительно (a и b – целые)
def sum_range(a, b):
    if a > b:
        return 'A больше B'

    total_sum = 0
    for i in range(a, b + 1):
        total_sum += i

    return total_sum


# end sum_range

# возвращающую True, если параметр n является простым числом,
# и False в противном случае
def is_prime(n):
    if n <= 1:
        return f'N меньше или равно 1'

    for i in range(2, int(math.sqrt(n))):
        if n % i == 0:
            return False

    return True
