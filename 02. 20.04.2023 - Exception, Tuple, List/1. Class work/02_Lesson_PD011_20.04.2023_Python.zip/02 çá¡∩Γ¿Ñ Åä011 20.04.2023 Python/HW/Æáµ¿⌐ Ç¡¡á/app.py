from random import randint
import functions


# С помощью функции sum_range() найти суммы для пяти пар случайных чисел.
def do_proc21():
    for pair in range(5):
        a = randint(1, 10)
        b = randint(1, 10)
        acc = functions.sum_range(a, b)
        if acc is not None:
            print(f'Proc21: sum_range({a},{b}) = {acc}')


# C помощью функции is_prime() найти количество простых чисел среди 15 случайных чисел в диапазоне от -120 до 250.
def do_proc28():
    for pair in range(15):
        num = randint(-120, 250)
        flag = functions.is_prime(num)

        if flag is not None:
            if flag:
                print(f'Proc28: {num} -> простое')

            if not flag:
                print(f'Proc28: {num} -> составное')


# С помощью функции roots_count() найти количество
# корней для каждого из трех квадратных уравнений с данными коэффициентами.
# Коэффициенты a, b, c формировать генератором случайных чисел.
def do_proc17():
    for pair in range(3):
        a = randint(0, 1)
        b = randint(5, 8)
        c = randint(3, 8)
        print(f'Proc17: коэффициенты квадратного уравнения: a = {a}, b = {b}, c = {c}')
        count = functions.roots_count(a, b, c)
        if count is not None:
            print(f'Proc17: количество корней: {count}')


if __name__ == '__main__':
    import main

    main.main()
