import app


def main():
    print(f'{__name__}: начало работы\n')
    app.do_proc17()
    print()
    app.do_proc21()
    print()
    app.do_proc28()
    print(f'\n{__name__}: конец работы')


if __name__ == '__main__':
    main()
