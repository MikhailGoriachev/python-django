# Описать функцию roots_count(a, b, c),
# определяющую количество корней квадратного уравнения a·x2 + b·x + c = 0 (a, b, c – параметры).
# Если коэффициент a равен нулю, то выбрасывать исключения.
# d = b2 − 4·a·c.
def roots_count(a, b, c):
    if a == 0:
        out_red("Proc17. Ошибка: a = 0")
        return

    d = b ** 2 - 4 * a * c
    if d < 0:
        return 0

    if d == 0:
        return 1

    if d > 0:
        return 2


# Описать функцию sum_range(a, b), находящую сумму всех целых чисел от A до B включительно (a и b – целые).
# Если a > b, то выбрасывать исключение.

def sum_range(a, b):
    if a > b:
        out_red(f'Proc21.Ошибка: a > b')
        return

    b += 1
    acc = 0

    while a < b:
        acc += a
        a += 1

    return acc + b


# Описать функцию is_prime(n), возвращающую True, если параметр n является простым числом, и False в противном случае
# Если параметр n <= 1 то выбрасывать исключение.
def is_prime(n):
    if n <= 1:
        out_red(f'Proc28.Ошибка: n <= 1')
        return

    for i in range(2, (n // 2) + 1):
        if n % i == 0:
            return False

    return True


# меняем цвет на красный
def out_red(text):
    print(f'\033[31m{text}\033[0m')


if __name__ == '__main__':
    import main

    main.main()
