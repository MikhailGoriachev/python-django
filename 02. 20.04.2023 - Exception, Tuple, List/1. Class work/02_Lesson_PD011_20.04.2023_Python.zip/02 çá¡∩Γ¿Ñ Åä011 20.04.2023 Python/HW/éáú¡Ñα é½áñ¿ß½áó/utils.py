import random
import main

if __name__ == '__main__':
    main.main()


def get_random(lo, hi):
    return random.randrange(lo, hi)

# end get_random
