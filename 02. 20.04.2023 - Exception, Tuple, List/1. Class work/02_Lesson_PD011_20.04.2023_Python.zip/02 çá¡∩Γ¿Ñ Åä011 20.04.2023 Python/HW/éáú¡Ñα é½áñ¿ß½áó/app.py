from math import sqrt

import main
import console_colors

if __name__ == '__main__':
    main.main()


# Опеделение количества корней квадратного уравнени
def roots_count(a, b, c):
    if a == 0:
        raise Exception(f"Коэффициент a задан некорректно!")

    d = b ** 2 - 4 * a * c

    if d > 0:
        return 2
    elif d == 0:
        return 1
    else:
        return 0

# end roots_count


# Нахождение суммы двух чисел
def sum_range(a, b):

    if a > b:
        raise Exception(f"a не может быть больше b! Задан диапазон: {console_colors.blue_25} {a} - {b}  \033[0m")

    result = a

    for i in range(a+1, b+1):
        result += i

    return result

# end sum_range


# Опрделение является ли переданное числов простым
def is_prime(n):

    if n <= 1:
        raise Exception(f"Число n не может быть <= 1! Задано: {console_colors.blue_25} {n}  \033[0m")

    for i in range(2, int(sqrt(n)+1)):

        if n % i == 0:
            return False

    return True

# end is_prime

