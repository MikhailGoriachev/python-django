import functions
import console_colors


def choose_task(task_number):
    task_number = int(task_number)

    if task_number == 0:
        exit(0)

    # Запуск задачи 1
    if task_number == 1:
        functions.proc_17()

    # Запуск задачи 2
    elif task_number == 2:
        functions.proc_21()

    # Запуск задачи 3
    elif task_number == 3:
        functions.proc_28()

    else:
        print(f"\n\n{console_colors.color_info}Номер задачи ведён неверно!{console_colors.terminate}"
              f" Введите значение в диапазоне 1 - 3\n")

# end choose_task

def main():

    while True:

        try:
            choose_task(input(f"\nВведите номер задачи ("
                              f"{console_colors.color_info}1, 2 или 3{console_colors.terminate}. для выхода введите 0): "))

        except Exception as e:
            print(f"\n\nПри выполнении операции упало исключение: "
                  f"{console_colors.brightRed} {e} {console_colors.terminate} \n")

    # end while

# end main


if __name__ == '__main__':
    main()
