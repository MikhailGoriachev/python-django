# class ConsoleColors:

terminate = "\033[0m"

brightRed = "\033[38;5;255m\033[48;5;124m"

white_green = "\033[38;5;16m\033[48;5;36m"

lightMagenta = "\033[48;5;14m\033[38;5;16m"

blue_25 = "\033[48;5;25m"

color_info = "\033[48;5;12m\033[38;5;16m"

