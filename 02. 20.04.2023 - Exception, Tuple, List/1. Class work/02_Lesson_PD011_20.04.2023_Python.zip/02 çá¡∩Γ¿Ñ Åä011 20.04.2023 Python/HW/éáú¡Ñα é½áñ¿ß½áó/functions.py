import main
import app
import console_colors

from utils import get_random


if __name__ == '__main__':
    main.main()


def proc_17():

    for i in range(3):
        lo = -5
        hi = 20

        a = get_random(lo, hi)
        b = get_random(lo, hi)
        c = get_random(lo, hi)

        roots = app.roots_count(a, b, c)

        print(f"\n{i+1}. Уравнения с коэффициентами {a}, {b}, {c}. "
              f"Количество корней: {console_colors.white_green} {roots} "
              f"{console_colors.terminate}")

    # end for


# end proc_17


def proc_21():

    for i in range(5):

        a = get_random(5, 20)
        b = get_random(15, 30)

        summ = app.sum_range(a, b)

        print(f"\n{i+1}. Диапазон {a} - {b}. Сумма из диапазона: "
              f"{console_colors.white_green} {summ} \033[0m")

    # end for

# end proc_21


def proc_28():

    for i in range(15):

        n = get_random(-120, 250)
        is_prime = app.is_prime(n)

        print(f"\n{i+1}. Число {console_colors.blue_25} {n}"
              f" \033[0m является простым: {console_colors.white_green} "
              f"{is_prime} \033[0m")

    # end for

# end proc_28

