# кортежи в Python

import tuples


def main():
    '''
    print('\nДемонстрация работы с кортежами в Python 3\n')
    tuples.demo_tuples()

    # демонстрация перебора полей кортежа
    tuples.iterate_tuples()
    print()

    # демонстрация поиска полей в кортеже
    tuples.find_item()
    print()
    '''

    # демонстрация сложных кортежей
    tuples.complex_tuples()
    print()
# end main


# вызов функции main() при старте этого модуля
if __name__ == '__main__':
    main()
# end if
