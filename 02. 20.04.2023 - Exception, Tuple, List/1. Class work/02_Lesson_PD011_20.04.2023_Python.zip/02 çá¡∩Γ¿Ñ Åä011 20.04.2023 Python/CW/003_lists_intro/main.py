# Коллекции значений в Python, введение в списки,list, []
import lists


def main():
    lists.demo_lists()

if __name__ == '__main__':
    main()
# end if
