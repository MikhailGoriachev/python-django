﻿import app


def main():
    app.task01_run()
    app.task02_run()


if __name__ == '__main__':
    main()
