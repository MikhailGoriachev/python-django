import random
import utils


# Task1. Обработка кортежей. Описать функцию rect_ps(x1, y1, x2, y2),
# вычисляющую периметр и площадь прямоугольника со сторонами,
# параллельными осям координат, по координатам (x1, y1), (x2, y2)
# его противоположных вершин (стороны вычисляются как a = abs(x2 - x1),
# b = abs(y2 – y1)). Функция возвращает кортеж с периметром и площадью.
# С помощью этой функции найти периметры и площади трех прямоугольников
# с данными противоположными вершинами.
def task01(count):
    # диапазон генерации
    MIN_TASK01 = -10
    MAX_TASK01 = 10

    # список для хранения кортежей результатов
    results = []

    # формирование списка кортежей результатов
    for i in range(0, count):
        # генерация случайных координат
        x1, y1, x2, y2 = random.uniform(MIN_TASK01, MAX_TASK01), random.uniform(MIN_TASK01, MAX_TASK01), random.uniform(
            MIN_TASK01, MAX_TASK01), random.uniform(MIN_TASK01, MAX_TASK01)

        # получить кортеж с периметром и площадью
        perimeter, area = rect_ps(x1, y1, x2, y2)

        # добавить в список результатов
        results.append((x1, y1, x2, y2, perimeter, area))
    # for i

    # вывод результата
    print('\nЗадача 1.\n'
          'Описать функцию rect_ps(x1, y1, x2, y2), вычисляющую периметр и\n'
          'площадь прямоугольника со сторонами, параллельными осям координат,\n'
          'по координатам (x1, y1), (x2, y2) его противоположных вершин (\n'
          'стороны вычисляются как a = abs(x2 - x1), b = abs(y2 – y1)).\n'
          'Функция возвращает кортеж с периметром и площадью. С помощью этой\n'
          'функции найти периметры и площади трех прямоугольников с\n'
          'данными противоположными вершинами')

    # номер строки таблицы
    row_number = 1

    # вывод шапки таблицы
    print(utils.get_task01_header())

    # вывод строки таблицы
    for result in results:
        print(utils.get_task01_row(row_number, result[0], result[1], result[2], result[3], result[4], result[5]))
        row_number += 1
    # for

    # вывод подвала таблицы
    print(utils.get_task01_footer())

# task01

# вычисление периметра и площади прямоугольника
def rect_ps(x1, y1, x2, y2):
    a = abs(x2 - x1)
    b = abs(y2 - y1)

    perimeter = calculate_perimeter(a, b)
    area = calculate_area(a, b)

    return perimeter, area


# rect_ps

# вычисление периметра прямоугольника
def calculate_perimeter(a, b):
    return 2 * (a + b)


# calculate_perimeter

# вычисление площади прямоугольника
def calculate_area(a, b):
    return a * b


# calculate_area

# значения для генерации элементов списка
MIN_VALUE_TASK2 = -20
MAX_VALUE_TASK2 = 20

# значения для генерации размера списка
MIN_SIZE_TASK2 = 5
MAX_SIZE_TASK2 = 10


# Сформируйте список list_c. Увеличить все нечетные числа,
# содержащиеся в списке, на исходное значение последнего нечетного числа.
# Если нечетные числа в списке отсутствуют, то оставить список без изменений.
# Вывести упорядоченную по убыванию копию списка
def increase_odd_elements_on_last_odd_with_sort_desc():
    print('\nЗадача 2.'
          'Пункт 1.\n\n'
          'Увеличить все нечетные числа, содержащиеся в списке,\n'
          'на исходное значение последнего нечетного числа.\n'
          'Если нечетные числа в списке отсутствуют, то оставить список без изменений.\n'
          'Вывести упорядоченную по убыванию копию списка\n')

    list_c = []

    # заполнение списка случайными значениями
    utils.fill_list(list_c, random.randint(MIN_SIZE_TASK2, MAX_SIZE_TASK2), MIN_VALUE_TASK2, MAX_VALUE_TASK2)

    # вывод исходного списка для обработки
    print(utils.get_list_str('Исходный список', list_c))

    # поиск последнего нечетного числа
    odd_element = utils.get_last_odd_element(list_c)

    # нечетное число найдено
    if odd_element is not None:
        # увеличить все нечетные числа на значение найденного числа
        for i in range(0, len(list_c)):
            if list_c[i] % 2 == 1:
                list_c[i] += odd_element

    # копия списка отсортированная по убыванию
    sorted_list = sorted(list_c, reverse=True)

    # вывод результата
    print(utils.get_list_str('Обработанный список', sorted_list))

# increase_odd_elements_on_last_odd_with_sort_desc


# Сформируйте список list_c. Возвести в квадрат все его
# локальные минимумы (то есть числа, меньшие своих соседей)
def square_local_minimum():
    print('\nЗадача 2. Пункт 2.\n\n'
          'Возвести в квадрат все локальные минимумы(то есть числа, меньшие своих соседей)\n')

    list_c = []

    # заполнение списка случайными значениями
    utils.fill_list(list_c, random.randint(MIN_SIZE_TASK2, MAX_SIZE_TASK2), MIN_VALUE_TASK2, MAX_VALUE_TASK2)

    # вывод исходного списка для обработки
    print(utils.get_list_str('Исходный список', list_c))

    # если текущий элемент меньше своих соседей - возвести в квадрат
    for i in range(1, len(list_c) - 1):
        # if list_c[i] < list_c[i - 1] and list_c[i] < list_c[i + 1]:
        if list_c[i - 1] > list_c[i] < list_c[i + 1]:
            list_c[i] *= list_c[i]

    # вывод результата
    print(utils.get_list_str('Обработанный список', list_c))

# square_local_minimum

# Сформируйте список list_c.
# Удалить из списка все одинаковые элементы, оставив их первые вхождения
def remove_similar_elements_except_first():
    print('\nЗадача 2. Пункт 3.\n\n'
          'Удалить из списка все одинаковые элементы, оставив их первые вхождения\n')

    list_c = []

    # заполнение списка случайными значениями
    utils.fill_list(list_c, random.randint(MIN_SIZE_TASK2, MAX_SIZE_TASK2), MIN_VALUE_TASK2, MAX_VALUE_TASK2)

    # вывод исходного списка для обработки
    print(utils.get_list_str('Исходный список', list_c))

    list_c.reverse()

    for i in range(len(list_c) - 1, -1, -1):
        value = list_c[i]
        if list_c.count(value) > 1:
            list_c.remove(value)

    list_c.reverse()

    # вывод результата
    print(utils.get_list_str('Обработанный список', list_c))


# remove_similar_elements_except_first

# Сформируйте список list_c.
# Вставить элемент с нулевым значением перед минимальным и после максимального элемента списка
def insert_zero():

    print('\nЗадача 2. Пункт 4.\n\n'
          'Вставить элемент с нулевым значением перед минимальным и после максимального элемента списка\n')

    list_c = []

    # заполнение списка случайными значениями
    utils.fill_list(list_c, random.randint(MIN_SIZE_TASK2, MAX_SIZE_TASK2), MIN_VALUE_TASK2, MAX_VALUE_TASK2)

    # вывод исходного списка для обработки
    print(utils.get_list_str('Исходный список', list_c))

    # элемент для вставки
    insert_value = 0

    # индекс минимального значения
    index_min_value = list_c.index(min(list_c))
    # вставка перед мин-ым элементом
    list_c.insert(index_min_value, insert_value)

    # индекс максимального значения
    index_max_value = list_c.index(max(list_c))
    # вставка после максимального элемента
    list_c.insert(index_max_value + 1, insert_value)

    # вывод результата
    print(utils.get_list_str('Обработанный список', list_c))

# insert_zero
