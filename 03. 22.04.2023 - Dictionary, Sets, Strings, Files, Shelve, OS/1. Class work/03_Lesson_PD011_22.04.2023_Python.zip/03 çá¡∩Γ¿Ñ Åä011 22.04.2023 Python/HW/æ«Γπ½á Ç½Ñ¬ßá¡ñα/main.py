import app
import utils
COUNT_EXEC_TASK01 = 3


def main():
    # текст меню
    # menu = utils.get_menu()

    while True:
        try:
            # получить ввод пункта меню от пользователя
            cmd = input(utils.menu)

            # вызов решения задания по вводу пользователя
            if cmd == '1':
                app.task01(COUNT_EXEC_TASK01)
            elif cmd == '2':
                app.increase_odd_elements_on_last_odd_with_sort_desc()
            elif cmd == '3':
                app.square_local_minimum()
            elif cmd == '4':
                app.remove_similar_elements_except_first()
            elif cmd == '5':
                app.insert_zero()
            elif cmd == '0':
                return
            else:
                raise Exception('\n\t\t\t\t~~~~~~~~ Нет такого пункта меню ~~~~~~~~\n')
        except Exception as ex:
            print(ex)


if __name__ == '__main__':
    main()
