# вспомогательные функции задания
import math
import random
import main

# region Вспомогательные функции задачи 1

# Функция  rect_ps(x1, y1, x2, y2),  вычисляющую  периметр  и  площадь прямоугольника
# со  сторонами,  параллельными  осям координат, по координатам (x1, y1), (x2, y2)
# его  противоположных  вершин  (стороны  вычисляются  как a = abs(x2 - x1),
# b = abs(y2 – y1)).  Функция возвращает кортеж  с периметром и  площадью.
def rect_ps(x1, y1, x2, y2):
    a = math.fabs(x2 - x1)     # горизонтальная сторона
    b = math.fabs(y2 - y1)     # вертикальная сторона

    p = 2 * (a + b)            # периметр прямоугольника
    s = a * b                  # площадь прямоугольника
    return p, s                # возвращаем площадь и периметр в кортеже
# end rect_ps

# endregion


#region Вспомогательные функции задачи 2
# формирование списка из n случайных чисел
# с диапазоном  значений от lo до hi
def generate_list(n, lo, hi):
    list_data = []
    for i in range(n):
        list_data.append(random.randint(lo, hi))

    return list_data
# end generate_list


# вывод list_data в одну строку с заголовком title
def show(list_data, title):
    str_ = title

    # доступ только по чтению - итератор
    # list - итерируемый объект
    for item in list_data:
        str_ += f'{item:5} '

    # вывод сформированной строки - списка данных
    print(str_)
# end show


# вывод list в одну строку с заголовком title, цветом выделяем элементы
# с нечетными индексами
def show_odd_index(data, title):
    str_ = title + '\t'

    # перебираем список
    for i in range(0, len(data)):
        # формирование цвета для элементов с нечетными индексами
        # присвоить color значение '34;1' если условие   % 2 != 0 истинно, иначе
        # присвоить color значение '30'
        color = '34;1' if i % 2 != 0 else '30'

        str_ += f'\033[{color}m{data[i]:5}\033[0m '

    # вывод сформированной строки - списка данных
    print(str_)
# end show_odd_index


# вывод list в одну строку с заголовком title, цветом выделяем элементы
# индексы которых хранятся в списке indexes
def show_indexes(data, title, indexes):
    str_ = title + '\t'

    # вывод списка
    for i in range(0, len(data)):
        # формирование цвета для элементов, чьи индексы хранятся в списке indexes
        color = '30'
        if i in indexes: color = '34;1'

        str_ += f'\033[{color}m{data[i]:5}\033[0m '

    # вывод сформированной строки - списка данных
    print(str_)
# end show_indexes


# вывод list в одну строку с заголовком title, цветом выделяем элементы
# значения которых хранятся в списке indexes
def show_values(data, title, values):
    str_ = title + '\t'

    # вывод списка
    for i in range(0, len(data)):
        # формирование цвета для элементов, чьи индексы хранятся в списке indexes
        color = '30'
        if data[i] in values: color = '34;1'

        str_ += f'\033[{color}m{data[i]:5}\033[0m '

    # вывод сформированной строки - списка данных
    print(str_)
# end show_values


# проверка элемента с индексом index на локальный минимум
def is_locmin(data, index):
    # локальным минимумом не может быть первый и последний элементы списка
    if index == 0 or index == len(data)-1: return False

    # проверяем элемент списка на локальный минимум
    return data[index-1] > data[index] < data[index+1]
# end is_locmin


# Заполнение списка случайными числами
# доступ к элементам списка через индексироване - доступ и по чтению
# и по записи
def fill(list_data, low, high):
    # заменяем значения списка на случайные
    for i in range(0, len(list_data)):
        list_data[i] = random.randint(low, high + 1)
# end fill


# из списка list_data удалить элемент со значением value, начиная
# с индекса index
def remove(list_data, value, index):
    # проходим по списку от конца к индексу index включительно
    # удаляем все элементы, равные value
    i = len(list_data)-1
    while i >= index:
        # удаление элемента списка, значение которого равно value
        if list_data[i] == value:
            list_data.pop(i)
        i -= 1
# end remove
#endregion


# запуск главной функции приложения
if __name__ == '__main__':
    main.main()
# end if
