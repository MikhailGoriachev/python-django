import main
import utils
import console_colors

if __name__ == '__main__':
    main.main()


# Вычисление площади и периметра прямоугольника
def rect_ps(x1, y1, x2, y2):
    a = abs(x2 - x1)
    b = abs(y2 - y1)

    p = 2 * (a + b)
    s = a * b

    return p, s

# end rect_ps


# Диапазон для генерации списка
LIST_VALUE_LO = -20
LIST_VALUE_HI = 20


# Увеличить все нечетные числа, содержащиеся в списке,
# на исходное значение последнего нечетного числа

def increase_odd():
    # Magic Number detected :(
    list_c = utils.generate_int_list(10, LIST_VALUE_LO, LIST_VALUE_HI)

    # Вывести список и задание + получить индекс последнего четного элемента

    task = "Подзадача 1. Увеличить все нечетные числа, содержащиеся в списке, " \
           "на исходное значение последнего нечетного числа\n\n"

    print(f'\n{task}Исходный список значений в диапазоне {LIST_VALUE_LO}, {LIST_VALUE_HI}\n')

    # God loop detect :( :( :( "Божественный цикл" обнаружен
    list_str = ""

    last_odd_index = 0

    for i in range(0, len(list_c)):

        line_break = "\n\n" if (i+1) % 15 == 0 and (i + 1) != 0 and i < len(list_c) else ""

        # Вывод с выделением нечентныйх чисел
        if list_c[i] % 2 != 0:

            last_odd_index = i
            list_str += f" {console_colors.blue_back_highlight} {list_c[i]: ^3} {console_colors.terminate}{line_break}"
        else:
            list_str += f" {console_colors.light_magenta} {list_c[i]: ^3} {console_colors.terminate}{line_break}"

    # end for

    print(list_str)

    # Увеличить нечетные числа
    for i in range(0, len(list_c)):

        # Если число нечетное и при этом не последнее нечетное
        if list_c[i] % 2 != 0 and i != last_odd_index:
            list_c[i] += list_c[last_odd_index]

    # end for

    list_c_sorted = sorted(list_c)
    list_c_sorted.reverse()

    print(f'\nИзмененный и отсортированный список значений\n'
          f'Последнее нечетное число: {console_colors.color_info} {list_c[last_odd_index]} {console_colors.terminate}\n')

    utils.show_list(list_c_sorted)

    # Ожидать нажатия клавиши
    utils.wait_for_enter_press()

# increase_odd


# Возвести в квадрат все локальные минимумы списка
def square_local_min():
    list_c = utils.generate_int_list(15, LIST_VALUE_LO, LIST_VALUE_HI)

    # Вывести список и задание
    task = "\nПодзадача 2.Возвести в квадрат все локальные минимумы списка\n"

    print(f'{task} \nИсходный список значений в диапазоне {LIST_VALUE_LO}, {LIST_VALUE_HI}\n')

    utils.show_list(list_c)

    # Создание копии списка для коррекной обработки по заданию
    list_copy = list_c.copy()

    # Изменить локальные минимумы
    for i in range(1, len(list_c)-1):

        # Вычисление локальных минимумов для остальных элементов
        if list_c[i - 1] > list_c[i] < list_c[i + 1]:
            list_copy[i] **= 2

    # end for

    print(f'\nИзмененный список значений\n')

    list_str = ""

    # Вывод с выделением измененных значений
    for i in range(0, len(list_copy)):

        if list_copy[i] != list_c[i]:
            list_str += f" {console_colors.blue_back_highlight} {list_copy[i]: ^3} {console_colors.terminate} "
        else:
            list_str += f" {console_colors.light_magenta} {list_copy[i]: ^3} {console_colors.terminate} "

    # end for

    print(list_str)

    # Ожидать нажатия клавиши
    utils.wait_for_enter_press()

# square_local_min


# Удалить из списка все одинаковые элементы, оставив их первые вхождения
def delete_duplicates():
    list_c = utils.generate_int_list(20, LIST_VALUE_LO, LIST_VALUE_HI)

    # Вывести список и задание
    task = "\nПодзадача 3. Удалить из списка все одинаковые элементы, " \
           "оставив их первые вхождения\n"

    print(f'{task} \nИсходный список значений в диапазоне {LIST_VALUE_LO}, {LIST_VALUE_HI}\n')

    utils.show_list_subtask_3(list_c)

    # Список для последующего выделения первых вхождений
    duplicates = []

    index = 0
    # Удалить повторющиеся значения
    for item in list_c:

        index += 1

        if list_c.count(item) == 1:
            continue

        duplicates.append(item)

        for j in range(0, list_c.count(item)):
            list_c.remove(item)

        # Вернуть первое вхождение
        list_c.insert(index - 1, item)

    # end for

    print(f'\nИзмененный список значений\n')

    list_str = ""

    # Вывод с выделением первых вхождений ранее повторяющихся элементов
    for i in range(0, len(list_c)):

        # Переносить строку каждые 15 элементов
        line_break = "\n\n" if (i + 1) % 15 == 0 else ""

        if list_c[i] in duplicates:
            list_str += f" {console_colors.blue_back_highlight} {list_c[i]: ^3} {console_colors.terminate}{line_break}"
        else:
            list_str += f" {console_colors.light_magenta} {list_c[i]: ^3} {console_colors.terminate}{line_break}"

    # end for

    print(list_str)

    # Ожидать нажатия клавиши
    utils.wait_for_enter_press()

# delete_duplicates


# Вставить элемент с нулевым значением перед минимальным и
# после максимального элемента списка
def insert_before_min_max():
    list_c = utils.generate_int_list(20, LIST_VALUE_LO, LIST_VALUE_HI)

    # Вывести список и задание

    task = "\nПодзадача 4. Вставить элемент с нулевым значением перед минимальным и " \
           "после максимального элемента списка\n"

    print(f'{task} \nИсходный список значений в диапазоне {LIST_VALUE_LO}, {LIST_VALUE_HI}\n'
          f'Минимальный элемент выделен: {console_colors.green_back_highlight}  {console_colors.terminate}. '
          f'Максимальный выделен: {console_colors.blue_back_highlight}  {console_colors.terminate}\n')

    min_index = utils.index_min(list_c)
    max_index = utils.index_max(list_c)

    utils.highlight_min_max(list_c, min_index, max_index)

    list_c.insert(min_index, 0)
    list_c.insert(utils.index_max(list_c)+1, 0)

    print(f'\nИзмененный список значений\n')

    list_str = ""

    # Определить новые индексы мин и макс. элелментов после вставки
    min_index = utils.index_min(list_c)
    max_index = utils.index_max(list_c)

    utils.highlight_min_max(list_c, min_index, max_index)

    print(list_str)

    # Ожидать нажатия клавиши
    utils.wait_for_enter_press()

# insert_before_min_max
