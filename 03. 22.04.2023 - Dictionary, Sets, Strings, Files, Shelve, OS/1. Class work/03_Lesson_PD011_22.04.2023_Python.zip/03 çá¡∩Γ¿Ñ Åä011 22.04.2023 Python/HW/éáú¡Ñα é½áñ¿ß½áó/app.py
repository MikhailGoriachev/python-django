import main
import console_colors
import functions
import utils


import msvcrt

if __name__ == '__main__':
    main.main()


# Задача 1 - работа с кортежем
def task01():

    RECTANGLES_COUNT = 3

    lo = -10
    hi = 10

    print(f"\nВычисление периметра и площади прямоугольника\n{utils.rectangle_header}")

    for i in range(RECTANGLES_COUNT):

        x1 = utils.get_random_float(lo, hi)
        y1 = utils.get_random_float(lo, hi)
        x2 = utils.get_random_float(lo, hi)
        y2 = utils.get_random_float(lo, hi)

        p, s = functions.rect_ps(x1, y1, x2, y2)

        print(utils.to_table_row_rectangle((i+1, x1, y1, x2, y2, p, s)))

    # end for

    print(utils.rectangle_footer)

    # Ожидать нажатия клавиши
    utils.wait_for_enter_press()
# end roots_count


def choose_task(task_number):
    if task_number == '0':
        return False

    # Увеличить все нечетные числа, содержащиеся в списке,
    # на исходное значение последнего нечетного числа

    if task_number == "1":
        functions.increase_odd()

    # Запуск задачи 2
    elif task_number == "2":
        functions.square_local_min()

    # Запуск задачи 3
    elif task_number == "3":
        functions.delete_duplicates()

    # Запуск задачи 4
    elif task_number == "4":
        functions.insert_before_min_max()

    else:
        raise IOError(f"\n\n{console_colors.color_info}Номер задачи ведён неверно!{console_colors.terminate} "
                      f"Введите значение в диапазоне 1 - 4\n")

    return True


# end choose_task

# Задача 2 - работа со списком
def task02():
    while True:

        try:
            tasks = "\n1 - подзадача 1. Увеличить все нечетные числа, содержащиеся в списке," \
                    "на исходное значение последнего нечетного числа" \
                    "\n2 - подзадача 2. Возвести в квадрат все локальные минимумы списка" \
                    "\n3 - подзадача 3. Удалить из списка все одинаковые элементы, оставив их первые вхождения" \
                    "\n4 - подзадача 4. Вставить элемент с нулевым значением перед минимальным и " \
                    "после максимального элемента списка"\
                    "\n0 - выход\n"

            result = choose_task(input(f"{tasks}\nВведите номер подзадачи задачи для работы со списком: "))

            if not result:
                return

        except IOError as e:
            print(e)

    # end while

# end task02
