import app
import console_colors


def choose_task(task_number):
    task_number = int(task_number)

    if task_number == 0:
        exit(0)

    # Запуск задачи 1
    if task_number == 1:
        app.task01()

    # Запуск задачи 2
    elif task_number == 2:
        app.task02()

    else:
        print(f"\n\n{console_colors.color_info}Номер задачи ведён неверно!{console_colors.terminate} Введите значение в диапазоне 1 - 2\n")

# end choose_task

def main():

    while True:

        try:
            tasks = "1 - задача 1 " \
                    "\n2 - задача 2" \
                    "\n0 - выход\n"

            choose_task(input(f"\n{tasks}\nВведите номер задачи: "))

        except Exception as e:
            print(f"\n\nПри выполнении операции упало исключение: {console_colors.bright_red} {e} {console_colors.terminate} \n")

    # end while

# end main


if __name__ == '__main__':
    main()
