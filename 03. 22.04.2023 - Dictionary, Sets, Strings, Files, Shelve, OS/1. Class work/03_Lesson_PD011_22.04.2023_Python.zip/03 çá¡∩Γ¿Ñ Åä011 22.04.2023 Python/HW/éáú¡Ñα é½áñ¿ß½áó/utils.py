import random
import main
import console_colors

if __name__ == '__main__':
    main.main()


def get_random_float(lo, hi):

    if lo > hi:
        return 0

    return random.uniform(lo, hi)

# end get_random_float


def get_random_int(lo, hi):

    if lo > hi:
        return 0

    return random.randrange(lo, hi)

# end get_random_int


# Сгенерировать массив целых чисел
def generate_int_list(size, lo , hi):
    generating_list = []

    for i in range(size):
        generating_list.append(get_random_int(lo, hi))

    # end for

    return generating_list


# Сгенерировать массив вещественных чисел
def generate_float_list(size, lo , hi):
    generating_list = []

    for i in range(size):
        generating_list.append(get_random_float(lo, hi))

    # end for

    return generating_list

# region Вывод прямоугольников


rectangle_header = "┌─────┬───────┬───────┬───────┬───────┬───────────┬─────────┐\n" \
                   "│  №  │  x1   │   y1  │  x2   │  y2   │ Периметр  │ Площадь │" \



# В параметрах получаем кортж с значениями: номер прямоугольника, x1, y1, x2, y2, p, s
def to_table_row_rectangle(values_tuple):
    number, x1, y1, x2, y2, p, s = values_tuple
    return f"├─────┼───────┼───────┼───────┼───────┼───────────┼─────────┤\n" \
           f"│{number:^5}│{x1: >6.3f} │{y1: >6.3f} │{x2: >6.3f} │{y2: >6.3f} │{p: ^11.3f}│{s: ^9.3f}│"


rectangle_footer = "└─────┴───────┴───────┴───────┴───────┴───────────┴─────────┘\n"
# endregion


def show_list(source_list):
    list_str = ""

    index = 0
    # Выделить повторяющиеся элементы
    for item in source_list:

        line_break = "\n\n" if (index+1) % 15 == 0 and (index + 1) != 0 \
                               and index < len(source_list) - 1 else ""

        list_str += f" {console_colors.light_magenta} " \
                    f"{item: ^3} {console_colors.terminate}{line_break}"

        index += 1

    # end for

    print(list_str)


# Вывести список с выделением повторяющихся элементов для подзадачи 3
def show_list_subtask_3(source_list):
    list_str = ""

    index = 0
    # Выделить повторяющиеся элементы
    for item in source_list:

        line_break = "\n\n" if (index+1) % 15 == 0 and (index + 1) != 0\
                               and index < len(source_list) - 1 else ""

        list_str += f" {console_colors.light_magenta if source_list.count(item) == 1 else console_colors.blue_back_highlight} " \
                    f"{item: ^3} {console_colors.terminate}{line_break}"

        index += 1

    # end for

    print(list_str)


# region Поиск индексов мин. и макс. значений в списке
def index_min(source_list):
    min_val = source_list[0]
    index = 0

    for i in range(0, len(source_list)):

        if source_list[i] < min_val:
            min_val = source_list[i]
            index = i

    # end for

    return index


def index_max(source_list):
    max_val = source_list[0]
    index = 0

    for i in range(0, len(source_list)):

        if source_list[i] > max_val:
            max_val = source_list[i]
            index = i

    # end for

    return index
# endregion


# Вывод списка с выделением мин/макс. элементов
def highlight_min_max(source_list, min_i, max_i):

    list_str = ""

    for i in range(0, len(source_list)):

        # выбор цвета для максимального и минимального элемента
        color = console_colors.green_back_highlight \
            if i == min_i \
            else console_colors.blue_back_highlight \
            if i == max_i \
            else console_colors.light_magenta

        line_break = "\n\n" if (i + 1) % 15 == 0 and (i + 1) != 0 \
                                and i < len(source_list) - 1 else ""

        list_str += f" {color} {source_list[i]: ^3} {console_colors.terminate}{line_break}"
    # end for

    print(list_str)

def wait_for_enter_press():


    print("\nДля входа в меню нажмите enter...")

    import keyboard
    keyboard.wait("enter", True)

