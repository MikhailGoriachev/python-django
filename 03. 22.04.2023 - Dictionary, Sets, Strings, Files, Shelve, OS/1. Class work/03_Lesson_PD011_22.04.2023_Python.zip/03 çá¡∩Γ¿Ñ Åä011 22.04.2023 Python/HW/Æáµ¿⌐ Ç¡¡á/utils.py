import random


def get_rand(lo, hi):
    t = random.uniform(lo, hi)
    if abs(t) < 2:
        t = 0
    return t


# end get_rand


# вывод list в одну строку с заголовком title
def show_list(list, title):
    str1 = title + '['

    for item in list:
        str1 += f' {item} '
    str1 += ']'
    print(str1)
# end def


# вывод list в одну строку с заголовком title и выделением min, max
def show_list_with_min_max(list, title, min, max):
    str1 = title + '['

    for item in list:
        if item == min:
            str1 += f'\033[33m {item} \033[0m'
        elif item == max:
            str1 += f'\033[35m {item} \033[0m'
        else:
            str1 += f' {item} '
    str1 += ']'
    print(str1)
# end def


# вывод list в одну строку с заголовком title и выделением локальных min
def show_list_with_loc_min(list, title, list_index):
    str1 = title + '['

    for i in range(len(list)):
        if i in list_index:
            str1 += f'\033[32m {list[i]} \033[0m'
        else:
            str1 += f' {list[i]} '
    str1 += ']'
    print(str1)
# end def


# Заполнение списка случайными числами
def fill_list(list, low, high):
    for i in range(0, len(list)):
        list[i] = random.randint(low, high + 1)


# end def


# инициализация списка случайной длины нулями
# low, high - диапазон длины формируемого списка
def init_list(low, high):
    my_list = []

    for i in range(0, random.randint(low, high + 1)):
        my_list.append(0)

    return my_list


if __name__ == '__main__':
    import main

    main.main()
