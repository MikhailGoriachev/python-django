import functions
import utils

# диапазон генерации случайных чисел
LO = -20
HI = 20


# Task1. Обработка кортежей. Описать функцию rect_ps(x1, y1, x2, y2), вычисляющую периметр и площадь
# прямоугольника со сторонами, параллельными осям координат, по координатам (x1, y1), (x2, y2) его противоположных
# вершин. Функция возвращает кортеж с периметром и площадью. С помощью этой функции найти периметры и площади трех
# прямоугольников с данными противоположными вершинами.

def task01():
    task = '''\033[36;1m
    Task1. Обработка кортежей. Описать функцию rect_ps(x1, y1, x2, y2), вычисляющую периметр и площадь 
    прямоугольника со сторонами, параллельными осям координат, по координатам (x1, y1), (x2, y2) его противоположных 
    вершин (стороны вычисляются как a = abs(x2 - x1), b = abs(y2 – y1)). Функция возвращает кортеж с периметром и 
    площадью. С помощью этой функции найти периметры и площади трех прямоугольников с данными противоположными 
    вершинами. 
    \033[0m'''
    print(task)

    # выводим шапку таблицы
    print(f'\033'
          '\t┌─────┬────────┬────────┬────────┬────────┬─────────┬─────────┐\n'
          '\t│  №  │   x1   │   y1   │   x2   │   y2   │    P    │    S    │\n'
          '\t├─────┼────────┼────────┼────────┼────────┼─────────┼─────────┤')

    for i in range(1, 4):
        a = utils.get_rand(LO, HI)
        b = utils.get_rand(LO, HI)
        c = utils.get_rand(LO, HI)
        d = utils.get_rand(LO, HI)

        # формирование строки таблицы
        table_row = f'\t│{i:5}│{a:8.3f}│{b:8.3f}│{c:8.3f}│{d:8.3f}'
        p, s = functions.rect_ps(a, b, c, d)

        table_row += f'│{p:9.3f}│{s:9.3f}│'
        print(table_row)

    print('\t└─────┴────────┴────────┴────────┴────────┴─────────┴─────────┘\033[0m\n')


def task02(num):
    # антипаттерн Magic Number
    list_c = utils.init_list(10, 15)  # длина списка по заданию - исправление антипаттерна
    utils.fill_list(list_c, LO, HI)

    if num == 1:

        utils.show_list(list_c, "\n\tСписок до обработки:")
        # Увеличить все нечетные числа, содержащиеся в списке, на исходное значение последнего нечетного числа.

        list_c.reverse()

        value = 0

        for item in list_c:
            if item % 2 != 0:
                value = item
                break

        list_c.reverse()

        for i in range(len(list_c)):
            if list_c[i] % 2 != 0:
                list_c[i] += value

        # Вывести упорядоченную по убыванию копию списка
        list = sorted(list_c)
        list.reverse()

        utils.show_list(list, "\n\tСписок после обработки:")

    elif num == 2:

        my_list = []

        # Сформируйте список list_c. Возвести в квадрат все его локальные минимумы
        for i in range(1, len(list_c) - 1):
            if list_c[i - 1] > list_c[i] < list_c[i + 1]:
                my_list.append(i)

        utils.show_list_with_loc_min(list_c, "\n\tСписок до обработки: зеленые - локальные минимумы ", my_list)

        for i in my_list:
            list_c[i] *= list_c[i]

        utils.show_list_with_loc_min(list_c, "\n\tСписок после обработки: зеленые - локальные минимумы ", my_list)

    elif num == 3:

        utils.show_list(list_c, "\n\tСписок до обработки:")
        list_c.reverse()

        # Удалить из списка все одинаковые элементы, оставив их первые вхождения
        for item in list_c:
            n = list_c.count(item)
            if n > 1:
                for i in range(0, n - 1):
                    list_c.remove(item)

        list_c.reverse()

        utils.show_list(list_c, "\n\tСписок после обработки:")

    elif num == 4:

        # Вставить элемент с нулевым значением перед минимальным и после максимального элемента списка
        # находим мин макс
        min_list = min(list_c)
        max_list = max(list_c)

        # находим индексы мин макс
        index_min_list_c = list_c.index(min_list)
        index_max_list_c = list_c.index(max_list)

        utils.show_list_with_min_max(list_c, "\n\tСписок до обработки: min - желтый, max - фиолетовый", min_list,
                                     max_list)

        if index_min_list_c < index_max_list_c:
            list_c.insert(index_min_list_c, 0)
            list_c.insert(index_max_list_c + 2, 0)
        else:
            list_c.insert(index_max_list_c + 1, 0)
            list_c.insert(index_min_list_c + 1, 0)

        utils.show_list_with_min_max(list_c, "\n\tСписок после обработки: min - желтый, max - фиолетовый", min_list,
                                     max_list)
    else:
        raise Exception("\n\t\033[31;1mОшибка: нет такого обработчика списка\033[0m")


if __name__ == '__main__':
    import main

    main.main()
