# вспомогательные функции задания


# вывод меню из словаря menu_task, выбор в меню и выполнение команд меню
import main


def do_menu(menu_task, title):
    while True:
        try:
            # вывести меню
            print(title)
            for key, value in menu_task.items():
                print(f'\t \033[34;1m{key}\033[0m. {value[0]}')
            # end for

            # ввести команду меню
            cmd = input('\t    Введите команду: ')

            # специальная команда - выход из цикла
            # обработки меню
            if cmd == '0':
                print()
                break
            # end if

            # выполнить команду меню, если команды нет - сообщить об ошибке
            if cmd in menu_task:
                menu_task[cmd][1]()
            else:
                raise Exception("нет такого пункта меню")
            # end if
        except Exception as e:
            print(f'\n\t\033[31;1mОшибка: {e}\033[0m\n')
        # end try-except
    # end while
# end do_menu


# запуск главной функции приложения
if __name__ == '__main__':
    main.main()
# end if

