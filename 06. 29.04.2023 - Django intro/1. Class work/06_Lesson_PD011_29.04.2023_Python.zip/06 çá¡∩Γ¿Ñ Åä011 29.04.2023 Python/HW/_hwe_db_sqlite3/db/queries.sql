-- Запрос 1. Запрос к данным	
-- Выбирает информацию о пациентах с фамилиями, начинающимися на заданную 
-- параметром последовательность букв
select
    *
from
    view_patients
where
    patient_surname like 'Ива' ||'%';

-- Запрос 2. Запрос к данным	
-- Выбирает информацию о врачах, для которых значение в поле Процент отчисления 
-- на зарплату, больше 2.3% (задавать параметром)
select
    *
from
    view_doctors
where
    interest > 20;

-- Запрос 3. Запрос к данным	
-- Выбирает информацию о приемах за некоторый период, заданный параметрами
select
    id
    , date
    , patient_surname
    , patient_name
    , patient_patronymic
    , doctor_surname
    , doctor_name
    , doctor_patronymic
    , category_name
    , price
from
    view_appointments
where
    date between '10.03.2022' and '12.03.2022';

-- Запрос 4. Запрос к данным	
-- Выбирает информацию о докторах, специальность которых задана параметром 
select
    *
from
    view_doctors
where
    category_name = 'офтальмолог';

-- Запрос 5. Запрос к данным	
-- Вычисляет размер заработной платы врача за каждый прием. Включает поля 
-- Фамилия врача, Имя врача, Отчество врача, Специальность врача, Стоимость 
-- приема, Зарплата. Сортировка по полю Специальность врача
select
    id
    , date
    , doctor_surname
    , doctor_name
    , doctor_patronymic
    , category_name
    , price
    , interest
    , price * interest / 100 as salary
from
    view_appointments
order by
    category_name;
 	 	 
-- Запрос 6. 
-- Итоговый запрос	
-- Выполняет группировку по полю Дата приема. Для каждой даты вычисляет 
-- максимальную стоимость приема
select
    date
    , count(price) as quantity
    , max(price) as maxPrice
from
    view_appointments
group by
    date;

-- Запрос 7. Итоговый запрос	
-- Выполняет группировку по полю Специальность. Для каждой специальности 
-- вычисляет средний Процент отчисления на зарплату от стоимости приема
select
    category_name
    , count(category_name) as quantity
    , avg(interest) as avgInterest
from
    view_appointments
group by
    category_name;