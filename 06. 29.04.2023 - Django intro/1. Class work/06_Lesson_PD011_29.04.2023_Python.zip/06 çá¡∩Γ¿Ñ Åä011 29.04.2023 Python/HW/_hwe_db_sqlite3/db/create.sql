-- создание таблиц БД

CREATE TABLE if not exists persons (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    surname    TEXT    NOT NULL,
    name       TEXT    NOT NULL,
    patronymic TEXT    NOT NULL
);


CREATE TABLE if not exists categories (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    category_name TEXT    NOT NULL
);


CREATE TABLE if not exists doctors (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    id_person   INTEGER REFERENCES persons (id),
    id_category INTEGER REFERENCES categories (id),
    price       DOUBLE  NOT NULL
                        CHECK (price > 0),
    interest    DOUBLE  NOT NULL
                        CHECK (interest BETWEEN 1 AND 100) 
);


CREATE TABLE if not exists patients (
    id        INTEGER  PRIMARY KEY AUTOINCREMENT,
    id_person INTEGER  REFERENCES persons (id),
    dob       DATETIME NOT NULL,
    address   TEXT     NOT NULL
);

CREATE TABLE if not exists appointments (
    id         INTEGER  PRIMARY KEY AUTOINCREMENT
                        NOT NULL,
    id_doctor           REFERENCES doctors (id) 
                        NOT NULL,
    id_patient          REFERENCES patients (id) 
                        NOT NULL,
    date       DATETIME NOT NULL
);


