import sqlite3
import main

# имя базы данных
db = "db/paid_clinic.db"


# Запрос 1. Запрос к данным
# Выбирает информацию о пациентах с фамилиями, начинающимися на заданную
# параметром последовательность букв
def query1():
    connection = sqlite3.connect(db)
    cursor = connection.cursor()

    # использование именованного параметра
    sql = '''
        select
            *
        from
            view_patients
        where
            patient_surname like :patient_name || '%';
    '''
    cursor.execute(sql, {'patient_name': 'Се'})

    print()
    # кортеж для доступа к данным
    for (id, patient_surname, patient_name, patient_patronymic, dob, address) in cursor.fetchall():
        print(f"\t| {id:5} | {patient_surname:18} | {patient_name:18} | "
              f"{patient_patronymic:18} | {dob:10} | {address:45} |")
    print()


# Запрос 2. Запрос к данным
# Выбирает информацию о врачах, для которых значение в поле Процент отчисления
# на зарплату, больше 2.3% (задавать параметром)
def query2():
    connection = sqlite3.connect(db)
    cursor = connection.cursor()

    # использование именованного параметра
    sql = '''
        select
            *
        from
            view_doctors
        where
            interest > :interest;
    '''
    doctors = cursor.execute(sql, {'interest': 20})

    print()
    # имена столбцов для доступа к данным
    for doctor in doctors:
        print(f"\t| {doctor[0]:5} | {doctor[1]:18} | {doctor[2]:18} | "
              f"{doctor[3]:18} | {doctor[4]:20} | {doctor[5]:8.2f} | {doctor[6]:8.2f} |")
    print()


# Запрос 3. Запрос к данным
# Выбирает информацию о приемах за некоторый период, заданный параметрами
def query3():
    connection = sqlite3.connect(db)
    cursor = connection.cursor()

    # использование именованного параметра
    sql = '''
        select
            id
            , date
            , patient_surname
            , patient_name
            , patient_patronymic
            , doctor_surname
            , doctor_name
            , doctor_patronymic
            , category_name
            , price
        from
            view_appointments
        where
            date between :from and :to;
    '''
    rows = cursor.execute(sql, {'from': '10.03.2022', 'to': '12.03.2022'})

    print()
    for (id, date, patient_surname, patient_name, patient_patronymic,
         doctor_surname, doctor_name, doctor_patronymic, category_name, price) in rows:
        print(f"\t| {id:3} | {date:10} |"
              f" {patient_surname:18} | {patient_name:18} | {patient_patronymic:18} |"
              f" {doctor_surname:18} | {doctor_name:18} | {doctor_patronymic:18} |"
              f" {category_name:25} | {price:10.2f} |")
    print()


# Запрос 4. Запрос к данным
# Выбирает информацию о докторах, специальность которых задана параметром
def query4():
    connection = sqlite3.connect(db)
    cursor = connection.cursor()

    # использование именованного параметра
    sql = '''
        select
            id
            , doctor_surname
            , doctor_name
            , doctor_patronymic
            , category_name
            , price
            , interest
        from
            view_doctors
        where
            category_name = :category_name;
    '''
    rows = cursor.execute(sql, {'category_name': 'офтальмолог'})

    print()
    for (id, doctor_surname, doctor_name, doctor_patronymic, category_name, price, interest) in rows:
        print(f"\t| {id:3} |"
              f" {doctor_surname:18} | {doctor_name:18} | {doctor_patronymic:18} |"
              f" {category_name:25} | {price:10.2f} | {interest:10.2f} |")
    print()


# Запрос 5. Запрос к данным
# Вычисляет размер заработной платы врача за каждый прием. Включает поля
# Фамилия врача, Имя врача, Отчество врача, Специальность врача, Стоимость
# приема, Зарплата. Сортировка по полю Специальность врача
def query5():
    connection = sqlite3.connect(db)
    cursor = connection.cursor()

    # использование именованного параметра
    sql = '''
        select
            id
            , date
            , doctor_surname
            , doctor_name
            , doctor_patronymic
            , category_name
            , price
            , interest
            , price * interest / 100 as salary
        from
            view_appointments
        order by
            category_name;
    '''
    rows = cursor.execute(sql)

    print()
    # имена столбцов для доступа к данным
    for (id, date, doctor_surname, doctor_name, doctor_patronymic, category_name,
         price, interest, salary) in rows:
        print(f"\t| {id:3} | {date:10} | {doctor_surname:18} | {doctor_name:18} | "
              f"{doctor_patronymic:18} | {category_name:25} | {price:10.2f} | "
              f"{interest:8.2f} | {salary:10.2f} |")
    print()


# Запрос 6.
# Итоговый запрос
# Выполняет группировку по полю Дата приема. Для каждой даты вычисляет
# максимальную стоимость приема
def query6():
    connection = sqlite3.connect(db)
    cursor = connection.cursor()

    # использование именованного параметра
    sql = '''
        select
            date
            , count(price) as quantity
            , max(price) as maxPrice
        from
            view_appointments
        group by
            date;
    '''
    rows = cursor.execute(sql)

    print()
    # в кортеже - имена столбцов для доступа к данным
    for (date, quantity, maxPrice) in rows:
        print(f"\t| {date:10} | {quantity:8} | {maxPrice:10.2f} |")
    print()


# Запрос 7. Итоговый запрос
# Выполняет группировку по полю Специальность. Для каждой специальности
# вычисляет средний Процент отчисления на зарплату от стоимости приема
def query7():
    connection = sqlite3.connect(db)
    cursor = connection.cursor()

    # использование именованного параметра
    sql = '''
        select
            category_name
            , count(category_name) as quantity
            , avg(interest) as avgInterest
        from
            view_appointments
        group by
            category_name;
    '''
    rows = cursor.execute(sql)

    print()
    # в кортеже - имена столбцов для доступа к данным
    for (category_name, quantity, avgInterest) in rows:
        print(f"\t| {category_name:20} | {quantity:8} | {avgInterest:8.2f} |")
    print()
#end query7


# Вывод всех таблиц БД с расшифровкой (используем представление)
def all_tables():
    connection = sqlite3.connect(db)
    cursor = connection.cursor()
    cursor.execute('select * from view_patients;')

    print('\n\tТаблица \033[1mПАЦИЕНТЫ (patients)\033[0m')
    # кортеж для доступа к данным
    for (id, patient_surname, patient_name, patient_patronymic, dob, address) in cursor.fetchall():
        print(f"\t| {id:5} | {patient_surname:18} | {patient_name:18} | "
              f"{patient_patronymic:18} | {dob:10} | {address:35} |")
    print('\n--------------------------------------------------\n')

    # чтение из представления для докторов
    doctors = cursor.execute('select * from view_doctors')

    print('\n\tТаблица \033[1mВРАЧИ (doctors)\033[0m')
    # имена столбцов для доступа к данным
    for doctor in doctors:
        print(f"\t| {doctor[0]:5} | {doctor[1]:18} | {doctor[2]:18} | "
              f"{doctor[3]:18} | {doctor[4]:20} | {doctor[5]:8.2f} | {doctor[6]:8.2f} |")
    print('\n--------------------------------------------------\n')

    rows = cursor.execute('select * from view_appointments;')

    print('\n\tТаблица \033[1mПРИЕМЫ (appointments)\033[0m')
    # имена столбцов для доступа к данным
    for (id, date, patient_surname, patient_name, patient_patronymic, dob, address,
        doctor_surname, doctor_name, doctor_patronymic, category_name,
        price, interest) in rows:
        print(f"\t| {id:3} | {date:10} "
              f"| {patient_surname:18} | {patient_name:18} "
              f"| {patient_patronymic:18} | {dob:10} | {address:35} "
              f"| {doctor_surname:18} | {doctor_name:18} "
              f"| {doctor_patronymic:18} | {category_name:25} | {price:10.2f} "
              f"| {interest:8.2f} |")
    print('\n--------------------------------------------------\n')

    rows = cursor.execute('select * from persons;')

    print('\n\tТаблица \033[1mПЕРСОНАЛЬНЫЕ ДАННЫЕ (persons)\033[0m')
    # имена столбцов для доступа к данным
    for (id, surname, name, patronymic) in cursor:
        print(f"\t| {id:3} | {surname:18} | {name:18} | {patronymic:18} |")
    print('\n--------------------------------------------------\n')

    rows = cursor.execute('select * from categories;')

    print('\n\tТаблица \033[1mСПЕЦИАЛЬНОСТИ (categories)\033[0m')
    # имена столбцов для доступа к данным
    for (id, category_name) in cursor:
        print(f"\t| {id:3} | {category_name:25} |")
    print('\n--------------------------------------------------\n')
#end all_tables


# запуск главной функции приложения
if __name__ == '__main__':
    main.main()
# end if