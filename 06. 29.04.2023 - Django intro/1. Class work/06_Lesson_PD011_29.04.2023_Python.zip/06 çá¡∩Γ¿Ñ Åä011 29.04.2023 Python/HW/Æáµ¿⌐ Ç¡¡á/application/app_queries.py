import sqlite3

import utils
from views.queries.Query05 import Query05
from views.queries.Query06 import Query06
from views.queries.Query07 import Query07


# исполнение запроса
def do_query_5():
    connection = sqlite3.connect("db/Appointment.db")
    cursor = connection.cursor()
    cursor.execute(sql_query05)

    result = []
    for (surname, name, patronymic, specialization, price, profit) in cursor.fetchall():
        row = Query05(surname, name, patronymic, specialization, price, profit)
        result.append(row)

    utils.show("\n\tРезультат запроса 5:", result, Query05.header, Query05.footer)
    cursor.close()


def do_query_6():
    connection = sqlite3.connect("db/Appointment.db")
    cursor = connection.cursor()
    cursor.execute(sql_query06)

    result = []
    for (data, price) in cursor.fetchall():
        row = Query06(utils.convert_date_from_str(data), price)
        result.append(row)

    utils.show("\n\tРезультат запроса 6:", result, Query06.header, Query06.footer)
    cursor.close()


def do_query_7():
    connection = sqlite3.connect("db/Appointment.db")
    cursor = connection.cursor()
    cursor.execute(sql_query07)

    result = []
    for (specialization, tax) in cursor.fetchall():
        row = Query07(specialization, tax)
        result.append(row)

    utils.show("\n\tРезультат запроса 7:", result, Query07.header, Query07.footer)
    cursor.close()


# Вычисляет размер заработной платы врача за каждый прием. Включает поля Фамилия врача, Имя врача, Отчество врача,
# Специальность врача, Стоимость приема, Зарплата. Сортировка по полю Специальность врача
sql_query05 = '''select  
      Doctors.surname as surname, 
      Doctors.name as dname, 
      Doctors.patronymic as patronymic, 
      Specialties.name as sname, 
      Receipts.price as price, 
      (Doctors.tax - 13)/100*Receipts.price as profit 
from Receipts join (Doctors join Specialties on Doctors.id_specialtie = Specialties._id) on Receipts.id_doctor = Doctors._id 
order by Specialties.name '''


# Выполняет группировку по полю Дата приема. Для каждой даты вычисляет максимальную стоимость приема
sql_query06 = '''select 
   Receipts.date as date,
   max(Receipts.price) as max
from Receipts
group by Receipts.date'''

# Выполняет группировку по полю Специальность. Для каждой специальности вычисляет средний Процент
# отчисления на зарплату от стоимости приема
sql_query07 = '''select 
    Specialties.name as name, 
    avg(tax) as avg 
from Doctors join Specialties on Doctors.id_specialtie = Specialties._id 
group by Specialties._id, Specialties.name'''
