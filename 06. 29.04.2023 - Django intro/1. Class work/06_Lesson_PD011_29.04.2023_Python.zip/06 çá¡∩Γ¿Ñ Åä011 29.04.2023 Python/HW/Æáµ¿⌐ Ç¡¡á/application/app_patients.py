import sqlite3

import utils
from views.Patient import Patient


def show(title, data):
    utils.show(title, data, Patient.header, Patient.footer)


# исполнение запроса
def do_query(sql, title, params=None):
    connection = sqlite3.connect("db/Appointment.db")
    cursor = connection.cursor()
    if params is None:
        cursor.execute(sql)
    else:
        cursor.execute(sql, params)

    patients = []

    for (_id, surname, name, patronymic, date_of_birth, address) in cursor.fetchall():
        patient = Patient(_id, surname, name, patronymic, utils.convert_date_from_str(date_of_birth), address)
        patients.append(patient)

    if len(patients) == 0:
        raise Exception("По вашему запросу ничего не найдено")
    else:
        show(title, patients)

    cursor.close()


# вывод всех записей из таблицы пациенты
sql_all = '''SELECT Patients._id,
       Patients.surname,
       Patients.name,
       Patients.patronymic,
       Patients.Date_of_Birth,
       Patients.address
  FROM Patients
  
'''

# Выбирает информацию о пациентах с фамилиями, начинающимися на заданную параметром последовательность букв
sql_query01 = sql_all + "where like(?,surname)=1"
