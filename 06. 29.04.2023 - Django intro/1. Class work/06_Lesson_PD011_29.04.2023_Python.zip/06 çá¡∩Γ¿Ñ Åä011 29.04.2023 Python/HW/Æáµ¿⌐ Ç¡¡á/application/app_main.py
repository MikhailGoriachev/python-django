# запуск главной функции приложения
import main
import utils

from application import app_doctors, app_patients, app_receipts, app_specialtie, app_queries


# Выведите также все таблицы с расшифровкой полей (используйте представления).
def show_doctors():
    app_doctors.do_query(app_doctors.sql_all, "\n\tТаблица врачи:")


def show_patients():
    app_patients.do_query(app_patients.sql_all, "\n\tТаблица пациенты:")


def show_receipts():
    app_receipts.do_query(app_receipts.sql_all, "\n\tТаблица приемы:")


def show_specialties():
    app_specialtie.do_query(app_specialtie.sql_all, "\n\tТаблица специальности:")


# Выбирает информацию о пациентах с фамилиями, начинающимися на заданную параметром последовательность букв
def do_query01():

    cmd = input('\n\tВведите последовательность букв: ')

    app_patients.do_query(app_patients.sql_query01, "\n\tРезультат запроса 1:", [f"{cmd}%"])


# Выбирает информацию о врачах, для которых значение в поле Процент отчисления на зарплату, больше 2.3%
def do_query02():
    cmd = input('\n\tВведите процент отчисления на зарплату: ')

    app_doctors.do_query(app_doctors.sql_query02, "\n\tРезультат запроса 2:", cmd)


# Выбирает информацию о приемах за некоторый период, заданный параметрами
def do_query03():
    cmd = input('\n\tВведите период (например: 5.11.2022 27.11.2022): ')

    params = cmd.split(" ")
    lo = utils.convert_date_from_str_2(params[0])
    hi = utils.convert_date_from_str_2(params[1])

    app_receipts.do_query(app_receipts.sql_query03, "\n\tРезультат запроса 3:", lo, hi)


# Выбирает информацию о докторах, специальность которых задана параметром
def do_query04():
    show_specialties()
    # cmd = input('\tВведите специальность: ')
    cmd = 'Аллерголог'

    app_doctors.do_query(app_doctors.sql_query04, "\n\tРезультат запроса 4:", cmd)


# Вычисляет размер заработной платы врача за каждый прием.
def do_query05():
    app_queries.do_query_5()


# Выполняет группировку по полю Дата приема. Для каждой даты вычисляет максимальную стоимость приема
def do_query06():
    app_queries.do_query_6()


# Выполняет группировку по полю Специальность. Для каждой специальности вычисляет средний Процент
# отчисления на зарплату от стоимости приема
def do_query07():
    app_queries.do_query_7()


def show_queries_menu():

    # меню запросов
    menu_task = {
        '1': ['Выбирает информацию о пациентах с фамилиями, начинающимися на заданную параметром последовательность '
              'букв ', do_query01],
        '2': ['Выбирает врачей, для которых процент отчисления на зарплату больше заданного', do_query02],
        '3': ['Выбирает информацию о приемах за некоторый период, заданный параметрами', do_query03],
        '4': ['Выбирает информацию о докторах, специальность которых задана параметром', do_query04],
        '5': ['Вычисляет размер заработной платы врача за каждый прием', do_query05],
        '6': ['Для каждой даты вычисляет максимальную стоимость приема', do_query06],
        '7': ['Для каждой специальности вычисляет средний Процент', do_query07],
        '0': ['Выход', 0]
    }

    # обработка меню приложения
    utils.do_menu(menu_task, '\n\t    Меню запросов')


if __name__ == '__main__':
    main.main()
