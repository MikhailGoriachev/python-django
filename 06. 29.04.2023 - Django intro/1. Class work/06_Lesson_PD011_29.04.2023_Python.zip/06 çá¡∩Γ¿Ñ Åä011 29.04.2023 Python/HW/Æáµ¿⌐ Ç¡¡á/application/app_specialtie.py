import sqlite3
import utils
from views.Specialty import Specialty


def show(title, data):
    utils.show(title, data, Specialty.header, Specialty.footer)


# исполнение запроса
def do_query(sql, title):
    connection = sqlite3.connect("db/Appointment.db")
    cursor = connection.cursor()
    cursor.execute(sql)

    specialties = []

    for (_id, name) in cursor.fetchall():
        specialty = Specialty(_id, name)
        specialties.append(specialty)

    show(title, specialties)

    cursor.close()


sql_all = '''SELECT Specialties._id,
       Specialties.name
  FROM Specialties;
'''
