import sqlite3

import utils
from views.Receipt import Receipt


def show(title, data):
    utils.show(title, data, Receipt.header, Receipt.footer)


# исполнение запроса
def do_query(sql, title, lo = None, hi = None):
    connection = sqlite3.connect("db/Appointment.db")
    cursor = connection.cursor()
    if lo is None and hi is None:
        cursor.execute(sql)
    else:
        cursor.execute(sql, [lo, hi])

    receipts = []

    for (_id, date, price, doctors_surname, doctors_name, doctors_patronymic, doctors_specialization,
         patients_surname, patients_name, patients_patronymic, patients_date_of_birth) in cursor.fetchall():
        receipt = Receipt(_id, utils.convert_date_from_str(date), price, doctors_surname, doctors_name,
                          doctors_patronymic, doctors_specialization,
                          patients_surname, patients_name, patients_patronymic,
                          utils.convert_date_from_str(patients_date_of_birth))
        receipts.append(receipt)

    if len(receipts) == 0:
        raise Exception("По вашему запросу ничего не найдено")
    else:
        show(title, receipts)

    cursor.close()


sql_all = '''SELECT Receipts._id,
       Receipts.date,
       Receipts.price,
       Doctors.surname as doctors_surname,
       Doctors.name as doctors_name,
       Doctors.patronymic as doctors_patronymic,
       Specialties.name as doctors_specialization,
       Patients.surname as patients_surname,
       Patients.name as patients_name,
       Patients.patronymic as patients_patronymic,
       Patients.Date_of_Birth as patients_date_of_birth
  FROM Receipts join ( Doctors join Specialties on Doctors.id_specialtie = Specialties._id) on Receipts.id_doctor = Doctors._id
                join Patients on Receipts.id_patient = Patients._id
                '''

# Выбирает информацию о приемах за некоторый период, заданный параметрами
sql_query03 = sql_all + "where date between ? and ?"
