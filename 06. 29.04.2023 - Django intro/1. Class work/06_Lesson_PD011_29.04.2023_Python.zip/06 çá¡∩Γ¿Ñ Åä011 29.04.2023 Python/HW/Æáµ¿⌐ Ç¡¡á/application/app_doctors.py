import sqlite3

import utils
from views.Doctor import Doctor


def show(title, data):
    utils.show(title, data, Doctor.header, Doctor.footer)


# исполнение запроса
def do_query(sql, title, params=None):
    connection = sqlite3.connect("db/Appointment.db")
    cursor = connection.cursor()
    if params is None:
        cursor.execute(sql)
    else:
        cursor.execute(sql, [f"{params}"])

    doctors = []

    for (_id, surname, name, patronymic, specialization, tax) in cursor.fetchall():
        doctor = Doctor(_id, surname, name, patronymic, specialization, tax)
        doctors.append(doctor)

    if len(doctors) == 0:
        raise Exception("По вашему запросу ничего не найдено")
    else:
        show(title, doctors)

    cursor.close()


# вывод всех записей из таблицы врачи
sql_all = '''SELECT 
         Doctors._id,
         Doctors.surname,
         Doctors.name,
         Doctors.patronymic,
         Specialties.name as specialization,
         Doctors.tax
    FROM Doctors join Specialties on Doctors.id_specialtie = Specialties._id
    '''

# Выбирает информацию о врачах, для которых значение в поле Процент отчисления на зарплату, больше 2.3%
# sql_query02 = f'{sql_all} where tax > ?'
sql_query02 = sql_all + "where tax > ?"

# Выбирает информацию о докторах, специальность которых задана параметром
sql_query04 = sql_all + "where Specialties.name = ?"

