import utils


class Receipt:

    def __init__(self, id_, date, price, doctors_surname, doctors_name, doctors_patronymic, doctors_specialization,
                 patients_surname, patients_name, patients_patronymic, patients_date_of_birth):
        self.__id = id_
        self.__date = date
        self.__price = price
        self.__doctors_surname = doctors_surname
        self.__doctors_name = doctors_name
        self.__doctors_patronymic = doctors_patronymic
        self.__doctors_specialization = doctors_specialization
        self.__patients_surname = patients_surname
        self.__patients_name = patients_name
        self.__patients_patronymic = patients_patronymic
        self.__patients_date_of_birth = patients_date_of_birth

    @property
    def id(self): return self.__id

    @property
    def date(self): return self.__date

    @property
    def price(self): return self.__price

    @property
    def doctors_surname(self): return self.__doctors_surname

    @property
    def doctors_name(self): return self.__doctors_name

    @property
    def doctors_patronymic(self): return self.__doctors_patronymic

    @property
    def doctors_specialization(self): return self.__doctors_specialization,

    @property
    def patients_surname(self): return self.__patients_surname

    @property
    def patients_name(self): return self.__patients_name

    @property
    def patients_patronymic(self): return self.__patients_patronymic

    @property
    def patients_date_of_birth(self): return self.__patients_date_of_birth

    def __str__(self) -> str:
        doctor = f"{self.__doctors_surname} {self.__doctors_name} {self.__doctors_patronymic}"
        patient = f"{self.__patients_surname} {self.__patients_name} {self.__patients_patronymic}"

        return f'\t│{self.__id:3} │ {utils.convert_str_from_date(self.__date):12}│{self.__price:10} │ {doctor:33}│ ' \
               f'{self.__doctors_specialization:19}│' \
               f' {patient:32}│ {utils.convert_str_from_date(self.__patients_date_of_birth):23}│'

    header = \
        '\t┌────┬─────────────┬───────────┬──────────────────────────────────┬────────────────────┬─────────────────────────────────┬──────' \
        '──────────────────┐\n' \
        '\t│ Id │ Дата приема │ Стоимость │             ФИО врача            │    Специальность   │           ФИО пациента          │ Дата' \
        ' рождения пациента │\n' \
        '\t├────┼─────────────┼───────────┼──────────────────────────────────┼────────────────────┼─────────────────────────────────┼────' \
        '────────────────────┤'

    footer = \
        '\t└────┴─────────────┴───────────┴──────────────────────────────────┴────────────────────┴─────────────────────────────────┴────' \
        '────────────────────┘'
