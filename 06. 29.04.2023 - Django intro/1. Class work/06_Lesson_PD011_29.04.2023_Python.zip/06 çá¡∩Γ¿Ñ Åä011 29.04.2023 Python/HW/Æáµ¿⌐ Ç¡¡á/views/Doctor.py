class Doctor:

    def __init__(self, id_, surname, name, patronymic, specialization, tax) -> None:
        self.__id = id_
        self.__surname = surname
        self.__name = name
        self.__patronymic = patronymic
        self.__specialization = specialization
        self.__tax = tax

    @property
    def id(self): return self.__id

    @property
    def name(self):
        return self.__name

    @property
    def surname(self): return self.__surname

    @property
    def patronymic(self): return self.__patronymic

    @property
    def specialization(self): return self.__specialization

    @property
    def tax(self): return self.__tax

    def __str__(self) -> str:
        return f'\t│{self.__id:3} │ {self.__surname:14}│ {self.__name:12}│ {self.__patronymic:13}│ {self.__specialization:19}│' \
               f'{self.__tax:8} │'

    header = \
        '\t┌────┬───────────────┬─────────────┬──────────────┬────────────────────┬─────────┐\n' \
        '\t│ Id │    Фамилия    │     Имя     │   Отчество   │    Специальность   │ Процент │\n' \
        '\t├────┼───────────────┼─────────────┼──────────────┼────────────────────┼─────────┤'

    footer = \
        '\t└────┴───────────────┴─────────────┴──────────────┴────────────────────┴─────────┘'
