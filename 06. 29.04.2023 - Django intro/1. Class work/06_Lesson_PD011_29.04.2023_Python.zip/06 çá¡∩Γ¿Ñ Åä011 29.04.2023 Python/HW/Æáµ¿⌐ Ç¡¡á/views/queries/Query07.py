class Query07:

    def __init__(self, specialization, tax):
        self.__specialization = specialization
        self.__tax = tax

    header = \
        '\t┌─────────────────┬─────────────────┐\n' \
        '\t│  Специальность  │     Процент     │\n' \
        '\t├─────────────────┼─────────────────┤'
    footer = \
        '\t└─────────────────┴─────────────────┘'

    def __str__(self) -> str:
        return f"\t│ {self.__specialization:16}│{self.__tax:16.3f} │"


