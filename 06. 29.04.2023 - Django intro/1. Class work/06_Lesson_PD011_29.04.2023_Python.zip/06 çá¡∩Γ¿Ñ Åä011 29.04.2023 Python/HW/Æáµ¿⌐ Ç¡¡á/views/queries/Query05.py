class Query05:
    """
    Вычисляет размер заработной платы врача за каждый прием. Включает поля Фамилия врача, Имя врача,
     Отчество врача, Специальность врача, Стоимость приема, Зарплата. Сортировка по полю Специальность врача
    """

    def __init__(self, surname, name, patronymic, specialization, price, profit):
        self.__surname = surname
        self.__name = name
        self.__patronymic = patronymic
        self.__specialization = specialization
        self.__price = price
        self.__profit = profit

    def __str__(self) -> str:
        return f'\t│ {self.__surname:14}│ {self.__name:12}│ {self.__patronymic:13}│ {self.__specialization:19}│' \
               f'{self.__price:17} │{self.__profit:14.3f} │'

    header = \
        '\t┌───────────────┬─────────────┬──────────────┬────────────────────┬──────────────────┬───────────────┐\n' \
        '\t│    Фамилия    │     Имя     │   Отчество   │    Специальность   │ Стоимость приема │    Зарплата   │\n' \
        '\t├───────────────┼─────────────┼──────────────┼────────────────────┼──────────────────┼───────────────┤'

    footer = \
        '\t└───────────────┴─────────────┴──────────────┴────────────────────┴──────────────────┴───────────────┘'
