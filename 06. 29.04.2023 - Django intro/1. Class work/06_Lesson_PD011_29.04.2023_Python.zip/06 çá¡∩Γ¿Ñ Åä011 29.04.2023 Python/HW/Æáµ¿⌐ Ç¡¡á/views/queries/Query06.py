import utils


class Query06:

    def __init__(self, data, price):
        self.__data = data
        self.__price = price

    def __str__(self) -> str:
        return f"\t│ {utils.convert_str_from_date(self.__data):16}│{self.__price:16} │"

    header = \
        '\t┌─────────────────┬─────────────────┐\n' \
        '\t│   Дата приема   │    Стоимость    │\n' \
        '\t├─────────────────┼─────────────────┤'
    footer = \
        '\t└─────────────────┴─────────────────┘'
