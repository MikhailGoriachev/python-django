import utils


class Patient:

    def __init__(self, id_, surname, name, patronymic, date_of_birth, address):
        self.__id = id_
        self.__surname = surname
        self.__name = name
        self.__patronymic = patronymic
        self.__date_of_birth = date_of_birth
        self.__address = address

    @property
    def id(self): return self.__id

    @property
    def name(self):
        return self.__name

    @property
    def surname(self): return self.__surname

    @property
    def patronymic(self): return self.__patronymic

    @property
    def date_of_birth(self): return self.__date_of_birth

    @property
    def address(self): return self.__address

    def __str__(self) -> str:
        return f'\t│{self.__id:3} │ {self.__surname:14}│ {self.__name:12}│ {self.__patronymic:13}│ {utils.convert_str_from_date(self.__date_of_birth):14}│' \
               f' {self.__address:23}│'

    header = \
        '\t┌────┬───────────────┬─────────────┬──────────────┬───────────────┬────────────────────────┐\n' \
        '\t│ Id │    Фамилия    │     Имя     │   Отчество   │ Дата рождения │    Адрес проживания    │\n' \
        '\t├────┼───────────────┼─────────────┼──────────────┼───────────────┼────────────────────────┤'

    footer = \
        '\t└────┴───────────────┴─────────────┴──────────────┴───────────────┴────────────────────────┘'
