class Specialty:

    def __init__(self, id, name):
        self.__id = id
        self.__name = name

    @property
    def name(self):
        return self.__name

    @property
    def id(self): return self.__id

    def __str__(self) -> str:
        return f'\t│{self.__id:3} │ {self.__name:16}│'

    header = \
        '\t┌────┬─────────────────┐\n' \
        '\t│ Id │  Специальность  │\n' \
        '\t├────┼─────────────────┤'
    footer = \
        '\t└────┴─────────────────┘'
