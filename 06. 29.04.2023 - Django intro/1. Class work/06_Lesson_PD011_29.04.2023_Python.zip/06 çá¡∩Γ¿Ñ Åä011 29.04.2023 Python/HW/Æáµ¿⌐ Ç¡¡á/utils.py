# вывод меню из словаря menu_task, выбор в меню и выполнение команд меню
import main
from datetime import datetime as dt


def do_menu(menu_task, title):
    while True:
        try:

            # вывести меню
            print(title)
            for key, value in menu_task.items():
                print(f'\t \033[34;1m{key}\033[0m. {value[0]}')
            # end for

            # ввести команду меню
            cmd = input('\t    Введите команду: ')

            # специальная команда - выход из цикла
            # обработки меню
            if cmd == '0':
                print()
                break
            # end if

            # выполнить команду меню, если команды нет - сообщить об ошибке
            if cmd in menu_task:
                menu_task[cmd][1]()
            else:
                raise Exception("нет такого пункта меню")
            # end if
        except Exception as e:
            print(f'\n\t\033[31;1mОшибка: {e}\033[0m\n')
        # end try-except
    # end while


# end do_menu


# выводим список
def show(title, data, header, footer):
    # вывод заголовка таблицы
    print(f'\t\t{title}\n{header}')

    # вывод основной части таблицы
    for item in data:
        print(f'{item}')

    # вывод подвала таблицы
    print(f'{footer}\n')


# запуск главной функции приложения
if __name__ == '__main__':
    main.main()


# Метод класса datetime strptime() принимает в качестве одного из аргументов строку и создает на основе её объект типа
# datetime.
def convert_date_from_str(date):
    return dt.strptime(date, '%Y-%m-%d')


def convert_date_from_str_2(date):
    return dt.strptime(date, '%d.%m.%Y')


# Метод strftime() преобразует объект типа datetime в строку.
def convert_str_from_date(date):
    return date.strftime('%d.%m.%Y')


def convert_str_from_date_2(date):
    return date.strftime('%Y-%m-%d')
