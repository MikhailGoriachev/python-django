import main

if __name__ == '__main__':
    main.main()


terminate = "\033[0m"

bright_red = "\033[38;5;255m\033[48;5;124m"

white_green = "\033[38;5;16m\033[48;5;36m"

light_magenta = "\033[48;5;14m\033[38;5;16m"

blue_25 = "\033[48;5;25m"

red_161_light = "\033[48;5;161m"

blue_back_highlight = "\033[48;5;69m\033[38;5;16m"
blue_white_highlight = "\033[48;5;69m"

green_back_highlight = "\033[48;5;35m\033[38;5;16m"

color_info = "\033[48;5;12m\033[38;5;16m"
