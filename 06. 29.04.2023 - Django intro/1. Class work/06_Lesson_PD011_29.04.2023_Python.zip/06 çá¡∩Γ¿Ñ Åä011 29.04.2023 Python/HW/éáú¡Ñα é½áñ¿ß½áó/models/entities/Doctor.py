from models.entities.Person import Person
from models.entities.Speciality import Speciality


class Doctor:

    header = "┌───────┬──────────────────────┬─────────────────────┬──────────────────────┬──────────────────┐\n" \
             "│  Id   │        ФИО           │    Специальность    │   Стоимость приема   │   % отчислений   │\n"\
             "├───────┼──────────────────────┼─────────────────────┼──────────────────────┼──────────────────┤\n"
    footer = "└───────┴──────────────────────┴─────────────────────┴──────────────────────┴──────────────────┘"

    # конструктор
    def __init__(self, doctor_id, person, speciality, price, percent):

        self.__id = doctor_id

        self.person = person
        self.doc_speciality = speciality
        self.price = price
        self.percent = percent

    # region Accessors
    # id
    @property
    def id(self):
        return self.__id

    # персоны
    @property
    def person(self):
        return self.__person

    @person.setter
    def person(self, person):
        if person is None or not isinstance(person, Person):
            raise AttributeError("Справочная сущность Person в Doctor задана некорректно!")

        self.__person = person

    # специальность
    @property
    def doc_speciality(self):
        return self.__doc_speciality

    @doc_speciality.setter
    def doc_speciality(self, speciality):
        if speciality is None or not isinstance(speciality, Speciality):
            raise AttributeError("Справочная сущность Speciality в Doctor задана некорректно!")

        self.__doc_speciality = speciality

    # стоимость приёма у врача
    @property
    def price(self):
        return self.__price

    @price.setter
    def price(self, price):
        if price <= 0 or not isinstance(price, int):
            raise AttributeError("Стоимость приёма задана некорректно!")

        self.__price = price

    # % отчислений врачу
    @property
    def percent(self):
        return self.__percent

    @percent.setter
    def percent(self, percent):
        if percent <= 0:
            raise AttributeError("% отчислений врачу задан некорректно!")

        self.__percent = percent

    # endregion

    def __str__(self) -> str:
        return f"id: {self.__id}\n ФИО: {self.__person.surname}.{self.__person.name[0]}.{self.__person.patronymic[0]}\n" \
               f" Специальность: {self.__doc_speciality.speciality}\n стоимость приёма: {self.__price}\n" \
               f" % отчислений: {self.__percent}\n"

    def to_table_row(self):
        snp = f"{self.__person.surname}.{self.__person.name[0]}.{self.__person.patronymic[0]}"
        return f"|{self.__id: ^7}| {snp: <20} | {self.__doc_speciality.speciality: <19} | {self.__price: >20} | {self.__percent: >16.3f} |\n"

