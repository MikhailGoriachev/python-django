from datetime import datetime

import utils
from models.entities.Person import Person
from models.entities.Speciality import Speciality


class Patient:

    header = "┌───────┬──────────────────────┬─────────────────────┬──────────────────────────────────┬──────────────────┐\n" \
             "│  Id   │     ФИО пациента     │    дата рождения    │          адрес пациента          │ паспорт пациента │\n"\
             "├───────┼──────────────────────┼─────────────────────┼──────────────────────────────────┼──────────────────┤\n"
    footer = "└───────┴──────────────────────┴─────────────────────┴──────────────────────────────────┴──────────────────┘"

    # конструктор
    def __init__(self, doctor_id, person, birth_date, address, passport):

        self.__id = doctor_id

        self.__person = person
        self.__birth_date = datetime.strptime(birth_date, utils.db_date_format)
        self.__address = address
        self.__passport = passport

    # region Accessors
    # id
    @property
    def id(self):
        return self.__id

    # персоны
    @property
    def person(self):
        return self.__person

    @person.setter
    def person(self, person):
        if person is None or not isinstance(person, Person):
            raise AttributeError("Справочная сущность Person в Doctor задана некорректно!")

        self.__person = person

    # дата рождения
    @property
    def birth_date(self):
        return self.__birth_date

    @birth_date.setter
    def birth_date(self, birth_date):
        if birth_date is None or not isinstance(birth_date, datetime):
            raise AttributeError("Дата рождения пациента задана некорректно!")

        self.__birth_date = birth_date

    # адрес проживания
    @property
    def address(self):
        return self.__address

    @address.setter
    def address(self, address):
        if not address:
            raise AttributeError("Адрес задан некорректно!")

        self.__address = address

    # паспорт пациента
    @property
    def passport(self):
        return self.__passport

    @passport.setter
    def passport(self, passport):
        if not passport:
            raise AttributeError("Паспорт пациента задан некорректно!")

        self.__passport = passport

    # endregion

    def __str__(self) -> str:
        return f"id: {self.__id}\n ФИО: {self.__person.surname}.{self.__person.name[0]}.{self.__person.patronymic[0]}\n" \
               f" дата рождения: {self.__birth_date.strftime(utils.date_format)}\n адрес проживания: {self.__address}\n" \
               f" паспорт: {self.__passport}\n"

    def to_table_row(self):
        snp = f"{self.__person.surname}.{self.__person.name[0]}.{self.__person.patronymic[0]}"
        return f"|{self.__id: ^7}| {snp: <20} | {self.__birth_date.strftime(utils.date_format): <19} | {self.__address: <32} | {self.__passport: <16} |\n"

