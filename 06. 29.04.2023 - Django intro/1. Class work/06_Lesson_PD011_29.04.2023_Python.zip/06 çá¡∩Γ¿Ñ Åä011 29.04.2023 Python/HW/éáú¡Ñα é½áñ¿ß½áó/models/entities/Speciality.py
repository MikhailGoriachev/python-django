
class Speciality:

    header = "┌───────┬─────────────────────────┐\n" \
             "│  Id   │      Специальность      │\n"\
             "├───────┼─────────────────────────┤\n"
    footer = "└───────┴─────────────────────────┘"

    last_id = 0

    # конструктор
    def __init__(self, speciality_id, speciality):

        # Задать id
        self.__id = speciality_id

        self.__speciality = speciality

    # region Accessors

    # id специальности
    @property
    def id(self):
        return self.__id

    # Специальность
    @property
    def speciality(self):
        return self.__speciality

    @speciality.setter
    def speciality(self, speciality):
        if speciality is None or speciality == "":
            raise AttributeError("Специальность задана некорректно!")

        self.__speciality = speciality
    # endregion

    def __str__(self) -> str:
        return f"id: {self.__id}\n Специальность: {self.__speciality}\n"

    def to_table_row(self, color=""):
        return f"|{self.__id: ^7}| {self.__speciality: <23} |\n"

