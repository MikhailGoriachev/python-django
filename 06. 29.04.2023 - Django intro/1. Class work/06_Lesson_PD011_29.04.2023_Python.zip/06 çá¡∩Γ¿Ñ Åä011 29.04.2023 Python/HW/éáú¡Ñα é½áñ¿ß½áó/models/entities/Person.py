class Person:

    header = "┌───────┬────────────────────┬──────────────────┬────────────────────┐\n" \
             "│  Id   │      Фамилия       │       Имя        │      Отчество      │\n"
    footer = "└───────┴────────────────────┴──────────────────┴────────────────────┘"

    # конструктор
    def __init__(self, person_id, surname, name, patronymic):

        self.__id = person_id

        self.__surname = surname
        self.__name = name
        self.__patronymic = patronymic

    # region Accessors
    # id
    @property
    def id(self):
        return self.__id

    # фамилия
    @property
    def surname(self):
        return self.__surname

    @surname.setter
    def surname(self, surname):
        if surname is None or surname == "":
            raise AttributeError("Фамилия задана некорректно!")

        self.__surname = surname

    # имя
    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, name):
        if name is None or name == "":
            raise AttributeError("Имя задано некорректно!")

        self.__name = name

    # отчество
    @property
    def patronymic(self):
        return self.__patronymic

    @patronymic.setter
    def patronymic(self, patronymic):
        if patronymic is None or patronymic == "":
            raise AttributeError("Отчество задано некорректно!")

        self.__patronymic = patronymic

    # endregion

    def __str__(self) -> str:
        return f"id: {self.__id}\n Фамилия: {self.__surname}\n" \
               f" Имя: {self.__name}\n Отчество: {self.__patronymic}\n"

    def to_table_row(self):
        return f"|{self.__id: ^7}| {self.__surname: <18} | {self.__name: <16} | {self.__patronymic: <18} |\n"

