from datetime import datetime

import utils
from models.entities.Doctor import Doctor
from models.entities.Patient import Patient
from models.entities.Person import Person
from models.entities.Speciality import Speciality


class Appointment:

    header = "┌──────┬─────────────────────┬──────────────────────┬─────────────────┬──────────────────┬──────────────┬──────────────────────┬─────────────────────┬──────────────────────────────────┬──────────────────┐\n" \
             "│  Id  │    дата приёма      │     ФИО доктора      │  Специальность  │ Стоимость приема │ % отчислений │     ФИО пациента     │    дата рождения    │          адрес пациента          │ паспорт пациента │\n"\
             "├──────┼─────────────────────┼──────────────────────┼─────────────────┼──────────────────┼──────────────┼──────────────────────┼─────────────────────┼──────────────────────────────────┼──────────────────┤\n"

    footer = "└──────┴─────────────────────┴──────────────────────┴─────────────────┴──────────────────┴──────────────┴──────────────────────┴─────────────────────┴──────────────────────────────────┴──────────────────┘"

    # конструктор
    def __init__(self, doctor_id, doctor, patient, appointment_date):

        self.__id = doctor_id

        self.__doctor = doctor
        self.__patient = patient
        self.__appointment_date = datetime.strptime(appointment_date, utils.db_date_format)

    # region Accessors
    # id
    @property
    def id(self):
        return self.__id

    # доктор
    @property
    def doctor(self):
        return self.__doctor

    @doctor.setter
    def doctor(self, doctor):
        if doctor is None or not isinstance(doctor, Doctor):
            raise AttributeError("Справочная сущность Doctor в Appointment задана некорректно!")

        self.__doctor = doctor

    # пациент
    @property
    def patient(self):
        return self.__patient

    @patient.setter
    def patient(self, patient):
        if patient is None or not isinstance(patient, Patient):
            raise AttributeError("Справочная сущность Patient в Appointment задана некорректно!")

        self.__patient = patient

    # дата приёма
    @property
    def appointment_date(self):
        return self.__appointment_date

    @appointment_date.setter
    def appointment_date(self, appointment_date):
        if appointment_date is None or not isinstance(appointment_date, datetime):
            raise AttributeError("Дата приёма задана некорректно!")

        self.__appointment_date = appointment_date

    # endregion

    def __str__(self) -> str:

        doctor_snp = f"{self.__doctor.person.surname}.{self.__doctor.person.name[0]}.{self.__doctor.person.patronymic[0]}"
        patient_snp = f"{self.__patient.person.surname}.{self.__patient.person.name[0]}.{self.__patient.person.patronymic[0]}"

        return f"id: {self.__id} \n дата приёма: {self.__appointment_date.strftime(utils.date_format)}" \
               f"\n ФИО доктора: {doctor_snp}\n" \
               f"\n специальность доктора: {self.__doctor.doc_speciality.speciality}" \
               f"\n стоимость приема: {self.__doctor.price}" \
               f"\n % отчислений доктору: {self.__doctor.percent}" \
               f"\n ФИО пациента: {patient_snp}" \
               f"\n адрес пациента: {self.__patient.address}\n" \
               f" паспорт: {self.__patient.passport}\n"

    # Вывод значений в строку таблицы
    def to_table_row(self):
        doctor_snp = f"{self.__doctor.person.surname}.{self.__doctor.person.name[0]}.{self.__doctor.person.patronymic[0]}"
        patient_snp = f"{self.__patient.person.surname}.{self.__patient.person.name[0]}.{self.__patient.person.patronymic[0]}"

        return f"|{self.__id: ^6}| {self.__appointment_date.strftime(utils.date_format): <19} " \
               f"| {doctor_snp: <20} | {self.__doctor.doc_speciality.speciality: <15} " \
               f"| {self.__doctor.price: <16} | {self.__doctor.percent: >12.3f} " \
               f"| {patient_snp: <20} | {self.__patient.birth_date.strftime(utils.date_format): <19} " \
               f"| {self.__patient.address: <32} | {self.__patient.passport: <16} |\n"

