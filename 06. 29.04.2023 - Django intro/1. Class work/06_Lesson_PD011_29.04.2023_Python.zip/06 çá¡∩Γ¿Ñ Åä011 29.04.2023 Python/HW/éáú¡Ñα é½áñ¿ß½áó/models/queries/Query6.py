from datetime import datetime

import utils
from models.entities.Person import Person
from models.entities.Speciality import Speciality


class Query6:

    header = "┌────────────────┬────────────────────┬───────────────────────────────┐\n" \
             "│  Дата приема   │ Количество записей │ Максимальная стоимость приема │\n"\
             "├────────────────┼────────────────────┼───────────────────────────────┤\n"
    footer = "└────────────────┴────────────────────┴───────────────────────────────┘"

    # конструктор
    def __init__(self, appointment_date, amount, max_price):

        self.appointment_date = datetime.strptime(appointment_date, utils.db_date_format)
        self.amount = amount
        self.max_price = max_price

    # region Accessors

    # дата приёма
    @property
    def appointment_date(self):
        return self.__appointment_date

    @appointment_date.setter
    def appointment_date(self, appointment_date):
        if appointment_date is None or not isinstance(appointment_date, datetime):
            raise AttributeError("Дата приёма задана некорректно!")

        self.__appointment_date = appointment_date

    # количество записей
    @property
    def amount(self):
        return self.__amount

    @amount.setter
    def amount(self, amount):
        if amount <= 0:
            raise AttributeError("Количество записей в Query 6 задано некорректно!")

        self.__amount = amount

    # максимальная стоимость приема
    @property
    def max_price(self):
        return self.__max_price

    @max_price.setter
    def max_price(self, max_price):
        if max_price <= 0:
            raise AttributeError("Максимальная стоимость приема в Query 6 задана некорректно!")

        self.__max_price = max_price

    # endregion

    def __str__(self) -> str:
        return f" Дата приема: {self.__appointment_date}\n" \
               f" Количество записей: {self.__amount}\n" \
               f" Максимальная стоимость приема: {self.__max_price.speciality}\n"

    def to_table_row(self):
        return f"| {self.__appointment_date.strftime(utils.date_format): ^14} | {self.__amount: >18} | {self.__max_price: >29} |\n"

