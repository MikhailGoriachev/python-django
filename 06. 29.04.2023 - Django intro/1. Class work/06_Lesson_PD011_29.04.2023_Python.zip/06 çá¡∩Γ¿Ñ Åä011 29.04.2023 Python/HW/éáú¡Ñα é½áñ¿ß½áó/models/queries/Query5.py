from datetime import datetime

import utils
from models.entities.Person import Person
from models.entities.Speciality import Speciality


class Query5:

    header = "┌────────────┬────────────────┬──────────────────┬──────────────────┬──────────────────┬─────────────────────┬──────────────────┬──────────────┬──────────────────┐\n" \
             "│ Id приема  │  Дата приема   │  Фамилия врача   │     Имя врача    │  Отчество врача  │    Специальность    │ Стоимость приема │ % отчислений │     Зарплата     │\n"\
             "├────────────┼────────────────┼──────────────────┼──────────────────┼──────────────────┼─────────────────────┼──────────────────┼──────────────┼──────────────────┤\n"
    footer = "└────────────┴────────────────┴──────────────────┴──────────────────┴──────────────────┴─────────────────────┴──────────────────┴──────────────┴──────────────────┘"

    # конструктор
    def __init__(self, appointment_id, appointment_date, person, speciality, price, percent, salary):

        self.__appointment_id = appointment_id
        self.appointment_date = datetime.strptime(appointment_date, utils.db_date_format)
        self.person = person
        self.doc_speciality = speciality
        self.price = price
        self.salary = salary
        self.percent = percent

    # region Accessors

    @property
    def appointment_id(self):
        return self.__appointment_id

    # дата приёма
    @property
    def appointment_date(self):
        return self.__appointment_date

    @appointment_date.setter
    def appointment_date(self, appointment_date):
        if appointment_date is None or not isinstance(appointment_date, datetime):
            raise AttributeError("Дата приёма задана некорректно!")

        self.__appointment_date = appointment_date

    # персоны
    @property
    def person(self):
        return self.__person

    @person.setter
    def person(self, person):
        if person is None or not isinstance(person, Person):
            raise AttributeError("Справочная сущность Person в Query 5 задана некорректно!")

        self.__person = person

    # специальность
    @property
    def doc_speciality(self):
        return self.__doc_speciality

    @doc_speciality.setter
    def doc_speciality(self, speciality):
        if speciality is None or not isinstance(speciality, Speciality):
            raise AttributeError("Справочная сущность Speciality в Doctor задана некорректно!")

        self.__doc_speciality = speciality

    # стоимость приёма у врача
    @property
    def price(self):
        return self.__price

    @price.setter
    def price(self, price):
        if price <= 0 or not isinstance(price, int):
            raise AttributeError("Стоимость приёма задана некорректно!")

        self.__price = price

    # зарплата
    @property
    def salary(self):
        return self.__salary

    @salary.setter
    def salary(self, salary):
        if salary <= 0:
            raise AttributeError("Зарплата врача задана некорректно!")

        self.__salary = salary

    # % отчислений врачу
    @property
    def percent(self):
        return self.__percent

    @percent.setter
    def percent(self, percent):
        if percent <= 0:
            raise AttributeError("% отчислений врачу задан некорректно!")

        self.__percent = percent

    # endregion

    def __str__(self) -> str:
        return f" id приема: {self.__appointment_id}\n" \
               f" ФИО: {self.__person.surname}.{self.__person.name[0]}.{self.__person.patronymic[0]}\n" \
               f" Специальность: {self.__doc_speciality.speciality}\n Стоимость приёма: {self.__price}\n" \
               f" % отчислений: {self.__percent}\n Зарплата врача: {self.__salary}\n"

    def to_table_row(self):
        return f"| {self.__appointment_id: ^10} | {self.__appointment_date.strftime(utils.date_format): <14} | {self.__person.surname: <16} | {self.__person.name: <16} | {self.__person.patronymic: <16} " \
               f"| {self.__doc_speciality.speciality: <19} | {self.__price: >16} | {self.__percent: >11.2f}% | {self.__salary: >16.2f} |\n"

