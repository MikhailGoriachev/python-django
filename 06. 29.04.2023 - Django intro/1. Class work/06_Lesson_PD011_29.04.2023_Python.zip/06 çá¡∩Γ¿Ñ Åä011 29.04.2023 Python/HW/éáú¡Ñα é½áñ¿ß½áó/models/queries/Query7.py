from datetime import datetime

import utils
from models.entities.Person import Person
from models.entities.Speciality import Speciality


class Query7:

    header = "┌─────────────────┬────────────────────┬──────────────────────┐\n" \
             "│  Специальность  │ Количество записей │ Средний % отчислений │\n"\
             "├─────────────────┼────────────────────┼──────────────────────┤\n"
    footer = "└─────────────────┴────────────────────┴──────────────────────┘"

    # конструктор
    def __init__(self, speciality, amount, avg_percent):

        self.doc_speciality = speciality
        self.amount = amount
        self.avg_percent = avg_percent

    # region Accessors

    # дата приёма
    @property
    def doc_speciality(self):
        return self.__doc_speciality

    @doc_speciality.setter
    def doc_speciality(self, speciality):
        if speciality is None or not isinstance(speciality, Speciality):
            raise AttributeError("Специальность задана некорректно!")

        self.__doc_speciality = speciality

    # количество записей
    @property
    def amount(self):
        return self.__amount

    @amount.setter
    def amount(self, amount):
        if amount <= 0:
            raise AttributeError("Количество записей в Query 6 задано некорректно!")

        self.__amount = amount

    # максимальная стоимость приема
    @property
    def avg_percent(self):
        return self.__avg_percent

    @avg_percent.setter
    def avg_percent(self, avg_percent):
        if avg_percent <= 0:
            raise AttributeError("Средний % отчислений в Query 7 задан некорректно!")

        self.__avg_percent = avg_percent

    # endregion

    def __str__(self) -> str:
        return f" Специальность доктора: {self.__doc_speciality.speciality}\n" \
               f" Количество записей: {self.__amount}\n" \
               f" Средний % отчислений: {self.__avg_percent.speciality}\n"

    def to_table_row(self):
        return f"| {self.__doc_speciality.speciality: ^15} | {self.__amount: >18} | {self.__avg_percent: >19}% |\n"

