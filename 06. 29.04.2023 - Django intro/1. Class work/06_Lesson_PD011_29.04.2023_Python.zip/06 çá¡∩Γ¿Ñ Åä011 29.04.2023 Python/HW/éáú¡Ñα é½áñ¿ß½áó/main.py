import console_colors
from controllers.QueriesController import QueriesController
from controllers.TablesController import TablesController


def main():
    main_menu_dict = {
        "1": ["1 - запросы",  QueriesController().start],
        "2": ["2 - таблицы",        TablesController().start],
        "0": ["0 - выход\n", exit]
    }

    while True:

        try:
            tasks = ""

            for value in main_menu_dict.values():
                tasks += f"\n{value[0]}"

            # Выбрать номер задачи
            task_number = input(f"{tasks}\nВведите номер задачи: ")

            if task_number == "0":
                exit(0)

            # Нахождение элемента словаря и вызов метода
            main_menu_dict.get(task_number)[1]()

        except Exception as e:
            print(
                f"\n\nПри выполнении операции возникло исключение: {console_colors.bright_red} {e} {console_colors.terminate} \n")

    # end while


# end main


if __name__ == '__main__':
    main()
