import console_colors
import utils
from models.entities.Appointment import Appointment
from models.entities.Doctor import Doctor
from models.entities.Patient import Patient
from models.entities.Speciality import Speciality

from repositories.AppointmentsRepository import AppointmentsRepository
from repositories.DoctorsRepository import DoctorsRepository
from repositories.PatientsRepository import PatientsRepository


class TablesController:

    # конструктор
    def __init__(self):

        # репозитории для выполнения запросов к таблицам
        self.__appointments_repository = AppointmentsRepository()
        self.__doctors_repository = DoctorsRepository()
        self.__patients_repository = PatientsRepository()

    # запуск задач и вывод меню
    def start(self):

        queries_menu = {
            "1": [" - таблица приемов. ",        self.appointments],
            "2": [" - таблица докторов. ",       self.doctors],
            "3": [" - таблица пациентов. ",      self.patients],
            "4": [" - таблица специальностей. ", self.specialities],
            "0": [" - выход\n", None]
        }

        # Формирование меню
        while True:

            tasks = ""

            for key, values in queries_menu.items():
                tasks += f"\n{key}{values[0]}"

            result = input(f"{tasks}\nВведите номер пункта для выборки из таблицы: ")

            if result == '0':
                return

            if result not in queries_menu.keys():
                print(f"\nНомер запроса введён неверно. "
                      f"{console_colors.color_info}Задайте значения в диапазоне 1 - 4{console_colors.terminate}")
                continue

            queries_menu.get(result)[1]()

        # end while

    # Приёмы
    def appointments(self):
        print("\nВывод таблицы приемов")

        appointments = self.__appointments_repository.get_all()
        utils.show_objects(appointments, Appointment.header, Appointment.footer)

        # ожидать нажатия клавиши
        utils.wait_for_enter_press()

    # Доктора
    def doctors(self):
        print("\nВывод таблицы докторов")

        doctors = self.__doctors_repository.get_all()
        utils.show_objects(doctors, Doctor.header, Doctor.footer)

        # ожидать нажатия клавиши
        utils.wait_for_enter_press()

    # Пациенты
    def patients(self):
        print("\nВывод таблицы пациентов")

        patients = self.__patients_repository.get_all()
        utils.show_objects(patients, Patient.header, Patient.footer)

        # ожидать нажатия клавиши
        utils.wait_for_enter_press()

    # Специальности
    def specialities(self):
        print("\nВывод таблицы специальностей")

        specialities = self.__doctors_repository.get_all_specialities()
        utils.show_objects(specialities, Speciality.header, Speciality.footer)

        # ожидать нажатия клавиши
        utils.wait_for_enter_press()

