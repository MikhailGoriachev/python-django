import datetime
import console_colors
import utils

from models.entities.Appointment import Appointment
from models.entities.Doctor import Doctor
from models.entities.Patient import Patient
from models.queries.Query5 import Query5
from models.queries.Query6 import Query6
from models.queries.Query7 import Query7

from repositories.AppointmentsRepository import AppointmentsRepository
from repositories.PatientsRepository import PatientsRepository
from repositories.DoctorsRepository import DoctorsRepository


class QueriesController:

    # конструктор
    def __init__(self):

        # репозитории для выполнения запросов
        self.__appointments_repository = AppointmentsRepository()
        self.__doctors_repository = DoctorsRepository()
        self.__patients_repository = PatientsRepository()

    # запуск задач и вывод меню
    def start(self):

        queries_menu = {
            "1": [" - запрос 1. ", self.query_1],
            "2": [" - запрос 2. ", self.query_2],
            "3": [" - запрос 3. ", self.query_3],
            "4": [" - запрос 4. ", self.query_4],
            "5": [" - запрос 5. ", self.query_5],
            "6": [" - запрос 6. ", self.query_6],
            "7": [" - запрос 7. ", self.query_7],
            "0": [" - выход\n", None]
        }

        # Формирование меню
        while True:

            tasks = ""

            for key, values in queries_menu.items():
                tasks += f"\n{key}{values[0]}"

            result = input(f"{tasks}\nВведите номер запроса: ")

            if result == '0':
                return

            if result not in queries_menu.keys():
                print(f"\nНомер запроса введён неверно. "
                      f"{console_colors.color_info}Задайте значения в диапазоне 1 - 7{console_colors.terminate}")
                continue

            queries_menu.get(result)[1]()

        # end while

    # Запрос 1: Выбирает информацию о пациентах с фамилиями,
    # начинающимися на заданную параметром последовательность букв
    def query_1(self):

        patients, surname = self.__patients_repository.query_1()

        print(f"\nПациенты с фамилиями начинающимися на {surname}")
        utils.show_objects(patients, Patient.header, Patient.footer)

        # ожидать нажатия клавиши
        utils.wait_for_enter_press()

    # Запрос 2: Выбирает информацию о врачах, для которых значение в поле
    # Процент отчисления на зарплату, больше 2.3%
    def query_2(self):

        percent = 2.3
        doctors = self.__doctors_repository.query_2(percent)

        print(f"\nДоктора с % отчислений на зарплату > {percent:.2f}%")
        utils.show_objects(doctors, Doctor.header, Doctor.footer)

        # ожидать нажатия клавиши
        utils.wait_for_enter_press()

    # Запрос 3: Выбирает информацию о приемах за некоторый период, заданный параметрами
    def query_3(self):

        # параметры для запроса
        date_lo = datetime.datetime.strptime("01.10.2021", utils.date_format)
        date_hi = datetime.datetime.strptime("01.09.2022", utils.date_format)

        # Выполнить запрос с переданными параметрами даты
        appointments = self.__appointments_repository.query_3(date_lo.strftime(utils.db_date_format), date_hi.strftime(utils.db_date_format))

        # Вывод полученной коллекции
        print(f"\nПриемы с датой в диапазоне от {console_colors.blue_back_highlight} {date_lo.strftime(utils.date_format)} {console_colors.terminate}"
              f" до {console_colors.blue_back_highlight} {date_hi.strftime(utils.date_format)} {console_colors.terminate}")
        utils.show_objects(appointments, Appointment.header, Appointment.footer)

        # ожидать нажатия клавиши
        utils.wait_for_enter_press()

    # Запрос 4: Выбирает информацию о докторах, специальность которых задана параметром
    def query_4(self):

        doctors, speciality = self.__doctors_repository.query_4()

        # Вывод полученной коллекции
        print(f"\nДоктора со специальностью '{speciality}'")
        utils.show_objects(doctors, Doctor.header, Doctor.footer)

        # ожидать нажатия клавиши
        utils.wait_for_enter_press()

    # Запрос 5: Вычисляет размер заработной платы врача за каждый прием
    def query_5(self):
        result = self.__appointments_repository.query_5()

        # Вывод полученной коллекции
        print(f"\nЗапрос 5: вычисляемые поля")
        utils.show_objects(result, Query5.header, Query5.footer)

        # ожидать нажатия клавиши
        utils.wait_for_enter_press()

    # Запрос 6: Выполняет группировку по полю Дата приема.
    # Для каждой даты вычисляет максимальную стоимость приема
    def query_6(self):
        result = self.__appointments_repository.query_6()

        # Вывод полученной коллекции
        print(f"\nЗапрос 6: группировка по полю дата приема")
        utils.show_objects(result, Query6.header, Query6.footer)

        # ожидать нажатия клавиши
        utils.wait_for_enter_press()

    # Запрос 7: Выполняет группировку по полю Специальность.
    # Для каждой специальности вычисляет средний Процент отчисления на зарплату от стоимости приема
    def query_7(self):
        result = self.__appointments_repository.query_7()

        # Вывод полученной коллекции
        print(f"\nЗапрос 7: группировка по полю cпециальность")
        utils.show_objects(result, Query7.header, Query7.footer)

        # ожидать нажатия клавиши
        utils.wait_for_enter_press()
