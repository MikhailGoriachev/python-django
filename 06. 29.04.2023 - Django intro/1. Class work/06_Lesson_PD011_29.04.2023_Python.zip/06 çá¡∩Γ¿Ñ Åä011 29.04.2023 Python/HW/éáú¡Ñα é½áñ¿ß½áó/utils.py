import random

import main
import console_colors

if __name__ == '__main__':
    main.main()

date_format = "%d.%m.%Y"
db_date_format = "%Y-%m-%d"

def get_random_float(lo, hi):
    if lo > hi:
        return 0

    return random.uniform(lo, hi)


# end get_random_float


def get_random_int(lo, hi):
    if lo > hi:
        return 0

    return random.randrange(lo, hi)


# end get_random_int


# Сгенерировать список целых чисел
def generate_int_list(size, lo, hi):
    generating_list = []

    for i in range(size):
        generating_list.append(get_random_int(lo, hi))

    # end for

    return generating_list


# Сгенерировать множество целых чисел
def generate_int_set(size, lo, hi):
    generating_set = set()

    while len(generating_set) < size:
        generating_set.add(get_random_int(lo, hi))

    # end while

    return generating_set


# Сгенерировать список вещественных чисел
def generate_float_list(size, lo, hi):
    generating_list = []

    for i in range(size):
        generating_list.append(get_random_float(lo, hi))

    # end for

    return generating_list


def show_container(source, line_break_count=15):
    if len(source) == 0:
        print("\nВ контейнере нет значений!")
        return

    list_str = ""

    index = 0
    # Выделить повторяющиеся элементы
    for item in source:
        line_break = "\n\n" if (index + 1) % line_break_count == 0 and (index + 1) < len(source) else ""

        list_str += f" {console_colors.light_magenta} " \
                    f"{item: ^3} {console_colors.terminate}{line_break}"

        index += 1

    # end for

    print(list_str)


def show_dictionary(source):
    if len(source) == 0:
        print("\nВ словаре нет значений!")
        return

    dict_str = ""

    # Выделить повторяющиеся элементы
    for key in source:
        dict_str += f"{console_colors.light_magenta} " \
                    f"{key: ^3} {console_colors.terminate} - {source[key]}\n"

    # end for

    print(dict_str)


# Вывести коллекцию объектов
def show_objects(collection, header, footer):

    if len(collection) == 0:
        print("\nВ коллекции нет значений!")
        return

    list_str = header

    for item in collection:
        list_str += item.to_table_row()

    # end for

    print(f"{list_str}{footer}")


# Получить случайную фамилию пациента
def get_random_patient_surname(cursor):
    cursor.execute("""
    select 
        view_patients.patient_surname
    from 
    view_patients """)

    surnames = list()

    for surname in cursor:
        surnames.append(surname[0])

    if len(surnames) <= 0:
        return ""

    return surnames[get_random_int(0, len(surnames))]

# end get_random_patient_surname

# Получить случайную специальность доктора
def get_random_speciality(cursor):

    # Получить специальности, которые есть в таблице докторов
    cursor.execute("""
    select
        DISTINCT (view_doctors.speciality)
    from
    view_doctors""")

    specialities = list()

    for speciality in cursor:
        specialities.append(speciality[0])

    if len(specialities) <= 0:
        return ""

    return specialities[get_random_int(0, len(specialities))]

# end get_random_speciality


# Ожидать нажатия enter
def wait_for_enter_press(title="Для входа в меню нажмите enter..."):
    print(f"\n{title}")

    import keyboard
    keyboard.wait("enter", True)
