import sqlite3

import console_colors
import utils
from models.entities.Patient import Patient
from models.entities.Person import Person


# Репозиторий для выполнения запросов к таблице пациентов
class PatientsRepository:

    # конструктор
    def __init__(self):

        self.__db_path = "app_data/polyclinic.db"

    # Получение всех записей
    def get_all(self):
        connection = sqlite3.connect(self.__db_path)
        cursor = connection.cursor()

        query = """
            select
                *
            from
                view_patients"""

        cursor.execute(query)

        return self.read_patients_from_cursor(cursor)

    # Запрос 1: Выбирает информацию о пациентах с фамилиями,
    # начинающимися на заданную параметром последовательность букв
    def query_1(self):
        connection = sqlite3.connect(self.__db_path)
        cursor = connection.cursor()

        query = """select 
                    * 
                    from 
                        view_patients 
                    where view_patients.patient_surname like ?"""

        # получить случайную фамилию и из неё получить первые 2 буквы
        patient_surname = utils.get_random_patient_surname(cursor)[:2]

        cursor.execute(query, [patient_surname + "%"])

        # Вернуть список пациентов + параметр запроса
        return self.read_patients_from_cursor(cursor), patient_surname

    # end query_1

    # Получить коллекцию из курсора
    def read_patients_from_cursor(self, cursor):
        patients_list = []

        for (_id, patient_surname, patient_name, patient_patronymic, birth_date, address, passport) in cursor.fetchall():

            # Создать объект сущности
            patient = Patient(_id, Person(0, patient_surname, patient_name, patient_patronymic), birth_date, address, passport)

            patients_list.append(patient)

        return patients_list

