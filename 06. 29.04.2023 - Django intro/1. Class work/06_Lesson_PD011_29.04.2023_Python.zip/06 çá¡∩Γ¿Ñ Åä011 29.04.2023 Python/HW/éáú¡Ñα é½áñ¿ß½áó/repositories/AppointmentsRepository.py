import sqlite3

import console_colors
import utils
from models.entities.Doctor import Doctor
from models.entities.Patient import Patient
from models.entities.Person import Person
from models.entities.Speciality import Speciality
from models.entities.Appointment import Appointment
from models.queries.Query5 import Query5
from models.queries.Query6 import Query6
from models.queries.Query7 import Query7


# Репозиторий для выполнения запросов к таблице приемов
class AppointmentsRepository:

    # конструктор
    def __init__(self):

        self.__db_path = "app_data/polyclinic.db"

    # Получение всех записей
    def get_all(self):

        connection = sqlite3.connect(self.__db_path)
        cursor = connection.cursor()

        query = """
        select
            *
        from
            view_appointments"""

        cursor.execute(query)

        return self.read_appointments_from_cursor(cursor)

    # Запрос 3: Выбирает информацию о приемах за некоторый период, заданный параметрами
    def query_3(self, date_min_str, date_max_str):
        connection = sqlite3.connect(self.__db_path)
        cursor = connection.cursor()

        query = """select
                       *
                   from
                       view_appointments
                   where
                   view_appointments.appointment_date between ? and ?"""

        cursor.execute(query, [(date_min_str),(date_max_str)])

        return self.read_appointments_from_cursor(cursor)

    # Запрос 5: Вычисляет размер заработной платы врача за каждый прием
    def query_5(self):
        connection = sqlite3.connect(self.__db_path)
        cursor = connection.cursor()

        query = """
        select
              view_appointments._id
            , view_appointments.appointment_date
            , view_appointments.doctor_surname
            , view_appointments.doctor_name
            , view_appointments.doctor_patronymic
            , view_appointments.speciality
            , view_appointments.price
            , view_appointments.percent
            , view_appointments.price * percent / 100 - (view_appointments.price * percent / 100) * 0.13 as salary
        from
            view_appointments
        order by
            view_appointments.speciality;"""

        cursor.execute(query)

        return self.read_query_5_from_cursor(cursor)

    # Запрос 6: Выполняет группировку по полю Дата приема.
    # Для каждой даты вычисляет максимальную стоимость приема
    def query_6(self):
        connection = sqlite3.connect(self.__db_path)
        cursor = connection.cursor()

        query = """
        select
            view_appointments.appointment_date,
            count(*) as amount,
            max(view_appointments.price) as maxPrice
        from
            view_appointments
        group by
            view_appointments.appointment_date;"""

        cursor.execute(query)

        return self.read_query_6_from_cursor(cursor)

    # Запрос 7: Выполняет группировку по полю Специальность.
    # Для каждой специальности вычисляет средний Процент отчисления на зарплату от стоимости приема
    def query_7(self):
        connection = sqlite3.connect(self.__db_path)
        cursor = connection.cursor()

        query = """
        select
            view_appointments.speciality,
            count(*) as amount,
            avg(view_appointments.percent) as avgPercent
        from
            view_appointments
        group by
            view_appointments.speciality;"""

        cursor.execute(query)

        return self.read_query_7_from_cursor(cursor)

    # Получить коллекцию из курсора
    def read_appointments_from_cursor(self, cursor):
        appointments_list = []

        for (_id, app_date, doc_id, doc_surname, doc_name, doc_patronymic, speciality, price, percent,
             pat_id, pat_surname, pat_name, pat_patronymic, birth_date, address, passport) in cursor.fetchall():

            # Создать объект сущности доктора
            doctor = Doctor(doc_id, Person(0, doc_surname, doc_name, doc_patronymic), Speciality(0, speciality), price, percent)
            patient = Patient(pat_id, Person(0, pat_surname, pat_name, pat_patronymic), birth_date, address, passport)

            appointments_list.append(Appointment(_id, doctor, patient, app_date))

        return appointments_list

    # Получить коллекцию запроса 5 из курсора
    def read_query_5_from_cursor(self, cursor):
        query_5_list = []

        for (appointment_id, appointment_date, doc_surname, doc_name, doc_patronymic, speciality, price, percent, salary) in cursor.fetchall():

            # Создать объект сущности запроса 5
            query_5 = Query5(appointment_id, appointment_date,
                             Person(0, doc_surname, doc_name, doc_patronymic),
                             Speciality(0, speciality), price, percent, salary)

            query_5_list.append(query_5)

        query_5_list.sort(key=lambda query5: query5.appointment_id)
        return query_5_list

    # Получить коллекцию запроса 6 из курсора
    def read_query_6_from_cursor(self, cursor):
        query_6_list = []

        for (appointment_date, amount, max_price) in cursor.fetchall():

            # Создать объект сущности запроса 6
            query_6_list.append(Query6(appointment_date, amount, max_price))

        query_6_list.sort(key=lambda query6: query6.amount, reverse=True)
        return query_6_list

    # Получить коллекцию запроса 7 из курсора
    def read_query_7_from_cursor(self, cursor):
        query_7_list = []

        for (speciality, amount, avg_percent) in cursor.fetchall():

            speciality_entity = Speciality(0, speciality)
            # Создать объект сущности запроса 6
            query_7_list.append(Query7(speciality_entity, amount, avg_percent))

        query_7_list.sort(key=lambda query7: query7.amount, reverse=True)
        return query_7_list

