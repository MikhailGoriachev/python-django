import sqlite3

import console_colors
import utils
from models.entities.Doctor import Doctor
from models.entities.Person import Person
from models.entities.Speciality import Speciality


# Репозиторий для выполнения запросов к таблице пациентов
class DoctorsRepository:

    # конструктор
    def __init__(self):

        self.__db_path = "app_data/polyclinic.db"

    # Получение всех записей
    def get_all(self):

        connection = sqlite3.connect(self.__db_path)
        cursor = connection.cursor()

        query = """
            select
                *
            from
                view_doctors"""

        cursor.execute(query)

        return self.read_doctors_from_cursor(cursor)

    # Получение всех специальностей
    def get_all_specialities(self):

        connection = sqlite3.connect(self.__db_path)
        cursor = connection.cursor()

        query = """
            select
                *
            from
                specialities;"""

        cursor.execute(query)

        return self.read_specialities_from_cursor(cursor)

    # Запрос 2: Выбирает информацию о врачах, для которых значение в поле
    # Процент отчисления на зарплату, больше 2.3%
    def query_2(self, percent):
        connection = sqlite3.connect(self.__db_path)
        cursor = connection.cursor()

        query = """
        select
           *
        from
           view_doctors
        where
           view_doctors.percent > ?;
           """

        cursor.execute(query, [(percent)])

        # Получить список докторов из курсора
        return self.read_doctors_from_cursor(cursor)

    # Запрос 4: Выбирает информацию о докторах, специальность которых задана параметром
    def query_4(self):

        connection = sqlite3.connect(self.__db_path)
        cursor = connection.cursor()

        query = """
            select
                *
            from
                view_doctors
            where view_doctors.speciality like ?
           """

        speciality = utils.get_random_speciality(cursor)

        cursor.execute(query, [(speciality)])

        # Получить список докторов из курсора
        return self.read_doctors_from_cursor(cursor), speciality

    # Получить коллекцию из курсора
    def read_doctors_from_cursor(self, cursor):
        doctor_list = []

        for (_id, doc_surname, doc_name, doc_patronymic, speciality, price, percent) in cursor.fetchall():

            # Создать объект сущности
            doctor = Doctor(_id, Person(0, doc_surname, doc_name, doc_patronymic), Speciality(0, speciality), price, percent)

            doctor_list.append(doctor)

        return doctor_list

    # Прочитать специальности из курсора
    def read_specialities_from_cursor(self, cursor):
        specialities_list = []

        for (_id, speciality) in cursor.fetchall():
            specialities_list.append(Speciality(_id, speciality))

        return specialities_list

