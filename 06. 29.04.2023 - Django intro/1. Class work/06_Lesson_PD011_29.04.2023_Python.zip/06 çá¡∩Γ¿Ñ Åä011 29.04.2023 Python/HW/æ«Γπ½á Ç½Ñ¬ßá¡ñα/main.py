from controllers.TaskController import TaskController


def main():
    # запуск задания на выполнение
    TaskController().run()


if __name__ == '__main__':
    main()
