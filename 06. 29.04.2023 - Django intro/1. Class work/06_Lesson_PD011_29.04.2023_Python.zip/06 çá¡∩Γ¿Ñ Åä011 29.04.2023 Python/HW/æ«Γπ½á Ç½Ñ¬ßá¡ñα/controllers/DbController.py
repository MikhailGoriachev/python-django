import sqlite3

from models.Consultation import Consultation
from models.ConsultationView import ConsultationView
from models.ConsultationWithSalary import ConsultationWithSalary
from models.Doctor import Doctor
from models.GroupByDateWithMaxPrice import GroupByDateWithMaxPrice
from models.GroupBySpecialityWithAvgPercent import GroupBySpecialityWithAvgPercent
from models.Patient import Patient
from models.Person import Person
from models.Speciality import Speciality


class DbController:
    def __init__(self, db_path='app_data/polyclinic.db'):
        self.__cursor = sqlite3.connect(db_path).cursor()

    # персоны из таблицы
    def get_table_persons(self):
        # запрос
        sql_cmd = f"""
                        select
                            persons.id
                            , persons.surname
                            , persons.name
                            , persons.patronymic
                        from
                            persons
                            """

        # выполнение запроса
        cursor = self.__cursor.execute(sql_cmd)

        # пустой список персон для результатов выборки
        persons = []

        # результат выборки
        # помещаем в коллекцию
        for data in cursor.fetchall():
            persons.append(Person(data[0], data[1], data[2], data[3]))

        return persons

    # специальности из таблицы
    def get_table_specialties(self):
        # запрос
        sql_cmd = f"""
                        select
                            specialties.id
                            , specialties.title
                        from
                            specialties
                            """

        # выполнение запроса
        cursor = self.__cursor.execute(sql_cmd)

        # пустой список специальностей для результатов выборки
        specialties = []

        # результат выборки
        # помещаем в коллекцию
        for data in cursor.fetchall():
            specialties.append(Speciality(data[0], data[1]))

        return specialties

    # таблица пациенты
    def get_table_patients(self):
        # запрос
        sql_cmd = f"""
                    select
                        patients_view.id
                        , patients_view.surname
                        , patients_view.name
                        , patients_view.patronymic
                        , patients_view.birth_date
                        , patients_view.address
                    from
                        patients_view
                    """

        # выполнение запроса
        cursor = self.__cursor.execute(sql_cmd)

        # пустой список пациентов для результатов выборки
        patients = []

        # результат выборки
        # помещаем в коллекцию
        for data in cursor.fetchall():
            patients.append(Patient(data[0], data[1], data[2], data[3], data[4], data[5]))

        return patients

    # таблица врачей
    def get_table_doctors(self):
        # запрос
        sql_cmd = f"""
                    select
                        doctors_view.id
                        , doctors_view.surname
                        , doctors_view.name
                        , doctors_view.patronymic
                        , doctors_view.title
                        , doctors_view.percent
                        , doctors_view.price
                    from
                        doctors_view
                        """

        # выполнение запроса
        cursor = self.__cursor.execute(sql_cmd)

        # пустой список докторов для результатов выборки
        doctors = []

        # результат выборки
        # помещаем в коллекцию
        for data in cursor.fetchall():
            doctors.append(
                Doctor(data[0], data[1], data[2],
                       data[3], data[4], data[5],
                       data[6])
            )

        return doctors

    # таблица приемов
    def get_table_consultations(self):
        # запрос
        sql_cmd = f"""
                    select
                        consultations_view.id
                        , consultations_view.date
                        , consultations_view.doctor_surname
                         , consultations_view.doctor_name
                         , consultations_view.doctor_patronymic
                        , consultations_view.patient_surname
                         , consultations_view.patient_name
                         , consultations_view.patient_patronymic
                    from
                        consultations_view
                    """

        # выполнение запроса
        cursor = self.__cursor.execute(sql_cmd)

        # пустой список приемов для результатов выборки
        consultations = []

        # результат выборки
        # помещаем в коллекцию
        for data in cursor.fetchall():
            consultations.append(
                Consultation(data[0], data[1], data[2], data[3],
                             data[4], data[5], data[6], data[7])
            )

        return consultations

    # Выбирает информацию о пациентах с фамилиями,
    # начинающимися на заданную параметром последовательность букв
    def get_patients_by_surname(self, surname):
        # словарь параметров
        # https://docs.python.org/3/library/sqlite3.html#how-to-guides
        dict_params = ({'surname': surname + '%'})

        # запрос
        sql_cmd = f"""
                    select
                        patients_view.id
                        , patients_view.surname
                        , patients_view.name
                        , patients_view.patronymic
                        , patients_view.birth_date
                        , patients_view.address
                    from
                        patients_view
                    where
                        patients_view.surname like :surname
                    order by 
                        patients_view.surname
                        , patients_view.name
                        , patients_view.patronymic
                """

        # выполнение запроса
        cursor = self.__cursor.execute(sql_cmd, dict_params)

        # пустой список пациентов для результатов выборки
        patients = []

        # результат выборки
        # помещаем в коллекцию
        for data in cursor.fetchall():
            patients.append(Patient(data[0], data[1], data[2], data[3], data[4], data[5]))

        return patients

    # Выбирает информацию о врачах, для которых значение в
    # поле Процент отчисления на зарплату, больше 2.3% (задавать параметром)

    def get_doctors_by_percent(self, percent):
        # словарь параметров
        dict_params = ({'percent': percent})

        # запрос
        sql_cmd = f"""
                    select
                        doctors_view.id
                        , doctors_view.surname
                        , doctors_view.name
                        , doctors_view.patronymic
                        , doctors_view.title
                        , doctors_view.percent
                        , doctors_view.price
                    from
                        doctors_view
                    where
                        doctors_view.percent > :percent
                    order by 
                        doctors_view.surname
                        , doctors_view.name
                        , doctors_view.patronymic
                        , doctors_view.title
                        , doctors_view.percent
                        , doctors_view.price
                """

        # выполнение запроса
        cursor = self.__cursor.execute(sql_cmd, dict_params)

        # пустой список докторов для результатов выборки
        doctors = []

        # результат выборки
        # помещаем в коллекцию
        for data in cursor.fetchall():
            doctors.append(
                Doctor(data[0], data[1], data[2],
                       data[3], data[4], data[5],
                       data[6])
            )

        return doctors

    # Выбирает информацию о приемах за некоторый период, заданный параметрами
    def get_consultations_by_range_date(self, start_date, end_date):
        # словарь параметров
        dict_params = (
            {'start_date': start_date, 'end_date': end_date}
        )

        # запрос
        sql_cmd = f"""
                    select
                        consultations_view.id
                        , consultations_view.date
                        , consultations_view.speciality_title
                        , consultations_view.doctor_surname || ' ' ||
                         substr(consultations_view.doctor_name, 1, 1) || '.' ||
                         substr(consultations_view.doctor_patronymic, 1, 1) || '.'
                        , consultations_view.patient_surname || ' ' ||
                         substr(consultations_view.patient_name, 1, 1) || '.' ||
                         substr(consultations_view.patient_patronymic, 1, 1) || '.'
                         , consultations_view.price
                    from
                        consultations_view
                    where
                        consultations_view.date between :start_date and :end_date
                    order by 
                        consultations_view.date
                """

        # выполнение запроса
        cursor = self.__cursor.execute(sql_cmd, dict_params)

        # пустой список приемов для результатов выборки
        consultations = []

        # результат выборки
        # помещаем в коллекцию
        for data in cursor.fetchall():
            consultations.append(
                ConsultationView(data[0], data[1], data[2], data[3], data[4], data[5])
            )

        return consultations

    # Выбирает информацию о докторах, специальность которых задана параметром
    def get_doctors_by_speciality(self, speciality):
        # словарь параметров
        dict_params = ({'speciality': speciality + '%'})

        # запрос
        sql_cmd = f"""
                    select
                        doctors_view.id
                        , doctors_view.surname
                        , doctors_view.name
                        , doctors_view.patronymic
                        , doctors_view.title
                        , doctors_view.percent
                        , doctors_view.price
                    from
                        doctors_view
                    where
                        doctors_view.title like :speciality
                    order by 
                        doctors_view.surname
                        , doctors_view.name
                        , doctors_view.patronymic
                        , doctors_view.title
                        , doctors_view.percent
                        , doctors_view.price
                """

        # выполнение запроса
        cursor = self.__cursor.execute(sql_cmd, dict_params)

        # пустой список докторов для результатов выборки
        doctors = []

        # результат выборки
        # помещаем в коллекцию
        for data in cursor.fetchall():
            doctors.append(
                Doctor(data[0], data[1], data[2],
                       data[3], data[4], data[5],
                       data[6])
            )

        return doctors

    # Вычисляет размер заработной платы врача за каждый прием.
    # Включает поля Фамилия врача, Имя врача, Отчество врача, Специальность врача,
    # Стоимость приема, Зарплата. Сортировка по полю Специальность врача
    def get_salary_for_consultation(self):
        # запрос
        sql_cmd = f"""
                    select
                        consultations_view.doctor_surname
                        , consultations_view.doctor_name
                        , consultations_view.doctor_patronymic
                        , consultations_view.speciality_title
                        , consultations_view.price
                        , consultations_view.pay_doctor
                    from
                        consultations_view
                    order by
                        consultations_view.speciality_title
                """

        # выполнение запроса
        cursor = self.__cursor.execute(sql_cmd)

        # пустой список приемов для результатов выборки
        consultations = []

        # результат выборки
        # помещаем в коллекцию
        for data in cursor.fetchall():
            consultations.append(
                ConsultationWithSalary(data[0], data[1], data[2],
                                       data[3], data[4], data[5])
            )

        return consultations

    # Выполняет группировку по полю Дата приема. Для каждой даты вычисляет максимальную стоимость приема
    def get_group_by_date_with_max_price(self):
        # запрос
        sql_cmd = f"""
                           select
                               consultations_view.date
                               , max(consultations_view.price)
                           from
                               consultations_view
                           group by
                                 consultations_view.date
                           order by
                               consultations_view.date
                       """

        # выполнение запроса
        cursor = self.__cursor.execute(sql_cmd)

        # пустой список групп для результатов выборки
        group = []

        # результат выборки
        # помещаем в коллекцию
        for data in cursor.fetchall():
            group.append(
                GroupByDateWithMaxPrice(data[0], data[1])
            )

        return group

    # Выполняет группировку по полю Специальность. Для каждой специальности вычисляет средний
    # Процент отчисления на зарплату от стоимости приема
    def get_group_by_speciality_with_avg_percent(self):
        # запрос
        sql_cmd = f"""
                        select
                            specialties.title
                            , IFNULL(avg(doctors.percent), 0)
                        from
                            specialties left join doctors on specialties.id = doctors.id_speciality
                        group by
                            specialties.title
                        order by
                            specialties.title
                       """

        # выполнение запроса
        cursor = self.__cursor.execute(sql_cmd)

        # пустой список групп для результатов выборки
        group = []

        # результат выборки
        # помещаем в коллекцию
        for data in cursor.fetchall():
            group.append(
                GroupBySpecialityWithAvgPercent(data[0], data[1])
            )

        return group
