from controllers.DbController import DbController
from models.ConsultationView import ConsultationView
from models.ConsultationWithSalary import ConsultationWithSalary
from models.Consultation import Consultation
from models.Doctor import Doctor
from models.GroupByDateWithMaxPrice import GroupByDateWithMaxPrice
from models.GroupBySpecialityWithAvgPercent import GroupBySpecialityWithAvgPercent
from models.Patient import Patient
from models.Person import Person
from models.Speciality import Speciality


class TaskController:
    def __init__(self, db=DbController()):
        self.__db = db

    def run(self):

        # все параметры заданы по умолчанию в функциях

        # Вывод таблицы персон
        self.__show_table_persons()

        # Вывод таблицы специальностей
        self.__show_table_specialties()

        # Вывод таблицы пациентов
        self.__show_table_patients()

        # Вывод таблицы врачей
        self.__show_table_doctors()

        # Вывод таблицы приемов
        self.__show_table_consultations()

        # Вывод информации о пациентах с фамилиями,
        # начинающимися на заданную параметром последовательность букв
        self.__show_patients_by_surname()

        # Выбирает информацию о врачах, для которых значение в поле
        # Процент отчисления на зарплату, больше заданного значения
        self.__show_doctors_by_percent()

        # Вывод информации о приемах за некоторый период, заданный параметрами
        self.__show_consultations_by_range_date()

        # Вывод информации о докторах, специальность которых задана параметром
        self.__show_doctors_by_speciality()

        # Вывод заработной платы врача за каждый прием.
        # Включает поля Фамилия врача, Имя врача, Отчество врача, Специальность врача, Стоимость приема, Зарплата.
        # Сортировка по полю Специальность врача
        self.__show_salary_for_consultation()

        # Выполняет группировку по полю Дата приема. Для каждой даты вычисляет максимальную стоимость приема
        self.__show_group_by_date_with_max_price()

        # Выполняет группировку по полю Специальность. Для каждой специальности вычисляет средний
        # Процент отчисления на зарплату от стоимости приема
        self.__show_group_by_speciality_with_avg_percent()

    # Вывод таблицы персон
    def __show_table_persons(self):
        print(f'\n\033[36;1mТаблица персон.\033[0m\n')

        # выборка данных из БД
        persons = self.__db.get_table_persons()

        # вывод результат выполнения запроса
        print(Person.header)
        for person in persons:
            print(person.to_table_row())
        print(Person.footer)

    # Вывод таблицы специальностей
    def __show_table_specialties(self):
        print(f'\n\033[36;1mТаблица специальностей.\033[0m\n')

        # выборка данных из БД
        specialties = self.__db.get_table_specialties()

        # вывод результат выполнения запроса
        print(Speciality.header)
        for s in specialties:
            print(s.to_table_row())
        print(Speciality.footer)

    # Вывод таблицы пациентов
    def __show_table_patients(self):
        print(f'\n\033[36;1mТаблица пациентов.\033[0m\n')
        # выборка данных из БД
        patients = self.__db.get_table_patients()

        # вывод результат выполнения запроса
        print(Patient.header)

        for patient in patients:
            print(patient.to_table_row())

        print(Patient.footer)

    def __show_table_doctors(self):
        print(f'\n\033[36;1mТаблица врачей.\033[0m\n')

        # выборка данных из БД
        doctors = self.__db.get_table_doctors()

        # вывод результат выполнения запроса
        print(Doctor.header)

        for doctor in doctors:
            print(doctor.to_table_row())

        print(Doctor.footer)

    def __show_table_consultations(self):
        print(f'\n\033[36;1mТаблица приемов.\033[0m\n')

        # выборка данных из БД
        consultations = self.__db.get_table_consultations()

        # вывод результат выполнения запроса
        print(Consultation.header)

        for c in consultations:
            print(c.to_table_row())

        print(Consultation.footer)

    # Выбирает информацию о пациентах с фамилиями, начинающимися на заданную параметром последовательность букв
    def __show_patients_by_surname(self, surname='К'):
        print(f'\n\033[36;1mЗапрос 1.\033[0m')
        print(f'\n\033[36;1mВыбирает информацию о пациентах с фамилиями, начинающимися на \"{surname}\"\n\033[0m')

        # выборка данных из БД
        patients = self.__db.get_patients_by_surname(surname)

        # вывод результат выполнения запроса
        print(Patient.header)

        for patient in patients:
            print(patient.to_table_row())

        print(Patient.footer)

    # Выбирает информацию о врачах, для которых значение в поле
    # Процент отчисления на зарплату, больше 2.3% (задавать параметром)
    def __show_doctors_by_percent(self, percent=25.2):
        print(f'\n\033[36;1mЗапрос 2.\033[0m')
        print(
            f'\n\033[36;1mВыбирает информацию о врачах, для которых значение в поле Процент отчисления на зарплату, больше \"{percent}\"\n\033[0m')

        # выборка данных из БД
        doctors = self.__db.get_doctors_by_percent(percent)

        # вывод результат выполнения запроса
        print(Doctor.header)

        for doctor in doctors:
            print(doctor.to_table_row())

        print(Doctor.footer)

    # Выбирает информацию о приемах за некоторый период, заданный параметрами
    def __show_consultations_by_range_date(self, start_date='2022-11-01', end_date='2022-11-30'):
        print(f'\n\033[36;1mЗапрос 3.\033[0m')
        print(
            f'\n\033[36;1mВыбирает информацию о приемах за период c \"{start_date}\" по \"{end_date}\"\n\033[0m')

        # выборка данных из БД
        consultations = self.__db.get_consultations_by_range_date(start_date, end_date)

        # вывод результат выполнения запроса
        print(ConsultationView.header)

        for consultation in consultations:
            print(consultation.to_table_row())

        print(ConsultationView.footer)

    # Выводит информацию о докторах, специальность которых задана параметром
    def __show_doctors_by_speciality(self, speciality='Офтальмолог'):
        print(f'\n\033[36;1mЗапрос 4.\033[0m')
        print(
            f'\n\033[36;1mВыбирает информацию о докторах с специальностью \"{speciality}\"\n\033[0m')

        # выборка данных из БД
        doctors = self.__db.get_doctors_by_speciality(speciality)

        # вывод результат выполнения запроса
        print(Doctor.header)

        for doctor in doctors:
            print(doctor.to_table_row())

        print(Doctor.footer)

    # Вычисляет размер заработной платы врача за каждый прием.
    # Включает поля Фамилия врача, Имя врача, Отчество врача, Специальность врача,
    # Стоимость приема, Зарплата. Сортировка по полю Специальность врача
    def __show_salary_for_consultation(self):
        print(f'\n\033[36;1mЗапрос 5.\033[0m')
        print(
            f'\n\033[36;1mВычисляет размер заработной платы врача за каждый прием\n\033[0m')

        # выборка данных из БД
        consultations = self.__db.get_salary_for_consultation()

        # вывод результат выполнения запроса
        print(ConsultationWithSalary.header)

        for consultation in consultations:
            print(consultation.to_table_row())

        print(ConsultationWithSalary.footer)

    # Выполняет группировку по полю Дата приема. Для каждой даты вычисляет максимальную стоимость приема
    def __show_group_by_date_with_max_price(self):
        print(f'\n\033[36;1mЗапрос 6.\033[0m')
        print(
            f'\n\033[36;1mВыполняет группировку по полю Дата приема. Для каждой даты вычисляет максимальную стоимость приема\n\033[0m')

        # выборка данных из БД
        group = self.__db.get_group_by_date_with_max_price()

        # вывод результат выполнения запроса
        print(GroupByDateWithMaxPrice.header)

        for gr in group:
            print(gr.to_table_row())

        print(GroupByDateWithMaxPrice.footer)

    # Выполняет группировку по полю Специальность. Для каждой специальности вычисляет средний
    # Процент отчисления на зарплату от стоимости приема
    def __show_group_by_speciality_with_avg_percent(self):
        print(f'\n\033[36;1mЗапрос 7.\033[0m')
        print(
            f'\n\033[36;1mВыполняет группировку по полю Специальность. Для каждой специальности вычисляет средний Процент отчисления на зарплату от стоимости приема\n\033[0m')

        # выборка данных из БД
        group = self.__db.get_group_by_speciality_with_avg_percent()

        # вывод результат выполнения запроса
        print(GroupBySpecialityWithAvgPercent.header)

        for gr in group:
            print(gr.to_table_row())

        print(GroupBySpecialityWithAvgPercent.footer)
