class GroupByDateWithMaxPrice:
    def __init__(self, date, price):
        self.date = date
        self.price = price

    # дата приема
    @property
    def date(self):
        return self.__date

    @date.setter
    def date(self, value):
        self.__date = value

    # стоимость приема
    @property
    def price(self):
        return self.__price

    @price.setter
    def price(self, value):
        self.__price = value

    # шапка таблицы
    header = \
        '\t┌───────────────────────────┬───────────────────────────┐\n' \
        '\t│        Дата приема        │         Стоимость         │\n' \
        '\t├───────────────────────────┼───────────────────────────┤'

    # подвал таблицы
    footer = \
        '\t└───────────────────────────┴───────────────────────────┘'

    # строка таблицы
    def to_table_row(self):
        return f'\t│ {self.__date:25} ' \
               f'│ {self.__price:25} │'
