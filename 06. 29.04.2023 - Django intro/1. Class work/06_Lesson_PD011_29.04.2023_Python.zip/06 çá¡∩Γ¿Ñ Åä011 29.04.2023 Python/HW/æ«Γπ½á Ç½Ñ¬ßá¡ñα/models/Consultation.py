class Consultation:
    def __init__(self, id, date, doctor_surname, doctor_name, doctor_patronymic,
                 patient_surname, patient_name, patient_patronymic):
        self.id = id
        self.date = date
        self.doctor_surname = doctor_surname
        self.doctor_name = doctor_name
        self.doctor_patronymic = doctor_patronymic
        self.patient_surname = patient_surname
        self.patient_name = patient_name
        self.patient_patronymic = patient_patronymic

    # id
    @property
    def id(self):
        return self.__id

    @id.setter
    def id(self, value):
        self.__id = value

    # дата приема
    @property
    def date(self):
        return self.__date

    @date.setter
    def date(self, value):
        self.__date = value

    # фамилия врача
    @property
    def doctor_surname(self):
        return self.__doctor_surname

    @doctor_surname.setter
    def doctor_surname(self, value):
        self.__doctor_surname = value

    # имя врача
    @property
    def doctor_name(self):
        return self.__doctor_name

    @doctor_name.setter
    def doctor_name(self, value):
        self.__doctor_name = value

    # отчество врача
    @property
    def doctor_patronymic(self):
        return self.__doctor_patronymic

    @doctor_patronymic.setter
    def doctor_patronymic(self, value):
        self.__doctor_patronymic = value

    # фамилия пациента
    @property
    def patient_surname(self):
        return self.__patient_surname

    @patient_surname.setter
    def patient_surname(self, value):
        self.__patient_surname = value

    # имя пациента
    @property
    def patient_name(self):
        return self.__patient_name

    @patient_name.setter
    def patient_name(self, value):
        self.__patient_name = value

    # отчество пациента
    @property
    def patient_patronymic(self):
        return self.__patient_patronymic

    @patient_patronymic.setter
    def patient_patronymic(self, value):
        self.__patient_patronymic = value

    # шапка таблицы
    header = \
        '\t┌──────┬─────────────────┬───────────────────────────┬───────────────────────────┬───────────────────────────┬───────────────────────────┬───────────────────────────┬───────────────────────────┐\n' \
        '\t│  Id  │   Дата приема   │        Фамилия врача      │        Имя врача          │       Отчество врача      │     Фамилия пациента      │       Имя пациента        │     Отчество пациента     │\n' \
        '\t├──────┼─────────────────┼───────────────────────────┼───────────────────────────┼───────────────────────────┼───────────────────────────┼───────────────────────────┼───────────────────────────┤'

    # подвал таблицы
    footer = \
        '\t└──────┴─────────────────┴───────────────────────────┴───────────────────────────┴───────────────────────────┴───────────────────────────┴───────────────────────────┴───────────────────────────┘'

    # строка таблицы
    def to_table_row(self):
        return f'\t│ {self.__id:4} ' \
               f'│ {self.__date:15} ' \
               f'│ {self.__doctor_surname:25} ' \
               f'│ {self.__doctor_name:25} ' \
               f'│ {self.__doctor_patronymic:25} ' \
               f'│ {self.__patient_surname:25} ' \
               f'│ {self.__patient_name:25} ' \
               f'│ {self.__patient_patronymic:25} │'
