class ConsultationWithSalary:

    def __init__(self, doctor_surname, doctor_name, doctor_patronymic, speciality_title, price, pay_doctor):
        self.doctor_surname = doctor_surname
        self.doctor_name = doctor_name
        self.doctor_patronymic = doctor_patronymic
        self.speciality_title = speciality_title
        self.price = price
        self.pay_doctor = pay_doctor

    # фамилия врача
    @property
    def doctor_surname(self):
        return self.__doctor_surname

    @doctor_surname.setter
    def doctor_surname(self, value):
        self.__doctor_surname = value

    # имя врача
    @property
    def doctor_name(self):
        return self.__doctor_name

    @doctor_name.setter
    def doctor_name(self, value):
        self.__doctor_name = value

    # отчество врача
    @property
    def doctor_patronymic(self):
        return self.__doctor_patronymic

    @doctor_patronymic.setter
    def doctor_patronymic(self, value):
        self.__doctor_patronymic = value

    # специальность
    @property
    def speciality_title(self):
        return self.__speciality_title

    @speciality_title.setter
    def speciality_title(self, value):
        self.__speciality_title = value

    # стоимость приема
    @property
    def price(self):
        return self.__price

    @price.setter
    def price(self, value):
        self.__price = value

    # заработная плата врача
    @property
    def pay_doctor(self):
        return self.__pay_doctor

    @pay_doctor.setter
    def pay_doctor(self, value):
        self.__pay_doctor = value

    # шапка таблицы
    header = \
        '\t┌───────────────────────────┬───────────────────────────┬───────────────────────────┬───────────────────────────┬─────────────────────────────┬─────────────────────────────┐\n' \
        '\t│          Фамилия          │            Имя            │          Отчество         │       Специальность       │      Стоимость приема       │           Зарплата          │\n' \
        '\t├───────────────────────────┼───────────────────────────┼───────────────────────────┼───────────────────────────┼─────────────────────────────┼─────────────────────────────┤'

    # подвал таблицы
    footer = \
        '\t└───────────────────────────┴───────────────────────────┴───────────────────────────┴───────────────────────────┴─────────────────────────────┴─────────────────────────────┘'

    # строка таблицы
    def to_table_row(self):
        return f'\t│ {self.__doctor_surname:25} ' \
               f'│ {self.__doctor_name:25} ' \
               f'│ {self.__doctor_patronymic:25} ' \
               f'│ {self.__speciality_title:25} ' \
               f'│ {self.__price:27.2f} ' \
               f'│ {self.__pay_doctor:27.2f} │'
