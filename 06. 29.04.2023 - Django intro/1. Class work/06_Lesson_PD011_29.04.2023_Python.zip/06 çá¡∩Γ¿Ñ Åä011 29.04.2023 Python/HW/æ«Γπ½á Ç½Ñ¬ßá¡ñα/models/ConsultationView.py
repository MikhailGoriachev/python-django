class ConsultationView:
    def __init__(self, id, speciality_title, date, doctor, patient, price):
        self.id = id
        self.speciality_title = speciality_title
        self.date = date
        self.doctor = doctor
        self.patient = patient
        self.price = price

    # id
    @property
    def id(self):
        return self.__id

    @id.setter
    def id(self, value):
        self.__id = value

    # специальность
    @property
    def speciality_title(self):
        return self.__speciality_title

    @speciality_title.setter
    def speciality_title(self, value):
        self.__speciality_title = value

    # дата приема
    @property
    def date(self):
        return self.__date

    @date.setter
    def date(self, value):
        self.__date = value

    # доктор
    @property
    def doctor(self):
        return self.__doctor

    @doctor.setter
    def doctor(self, value):
        self.__doctor = value

    # пациент
    @property
    def patient(self):
        return self.__patient

    @patient.setter
    def patient(self, value):
        self.__patient = value

    # стоимость приема
    @property
    def price(self):
        return self.__price

    @price.setter
    def price(self, value):
        self.__price = value

    # шапка таблицы
    header = \
        '\t┌──────┬───────────────────────────┬───────────────────────────┬───────────────────────────┬───────────────────────────┬───────────────┐\n' \
        '\t│  Id  │        Дата приема        │       Специальность       │          Доктор           │           Пациент         │   Стоимость   │\n' \
        '\t├──────┼───────────────────────────┼───────────────────────────┼───────────────────────────┼───────────────────────────┼───────────────┤'

    # подвал таблицы
    footer = \
        '\t└──────┴───────────────────────────┴───────────────────────────┴───────────────────────────┴───────────────────────────┴───────────────┘'

    # строка таблицы
    def to_table_row(self):
        return f'\t│ {self.__id:4} ' \
               f'│ {self.__date:25} ' \
               f'│ {self.__speciality_title:25} ' \
               f'│ {self.__doctor:25} ' \
               f'│ {self.__patient:25} ' \
               f'│ {self.__price:13.2f} │'
