class Patient:
    def __init__(self, id, surname, name, patronymic, birth_date, address):
        self.id = id
        self.surname = surname
        self.name = name
        self.patronymic = patronymic
        self.birth_date = birth_date
        self.address = address

    # id
    @property
    def id(self):
        return self.__id

    @id.setter
    def id(self, value):
        self.__id = value

    # фамилия
    @property
    def surname(self):
        return self.__surname

    @surname.setter
    def surname(self, value):
        self.__surname = value

    # имя
    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, value):
        self.__name = value

    # отчество
    @property
    def patronymic(self):
        return self.__patronymic

    @patronymic.setter
    def patronymic(self, value):
        self.__patronymic = value

    # дата рождения
    @property
    def birth_date(self):
        return self.__birth_date

    @birth_date.setter
    def birth_date(self, value):
        self.__birth_date = value

    # адрес
    @property
    def address(self):
        return self.__address

    @address.setter
    def address(self, value):
        self.__address = value

    # шапка таблицы

    header = \
        '\t┌──────┬───────────────────────────┬───────────────────────────┬───────────────────────────┬─────────────────┬──────────────────────────────────────────┐\n' \
        '\t│  Id  │          Фамилия          │            Имя            │          Отчество         │  Дата рождения  │                   Адрес                  │\n' \
        '\t├──────┼───────────────────────────┼───────────────────────────┼───────────────────────────┼─────────────────┼──────────────────────────────────────────┤'

    # подвал таблицы
    footer = \
        '\t└──────┴───────────────────────────┴───────────────────────────┴───────────────────────────┴─────────────────┴──────────────────────────────────────────┘'

    # строка таблицы
    def to_table_row(self):
        return f'\t│ {self.__id:4} ' \
               f'│ {self.__surname:25} ' \
               f'│ {self.__name:25} ' \
               f'│ {self.__patronymic:25} ' \
               f'│ {self.__birth_date:15} ' \
               f'│ {self.__address:40} │'
