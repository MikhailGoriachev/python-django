class GroupBySpecialityWithAvgPercent:
    def __init__(self, speciality, percent):
        self.speciality = speciality
        self.percent = percent

    # дата приема
    @property
    def speciality(self):
        return self.__speciality

    @speciality.setter
    def speciality(self, value):
        self.__speciality = value

    # стоимость приема
    @property
    def percent(self):
        return self.__percent

    @percent.setter
    def percent(self, value):
        self.__percent = value

    # шапка таблицы
    header = \
        '\t┌───────────────────────────┬───────────────────────────┐\n' \
        '\t│      Специальность        │          Процент          │\n' \
        '\t├───────────────────────────┼───────────────────────────┤'

    # подвал таблицы
    footer = \
        '\t└───────────────────────────┴───────────────────────────┘'

    # строка таблицы
    def to_table_row(self):
        return f'\t│ {self.__speciality:25} ' \
               f'│ {self.__percent:25} │'
