class Speciality:
    def __init__(self, id, title):
        self.id = id
        self.title = title

    # id
    @property
    def id(self):
        return self.__id

    @id.setter
    def id(self, value):
        self.__id = value

    # специальность
    @property
    def title(self):
        return self.__title

    @title.setter
    def title(self, value):
        self.__title = value

    # шапка таблицы
    header = \
        '\t┌──────┬───────────────────────────┐\n' \
        '\t│  Id  │       Специальность       │\n' \
        '\t├──────┼───────────────────────────┤'

    # подвал таблицы
    footer = \
        '\t└──────┴───────────────────────────┘'

    # строка таблицы
    def to_table_row(self):
        return f'\t│ {self.__id:4} ' \
               f'│ {self.__title:25} │'
