import app
import utils


def main():
    try:

        print('\n\tМеню приложения')
        for key in utils.menu_tasks:
            print(f"\t\033[31;1m{key}\033[0m {utils.menu_tasks[key]}")

        while True:
            cmd = input('\tВаш выбор: ')

            if cmd == '1':
                app.do_task01()

            elif cmd == '2':
                app.do_task02()

            elif cmd == '3':
                app.do_task03()

            elif cmd == '4':
                app.do_task04()

            elif cmd == '5':
                app.do_task04_add()

            elif cmd == '6':
                app.do_task04_edt()

            elif cmd == '7':
                app.do_task04_del()

            elif cmd == '0':
                return
            else:
                raise Exception("\n\t\033[31;1mОшибка: нет такого пункта меню\033[0m")

    except Exception as e:
        print(e)
    finally:
        print("\n\tКонец работы приложения...")


if __name__ == '__main__':
    main()

