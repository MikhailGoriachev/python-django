import csv
import os
import random
import shelve

import utils

# Диапазон генерации чисел в множестве
LO = -20
HI = 20

# Диапазон генерации длины множества
LO_LEN = 5
HI_LEN = 23

# имя исходного текстового файла
FILE_NAME = "text.txt"

# имя файла товаров
GOODS_FILE_NAME = 'goods'

# путь к файлу товаров
PATH = "task4\\" + GOODS_FILE_NAME


# Task1. Обработка множеств. Разработайте функцию, в которой используются два множества из случайных целых чисел.
# Функция должна обеспечивать:
def do_task01():
    set01 = set()
    set02 = set()

    # Формирование множеств – используйте операцию добавления в множество,
    # длина каждого множества определяется генератором случайных чисел
    # (от 5и до 23х элементов), диапазон значений элементов: -20, 20;
    utils.fill_set(set01, LO, HI, random.randint(LO_LEN, HI_LEN))
    utils.fill_set(set02, LO, HI, random.randint(LO_LEN, HI_LEN))

    # Вычисление пересечения множеств
    set_result = set01 & set02
    print(f'\n\tИсходные множества:\n\t{set01}\n\t{set02}\n\n\tПересечение множеств: {set_result}')

    # Вычисление разности множеств
    set_result = set01 - set02
    print(f'\tРазность множеств: {set_result}')

    # Вычисление объединения множеств;
    set_result = set01.union(set02)
    print(f'\tОбъединение множеств: {set_result}')

    # Удаление всех отрицательных элементов из множества с меньшим количеством элементов
    if len(set01) < len(set02):
        new_set = utils.delete_neg(set01)
        print(f'\tМножество 1 после удаления всех отрицательных элементов: {new_set}\n')
    else:
        new_set = utils.delete_neg(set02)
        print(f'\tМножество 2 после удаления всех отрицательных элементов: {new_set}\n')


# Task2. Обработка строк, текстовых файлов. Для файла text.txt, приведенного в папке задания реализуйте обработки
def do_task02():
    # Считаем файл одной операцией read()
    with open(FILE_NAME, "r", encoding='utf-8') as file:
        lines = file.read()

    # lower()     : переводит строку в нижний регистр
    lines = lines.lower()

    # Перевести текст из исходного файла в нижний регистр, сохранить в файле lowers.txt
    with open("lowers.txt", "w", encoding='utf-8') as lowers_file:
        # способ записи в файл
        lowers_file.write(lines)

    # Считаем файл lowers.txt
    with open("lowers.txt", "r", encoding='utf-8') as file:
        lowers_lines = file.read()

    # кол-во строк в файле lowers.txt
    count_lines = len(lowers_lines.split("\n"))
    print(f"\n\tКол-во строк в файле lowers.txt: {count_lines}")
    lowers_lines = lowers_lines.replace("\n", " ").replace(",", "").replace(".", "").replace("(", "").replace(")", "")

    # разбить строку на список
    words_list = lowers_lines.split(" ")

    result_list = []
    # проверяем список на пустые слова
    for word in words_list:
        if len(word) > 0:
            result_list.append(word)

    # кол-во слов в файле lowers.txt
    count_words = len(result_list)
    print(f"\tКол-во слов в файле lowers.txt: {count_words}")

    # определить максимальную длину слова и список слов максимальной длины, минимальную длину слова и список слов
    # минимальной длины

    max_size = 0
    # слова max и min длины
    # почему-то max_word = max(result_list) работает некорректно поэтому цикл for
    for w in result_list:
        if len(w) > max_size:
            max_size = len(w)

    print(f"\tМаксимальная длина слова: {max_size}")

    min_word = min(result_list)
    min_size = len(min_word)

    print(f"\tМинимальная длина слова: {min_size}")

    max_words = []
    min_words = []

    # поиск слов min и max длины
    for word in result_list:
        if len(word) == max_size:
            max_words.append(word)

        if len(word) == min_size:
            min_words.append(word)

    print(f"\n\tСписок слов максимальной длины:\n\t{max_words}")
    print(f"\n\tСписок слов минимальной длины:\n\t{min_words}")

    max_str = ", ".join(max_words)
    min_str = ", ".join(min_words)

    # сохраните списки слов в файлах longest.txt и shortest.txt соответственно для слов максимальной и минимальной длины
    with open("longest.txt", "w", encoding='utf-8') as longest_file:
        longest_file.write(max_str)

    with open("shortest.txt", "w", encoding='utf-8') as shortest_file:
        shortest_file.write(min_str)

    print(f"\n\tФайлы записаны\n")

    # Сформируйте словарь из слов файла lowers.txt – ключом является слово, значением – количество вхождений этого
    # слова в текст.
    dictionary = dict()

    for word in result_list:
        dictionary[word] = result_list.count(word)

    # Сохраните этот словарь в формате CSV, имя файла words.csv
    with open("words.csv", "w", encoding='UTF-8', newline="") as file:
        # объект для записи в файл
        writer = csv.writer(file)

        # собственно запись в файл всего списка данных writerows()
        writer.writerows(dictionary.items())


# Task3. Обработка словарей, файлов в формате CSV.
def do_task03():
    # вывод столицы заданного государства
    str01 = "\n\tВведите государство для поиска: "
    cmd01 = input(str01)

    # вывод государства, столицей которого является заданный город
    str02 = "\tВведите столицу для поиска: "
    cmd02 = input(str02)

    print(f"\n\tСтолица заданного государства: " + utils.dictionary_countries.get(cmd01, '\033[31mзаданное '
                                                                                         'государство в словаре не '
                                                                                         'найдено!\033[0m'))

    # признак нахождения заданного ключа в словаре
    flag = True
    dictionary_items = utils.dictionary_countries.items()
    for key, value in dictionary_items:
        if value == cmd02:
            print(f"\tГосударство заданной столицы: {key}")
            flag = False
            break

    if flag:
        print(f"\tГосударство заданной столицы: \033[31mзаданная столица в словаре не найдена!\033[0m")

    # добавление государства и его столицы в словарь
    # вывод столицы
    str01 = "\n\tВведите государство для добавления: "
    cmd01 = input(str01)

    # вывод государства
    str02 = "\tВведите столицу для добавления: "
    cmd02 = input(str02)

    # запись словаря в файл формата CSV, имя файл – countries.csv
    with open("countries.csv", "w", encoding='UTF-8', newline="") as file:
        # объект для записи в файл
        writer = csv.writer(file)

        # собственно запись в файл всего списка данных writerows()
        writer.writerows(utils.dictionary_countries.items())

    # чтение словаря из файла формата CSV, имя файла – countries.csv,
    with open("countries.csv", "r", encoding='UTF-8', newline="") as file:
        # объект для чтения из файла
        reader = csv.reader(file)

        # собственно чтение данных в словарь
        new_dictionary_countries = dict()
        for row in reader:
            new_dictionary_countries[row[0]] = row[1]

    # добавление государства и его столицы в словарь
    # проверка на правильность вводимых данных
    if cmd01.isalpha() and cmd02.isalpha():
        new_dictionary_countries[cmd01] = cmd02
    else:
        print(f"\t\033[31mДанные были введены некорректно, добавление отменено!\033[0m")

    print("\n\tФайл прочитан:")
    utils.show_dictionary_countries(new_dictionary_countries)


def preparation_task04():
    # Создание папки task4
    # путь относительно текущего скрипта
    if not os.path.exists("task4"):
        os.mkdir("task4")

    goods = []

    if os.path.exists("task4\\goods.dat"):

        # выведите в бинарный файл при помощи модуля shelve список товаров.
        with shelve.open(PATH) as rd:
            for i in rd:
                goods.append(rd[i])

    # Если файла в папке task4 нет – формируйте список для записи присваиванием и сохраняйте его в файл.
    else:
        goods = utils.generate_goods()

        # запись файла при помощи модуля shelve
        with shelve.open(PATH) as wr:
            for i in range(len(goods)):
                wr[f"{i}"] = goods[i]

    return goods


# Task4. Бинарные файлы shelve, модуль os.
def do_task04():
    goods = preparation_task04()
    utils.show_goods(goods)

    # вычислить сумму цен товаров, имеющихся в наличии
    goods_sum = 0
    for good in goods:
        if good[2]:
            goods_sum += good[1]

    print(f"\tСумма цен товаров, имеющихся в наличии: {goods_sum}")

    # количество наименований товаров, которых нет в наличии
    my_dictionary = dict()

    for good in goods:
        if not good[2]:
            my_dictionary[good[0]] = 0

    print(f"\tКоличество наименований товаров, которых нет в наличии: {len(my_dictionary)}\n")


# добавление товара
def do_task04_add():
    goods = preparation_task04()
    with shelve.open(PATH) as fr:
        # собственно запись
        fr[f"{len(goods)}"] = utils.generate_good()
    print("\n\tДобавление завершено")


def do_task04_edt():
    goods = preparation_task04()
    with shelve.open(PATH) as fr:
        fr[f"{random.randint(0,len(goods)-1)}"] = utils.generate_good()
    print("\n\tИзменение завершено")

def do_task04_del():
    goods = preparation_task04()
    with shelve.open(PATH) as fr:
        del fr[f"{random.randint(0,len(goods)-1)}"]
    print("\n\tУдаление завершено")


if __name__ == '__main__':
    import main

    main.main()
