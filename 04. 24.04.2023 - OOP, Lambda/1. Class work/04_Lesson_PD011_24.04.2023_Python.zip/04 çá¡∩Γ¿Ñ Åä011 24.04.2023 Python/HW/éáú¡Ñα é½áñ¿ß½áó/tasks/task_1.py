import main
import console_colors
import utils

if __name__ == '__main__':
    main.main()

# Были ли сформированы множества
are_sets_formed = False

SET_SIZE_MIN = 5
SET_SIZE_MAX = 23

SET_VALUE_MIN = -20
SET_VALUE_MAX = 20

# Множества

set_1 = set()
set_2 = set()


# Сформировать множества
def fill_sets():

    global are_sets_formed
    global set_1
    global set_2

    are_sets_formed = True

    set_1 = utils.generate_int_set(
        utils.get_random_int(SET_SIZE_MIN, SET_SIZE_MAX),
        SET_VALUE_MIN, SET_VALUE_MAX
    )

    set_2 = utils.generate_int_set(
        utils.get_random_int(SET_SIZE_MIN, SET_SIZE_MAX),
        SET_VALUE_MIN, SET_VALUE_MAX
    )

    print(f'\nМножество 1 со значениями в диапазоне {SET_VALUE_MIN}, {SET_VALUE_MAX}. '
          f'Количество элементов: {len(set_1)}\n')

    utils.show_container(set_1)

    print(f'\nМножество 2 со значениями в диапазоне {SET_VALUE_MIN}, {SET_VALUE_MAX}. '
          f'Количество элементов: {len(set_2)}\n')

    utils.show_container(set_2)

    # Ожидать нажатие клавиши
    #utils.wait_for_enter_press()


# Вычисления в множествах
def calculations():
    print(f'\nМножество 1:\n')

    utils.show_container(set_1)

    print(f'\nМножество 2:\n')

    utils.show_container(set_2)

    print(f'\nВычисление пересечения множеств:\n')

    crossing_set = set_1.intersection(set_2)

    utils.show_container(crossing_set)

    print(f'\nВычисление разности множеств:\n')

    difference_set = set_1.difference(set_2)

    utils.show_container(difference_set)

    print(f'\nВычисление объединения множеств (элементы из множества 2 выделены):\n')

    union_set = set_1.union(set_2)

    utils.show_united_set(union_set, set_2)

    # Ожидать нажатие клавиши
    utils.wait_for_enter_press()

# calculations


# Удаление элементов из множества
def delete_from_set():
    global set_1
    global set_2

    if len(set_1) == len(set_2):
        print(f"\n{console_colors.red_161_light}Размеры обоих множеств равны.{console_colors.terminate} "
              f"Операция не может быть выполнена!")
        return

    # Получить множество минимальной длины
    smallest_set = set_1 if len(set_2) > len(set_1) else set_2
    smallest_set_name = "1" if len(set_2) > len(set_1) else "2"

    print(f'\nНаименьшее множество - множество {smallest_set_name}:\n')

    utils.show_container(smallest_set)

    # Создать копию множества для удаления элементов
    smallest_set_copy = smallest_set.copy()

    for item in smallest_set:
        if item < 0:
            smallest_set_copy.discard(item)

    # Получить измененную версию множества
    smallest_set = smallest_set_copy

    # Изменить глобальные переменные множеств
    if len(set_1) < len(set_2):
        set_1 = smallest_set
    else:
        set_2 = smallest_set

    print(f'\nУдаление отрицательных элементов из множества {smallest_set_name}:\n')

    utils.show_container(smallest_set)
    # Ожидать нажатие клавиши
    utils.wait_for_enter_press()
