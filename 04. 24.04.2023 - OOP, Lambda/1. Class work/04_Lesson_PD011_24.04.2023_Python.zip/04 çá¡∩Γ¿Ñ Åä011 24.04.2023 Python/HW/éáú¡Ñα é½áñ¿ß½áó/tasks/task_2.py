import operator
import os
import re

import main
import console_colors
import utils

if __name__ == '__main__':
    main.main()

DEFAULT_FILE = "app_data/task02/text.txt"
LOWER_CASE_FILE = "app_data/task02/lowers.txt"

content = ""


# Существует ли файл для обработок
def task_file_exists():
    return os.path.exists(LOWER_CASE_FILE)


# Прочитать исходный файл и записать значения в lowers.txt
def read_file():
    global content
    with open(DEFAULT_FILE, "r", encoding="utf-8") as file:
        content = file.read()

        content = content.lower()

    # end with

    with open(LOWER_CASE_FILE, "w", encoding="utf-8") as file:
        file.write(content)

    # end with

    print(f"\nСодержимое файла, переведённое в нижний регистр:\n{content}")


def calculations():
    global content
    rows_count = content.count("\n")
    words = re.split("[ \n\t\r():.,–—]+", content)

    print(f"\n\nСписок слов: {words}")

    words_count = len(words)

    max_length = len(max(words, key=len))
    min_length = len(min(words, key=len))

    print(f"\nРасчёты параметров строк\n"
          f"Количество строк: {console_colors.light_magenta} {rows_count} {console_colors.terminate}\n\n"
          f"Количество слов: {console_colors.light_magenta} {words_count} {console_colors.terminate}\n\n"
          f"Макс. длина слова: {console_colors.light_magenta} {max_length} {console_colors.terminate}\n\n"
          f"Мин. длина слова: {console_colors.light_magenta} {min_length} {console_colors.terminate}"
          )

    # Список слов минимальной длины
    min_length_words = list()
    max_length_words = list()

    for word in words:
        if len(word) == min_length:
            min_length_words.append(word)

        if len(word) == max_length:
            max_length_words.append(word)

    print(f"\nСписок слов минимальной длины, равной {min_length}")

    utils.show_container(min_length_words)

    print(f"\nСписок слов максимальной длины, равной {max_length}")

    utils.show_container(max_length_words, 8)

    write_lists_to_files(min_length_words, max_length_words)

    # Ожидать нажатия клавиши
    utils.wait_for_enter_press()

    return words


# Записать списки слов мин и макс. длины
def write_lists_to_files(list_min, list_max):

    shortest_file = "app_data/task02/shortest.txt"
    with open(shortest_file, "w", encoding="utf-8") as file:
        file.write(" ".join(list_min))

    longest_file = "app_data/task02/longest.txt"
    with open(longest_file, "w", encoding="utf-8") as file:
        file.write(" ".join(list_max))


# Cловарь из слов файла lowers.txt – ключом является слово,
# значением – количество вхождений этого слова в текст
def frequency_dictionary(words):
    global content

    words_dict = {}
    for word in words:
        words_dict[word] = words.count(word)

    # Отсортировать словарь по убыванию значений
    words_dict = dict(sorted(words_dict.items(), key=operator.itemgetter(1), reverse=True))
    utils.show_dictionary(words_dict)

    file_path = "app_data/task02/words.csv "

    # Записать словарь в CSV
    utils.write_dict_to_csv(words_dict, file_path)

    utils.wait_for_enter_press()


def read_dict_from_csv():
    file_path = "app_data/task02/words.csv "

    if not os.path.exists(file_path):
        raise Exception(f"Файл {file_path} не существует!")

    # Прочитать словарь из CSV
    words_dict = utils.read_dict_from_csv(file_path)

    print("\nПрочитанный из файла словарь:\n")
    utils.show_dictionary(words_dict)

    utils.wait_for_enter_press()


