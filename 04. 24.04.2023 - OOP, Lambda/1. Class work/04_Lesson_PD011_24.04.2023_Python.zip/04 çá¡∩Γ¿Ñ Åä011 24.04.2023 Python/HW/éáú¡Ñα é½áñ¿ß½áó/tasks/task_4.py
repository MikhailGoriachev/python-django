import os.path
import shelve

import main
import console_colors
import utils
import random

if __name__ == '__main__':
    main.main()

LIST_SIZE_MIN = 10
LIST_SIZE_MAX = 15

DIR_PATH = "app_data/task04"
FILE_PATH = "app_data/task04/goods"

goods = list()


def prepare_folder_and_list():

    if not os.path.exists(DIR_PATH):
        os.mkdir(DIR_PATH)

    global goods

    # Если файл с данными существует, тогда генерировать коллекцию и писать в файл
    if not os.path.exists(f"{FILE_PATH}.dat"):
        goods = utils.generate_goods_list(utils.get_random_int(LIST_SIZE_MIN, LIST_SIZE_MAX))

        write_list_to_file()


def write_list_to_file():

    if len(goods) <= 0:
        print(f"\n{console_colors.red_161_light}Список пуст{console_colors.terminate}, "
              f"для записи в файл список нужно сформировать!")
        return

    with shelve.open(FILE_PATH, flag="n") as goods_file:

        number = 1
        for item in goods:

            # Добавить id товара
            item[0] = number

            goods_file[str(number)] = item
            number += 1


def read_list_from_file(title="Прочитанная коллекция товаров: "):

    global goods

    goods = utils.read_collection_from_shelve(FILE_PATH)

    if len(goods) <= 0:
        print("\nПрочитать коллекцию товаров не удалось! Возможно файл пуст")
        return

    print(f"\n{title}\n")

    utils.show_goods(goods)

    utils.wait_for_enter_press()


def goods_statistics():

    global goods
    if len(goods) <= 0:
        goods = utils.read_collection_from_shelve(FILE_PATH)

    # Вычисление суммы стоимостей товаров, которые есть в наличии
    #  и количества товаров, которых нет в наличии
    prices_sum = 0
    not_available_amount = 0

    for item in goods:
        if item[3] == 1:
            prices_sum += item[2]
        else:
            not_available_amount += 1

    # end for

    print(f"\nСумма стоимостей товаров, которые есть в наличии: "
          f"{console_colors.light_magenta} {prices_sum} {console_colors.terminate}\n")
    print(f"Количество товаров, которых нет в наличии: "
          f"{console_colors.light_magenta}  {not_available_amount: ^2} {console_colors.terminate}")

    utils.wait_for_enter_press()


# Добавить товар
def add_product():

    # Если файл с коллекцией не существует
    if not os.path.exists(f"{FILE_PATH}.dat"):
        print(f"\n{console_colors.red_161_light}Файл с товарами не существует!{console_colors.terminate} "
              f"добавить товар невозможно.")
        return

    product_name = utils.get_random_product()

    # Создать список, описывающий один товар
    product_list = [0, product_name[0], product_name[1], bool(random.getrandbits(1))]

    with shelve.open(FILE_PATH) as goods_file:

        # Получить текущую коллекцию в файле
        temp_list = list()
        for key in goods_file:
            temp_list.append(goods_file[key])

        # Сформировать новый ключ для добавления (id), определив предыдущий наибольший id
        adding_key = get_max_product_id(temp_list)+1

        # Задать id
        product_list[0] = adding_key

        # Записать в файл
        goods_file[str(adding_key)] = product_list

    # Вывод файла после добавления элемента
    read_list_from_file(f"Товары после добавления '{product_list[1]}' с номером {adding_key}")


# Удалить товар
def delete_product():

    # Если файл с коллекцией не существует
    if not os.path.exists(f"{FILE_PATH}.dat"):
        print(f"\n{console_colors.red_161_light}Файл с товарами не существует!{console_colors.terminate} "
              f"удалить товар невозможно.")
        return

    with shelve.open(FILE_PATH) as goods_file:

        # Получить список id в коллекции, в файле,
        # иначе можно попасть на ключ, которого уже нет
        list_ids = get_goods_ids(goods_file)

        ids_index = utils.get_random_int(1, len(list_ids))

        deletion_key = str(list_ids[ids_index])
        deleted_product = goods_file.pop(deletion_key, "Товар не найден")

    # Вывод файла после добавления элемента
    read_list_from_file(f"Товары после удаления '{deleted_product[1] if isinstance(deleted_product, list) else deleted_product}' "
                        f"с номером {deletion_key}")


# Изменить товар
def update_product():

    # Если файл с коллекцией не существует
    if not os.path.exists(f"{FILE_PATH}.dat"):
        print(f"\n{console_colors.red_161_light}Файл с товарами не существует!{console_colors.terminate} "
              f"изменить товар невозможно.")
        return

    with shelve.open(FILE_PATH) as goods_file:

        # Получить список id в коллекции, в файле,
        # иначе можно попасть на ключ, которого уже нет
        list_ids = get_goods_ids(goods_file)

        ids_random_index = utils.get_random_int(1, len(list_ids))

        updating_key = str(list_ids[ids_random_index])

        # Прочитать товар для изменения
        product = goods_file[updating_key]

        # Запомнить старое наименование - для вывода
        prod_name_old = product[1]

        # Получить новое наименование и цену, так же поменять признак наличия
        random_product = utils.get_random_product()
        product = [product[0], random_product[0], random_product[1], bool(random.getrandbits(1))]

        # Записать изменённый товар обратно
        goods_file[updating_key] = product

    # Вывод файла после добавления элемента
    read_list_from_file(f"Товары после изменения товара '{prod_name_old}' на '{product[1]}'"
                        f"с номером {updating_key}")


# Получение максимального id в списке товаров
def get_max_product_id(source):
    max_id = 0

    for item in source:
        if item[0] > max_id:
            max_id = item[0]

    return max_id


# Список id товаров в файле
def get_goods_ids(goods_file):

    ids = list()

    for key in goods_file:
        ids.append(goods_file[key][0])

    return ids
