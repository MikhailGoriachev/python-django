import main
import console_colors
import utils

if __name__ == '__main__':
    main.main()

countries_dictionary = {
    "Нидерланды": "Амстердам",
    "Греция": "Афины",
    "Словакия": "Братислава",
    "Бельгия": "Брюссель",
    "Венгрия": "Будапешт",
    "Румыния": "Бухарест",
    "Польша": "Варшава",
    "Австрия": "Вена",
    "Великобритания": "Лондон",
    "Испания": "Мадрид",
    "Норвегия": "Осло",
    "Франция": "Париж",
    "Италия": "Рим",
    "Финляндия": "Хельсинки",
    "ОАЭ": "Абу-Даби",
    "США": "Вашингтон",
    "Австралия": "Канберра",
    "Новая Зеландия": "Веллингтон",
}

capital = ""
country = ""
FILE_PATH = "app_data/task03/countries.csv"


def get_capital_of_country():

    # Словарь: номер + название стран
    countries = {}

    index = 0
    for key in countries_dictionary:
        countries[index+1] = key
        index += 1

    tasks = ""

    for number, country_val in countries.items():
        tasks += f"\n{number} - {country_val}"

    tasks += "\n\nВведите номер или название страны: "

    chosen_value = input(tasks).strip()

    global capital, country
    if chosen_value.isdigit():
        country = countries.get(int(chosen_value), f"{console_colors.color_info}Номер страны введён неверно!"
                                                   f"{console_colors.terminate}")
        capital = countries_dictionary.get(country, f"{console_colors.color_info}Заданной страны нет в словаре!"
                                                    f"{console_colors.terminate}\n")
    else:

        country = chosen_value
        capital = countries_dictionary.get(country, f"{console_colors.color_info}Заданной страны нет в словаре!"
                                                    f"{console_colors.terminate}\n")

    print(f"\nСтолица страны {country} - {capital}")

    utils.wait_for_enter_press()


def get_country_from_capital():

    # Словарь: номер + название города
    capitals = {}

    index = 0
    for value in countries_dictionary.values():
        capitals[index+1] = value
        index += 1

    tasks = ""

    for number, capital_val in capitals.items():
        tasks += f"\n{number} - {capital_val}"

    tasks += "\n\nВведите номер или название города: "

    chosen_value = input(tasks).strip()


    global capital, country
    if chosen_value.isdigit():
        capital = capitals.get(int(chosen_value), f"{console_colors.color_info}Номер или имя города введены неверно!"
                                                  f"{console_colors.terminate}")

        country = find_country_by_capital(capital)
    else:

        capital = chosen_value
        country = find_country_by_capital(capital)

    print(f"\nСтрана столицы {capital} - {country}")

    utils.wait_for_enter_press()


# Найти государство в словаре по заданной столице
def find_country_by_capital(value):
    # Найти первое вхождение страны по столице
    found_key = ""
    for country_key, capital_val in countries_dictionary.items():
        if capital_val == value:
            found_key = country_key
            break

    return found_key if len(found_key) > 0 else \
        f"{console_colors.color_info}Страны с заданной столицей нет в словаре! " \
        f"{console_colors.terminate}\n"


# Запись в CSV
def write_to_csv():

    utils.write_dict_to_csv(countries_dictionary, FILE_PATH)

    print(f"\nСловарь государств записан в файл!")

    # Ожидать нажатия клавиш
    utils.wait_for_enter_press()


# Чтение из CSV
def read_dict_from_csv():

    global countries_dictionary

    countries_dictionary = utils.read_dict_from_csv(FILE_PATH)

    print(f"\nСловарь государств прочитан из CSV файла\n")

    utils.show_dictionary(countries_dictionary)

    # Ожидать нажатия клавиш
    utils.wait_for_enter_press()


# Добавление записи словарь
def add_item_in_dict():

    global country, capital

    print("\nДобавление государства в словарь")

    country = input("\nЗадаёте страну: ")

    capital = input("\nЗадайте столицу: ")

    countries_dictionary[country] = capital

    print("\nИзменённый список:")

    utils.show_dictionary(countries_dictionary)

    # Ожидать нажатия клавиш
    utils.wait_for_enter_press()

