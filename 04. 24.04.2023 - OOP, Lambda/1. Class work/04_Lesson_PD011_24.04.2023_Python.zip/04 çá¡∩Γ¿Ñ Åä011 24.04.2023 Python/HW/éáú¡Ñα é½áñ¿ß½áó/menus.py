import app
import main

if __name__ == '__main__':
    main.main()

# Главное меню
main_menu_dict = {
    1: ["1 - задача 1", app.task01],
    2: ["2 - задача 2", app.task02],
    3: ["3 - задача 3", app.task03],
    4: ["4 - задача 4", app.task04],
    0: ["0 - выход\n", exit]
}
