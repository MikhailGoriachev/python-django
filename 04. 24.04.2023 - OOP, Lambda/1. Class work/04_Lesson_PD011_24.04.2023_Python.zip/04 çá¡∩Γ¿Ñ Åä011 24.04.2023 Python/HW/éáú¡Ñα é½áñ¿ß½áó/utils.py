import csv
import random
import re
import shelve

import main
import console_colors

if __name__ == '__main__':
    main.main()


def get_random_float(lo, hi):
    if lo > hi:
        return 0

    return random.uniform(lo, hi)


# end get_random_float


def get_random_int(lo, hi):
    if lo > hi:
        return 0

    return random.randrange(lo, hi)


# end get_random_int


# Сгенерировать список целых чисел
def generate_int_list(size, lo, hi):
    generating_list = []

    for i in range(size):
        generating_list.append(get_random_int(lo, hi))

    # end for

    return generating_list


# Сгенерировать множество целых чисел
def generate_int_set(size, lo, hi):
    generating_set = set()

    while len(generating_set) < size:
        generating_set.add(get_random_int(lo, hi))

    # end while

    return generating_set


# Сгенерировать список вещественных чисел
def generate_float_list(size, lo, hi):
    generating_list = []

    for i in range(size):
        generating_list.append(get_random_float(lo, hi))

    # end for

    return generating_list


def show_container(source, line_break_count=15):
    if len(source) == 0:
        print("\nВ контейнере нет значений!")
        return

    list_str = ""

    index = 0
    # Выделить повторяющиеся элементы
    for item in source:
        line_break = "\n\n" if (index + 1) % line_break_count == 0 and (index + 1) < len(source) else ""

        list_str += f" {console_colors.light_magenta} " \
                    f"{item: ^3} {console_colors.terminate}{line_break}"

        index += 1

    # end for

    print(list_str)


def show_united_set(set_1, set_2):
    list_str = ""

    index = 0
    # Выделить повторяющиеся элементы
    for item in set_1:
        line_break = "\n\n" if (index + 1) % 15 == 0 and (index + 1) < len(set_1) else ""

        list_str += f" {console_colors.blue_back_highlight if item in set_2 else console_colors.light_magenta} " \
                    f"{item: ^3} {console_colors.terminate}{line_break}"

        index += 1

    # end for

    print(list_str)


def show_dictionary(source):
    if len(source) == 0:
        print("\nВ словаре нет значений!")
        return

    dict_str = ""

    # Выделить повторяющиеся элементы
    for key in source:
        dict_str += f"{console_colors.light_magenta} " \
                    f"{key: ^3} {console_colors.terminate} - {source[key]}\n"

    # end for

    print(dict_str)


# Записать словарь в файл в формате csv
def write_dict_to_csv(dictionary, file_path):
    with open(file_path, "w", newline="", encoding='UTF-8') as file:
        dict_writer = csv.DictWriter(file, dictionary.keys())
        dict_writer.writeheader()
        dict_writer.writerow(dictionary)


# Прочитать словарь из файла в формате csv
def read_dict_from_csv(file_path):
    with open(file_path, "r", newline="", encoding='UTF-8') as file:

        # Прочитать 1-ю строку - имена столбцов (ключи)
        str_keys = file.readline().strip()

        if len(str_keys) <= 0:
            return

        keys = re.split("[,;]+", str_keys)

        if keys is None or len(keys) <= 0:
            raise Exception("Прочитать словарь из CSV-файла не вышло!")

        dictionary = {}

        # Прочитать вторую строку - значения
        str_values = file.readline().strip()

        values = re.split("[,;]+", str_values)

        if values is None or len(values) != len(keys):
            raise Exception("Прочитать словарь из CSV-файла не вышло!")

        for i in range(0, len(keys)):
            dictionary[keys[i]] = values[i]

    return dictionary


# Наименования товаров и их цены
goods_names_list = [
    ["чехол для Iphone 13 pro", 2000],
    ["чехол для Iphone 14 ", 2000],
    ["чехол для samsung galaxy s22", 1550],
    ["чехол для samsung galaxy s10 plus", 1400],
    ["защитное стекло для Iphone 13 pro", 1300],
    ["защитное стекло для samsung galaxy s22", 1700],
    ["Подставка для ноутбука HIPER BRISA", 2000],
    ["Подставка для ноутбука HIPER TYPHON", 1700],
    ["samsung s22 ultra", 75_000],
    ["Xiaomi Mi 11 Ultra", 72_000],
    ["xiaomi mi 10 ultra", 65_000],
]


def get_random_product():
    return goods_names_list[get_random_int(0, len(goods_names_list)-1)]


# Генерация списка товаров
def generate_goods_list(size):

    goods = list()

    for i in range(0, size):
        if i < len(goods_names_list):
            goods.append([0,goods_names_list[i][0], goods_names_list[i][1], bool(random.getrandbits(1))])
        else:
            goods_index = get_random_int(0, len(goods_names_list)-1)
            goods.append([
                0,
                goods_names_list[goods_index][0],
                goods_names_list[goods_index][1],
                bool(random.getrandbits(1))
            ])

    return goods


def show_goods(goods):

    if len(goods) == 0:
        print("\nВ контейнере нет значений!")
        return

    list_str = "┌───────┬────────────────────────────────────────┬─────────────────────┬─────────────────┐\n" \
               "│  Id   │         Наименование товара            │   Стоимость товара  │  Наличие товара │\n" \

    index = 0
    # Выделить повторяющиеся элементы
    for item in goods:
        list_str += f"├───────┼────────────────────────────────────────┼─────────────────────┼─────────────────┤\n" \
                    f"|{item[0]: ^7}| {item[1]: <38} | {item[2]: >19} | {'есть в наличии' if item[3] == 1 else 'нет в наличии': ^15} |\n"

        index += 1

    # end for

    print(f"{list_str}"
          f"└───────┴────────────────────────────────────────┴─────────────────────┴─────────────────┘\n")


# Прочитать коллекцию из бинарного файла
def read_collection_from_shelve(file_path):

    collection = list()

    with shelve.open(file_path, flag="c") as goods_file:

        if len(goods_file) <= 0:
            return collection

        for item in goods_file:
            collection.append(goods_file[item])
    return collection


# Ожидать нажатия enter
def wait_for_enter_press():
    print("\nДля входа в меню нажмите enter...")

    import keyboard
    keyboard.wait("enter", True)
