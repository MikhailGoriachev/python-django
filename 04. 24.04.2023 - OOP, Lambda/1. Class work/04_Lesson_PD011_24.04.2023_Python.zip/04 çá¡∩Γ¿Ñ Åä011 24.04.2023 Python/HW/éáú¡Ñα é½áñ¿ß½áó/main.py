import app
import console_colors
import menus


def choose_task(task_number):

    if task_number == "0":
        exit(0)

    try:
        task_number = int(task_number)

        # Нахождение элемента словаря и вызов метода
        menus.main_menu_dict.get(task_number)[1]()

        # print(f"\n\n{console_colors.color_info}Номер задачи ведён неверно!{console_colors.terminate} Введите значение в диапазоне 1 - 4\n")
    except Exception as e:
        raise Exception(f"Номер задачи ведён неверно! Введите значение в диапазоне 1 - 4\n {e}")


# end choose_task

def main():


    while True:

        try:
            tasks = ""

            for value in menus.main_menu_dict.values():
                tasks += f"\n{value[0]}"

            choose_task(input(f"{tasks}\nВведите номер задачи: "))

        except Exception as e:
            print(f"\n\nОшибка при выполнении операции: {console_colors.bright_red} {e} {console_colors.terminate} \n")

    # end while

# end main



if __name__ == '__main__':
    main()
