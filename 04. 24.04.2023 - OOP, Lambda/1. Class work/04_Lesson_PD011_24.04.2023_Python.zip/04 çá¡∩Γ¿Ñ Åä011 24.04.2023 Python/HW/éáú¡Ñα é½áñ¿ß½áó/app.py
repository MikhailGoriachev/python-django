import main
import console_colors


from tasks import task_1
from tasks import task_2
from tasks import task_3
from tasks import task_4

if __name__ == '__main__':
    main.main()


# Задача 1
def task01():
    task_1.fill_sets()
    task_1.calculations()
    task_1.delete_from_set()
# end task02


# Задача 2
def task02():
    task_2.read_file()
    words = task_2.calculations()
    task_2.frequency_dictionary(words)
    task_2.read_dict_from_csv()
# end task02


# Задача 3
def task03():
    task03_menu_dict = {
        "1": [" - столица заданного государства.", task_3.get_capital_of_country],
        "2": [" - государство по заданной странице.", task_3.get_country_from_capital],
        "3": [" - запись словаря в CSV.", task_3.write_to_csv],
        "4": [" - чтение словаря из CSV.", task_3.read_dict_from_csv],
        "5": [" - добавление государства.", task_3.add_item_in_dict],
        "0": [" - выход\n", None]
    }

    while True:

        try:
            tasks = ""

            for key, values in task03_menu_dict.items():
                tasks += f"\n{key}{values[0]}"

            result = input(f"{tasks}\nВведите номер подзадачи задачи для работы с CSV файлами: ")

            if result == '0':
                return
            try:

                task03_menu_dict.get(result)[1]()

            except Exception as e:
                raise Exception(e)

        except Exception as e:
            print(f"\n\nПри выполнении обработок в task 03 упало исключение: {console_colors.bright_red} {e} {console_colors.terminate} \n")

        # end while
# end task03

# Задача 4
def task04():
    task04_menu_dict = {
        "1": [" - прочитать коллекцию из файла.", task_4.read_list_from_file],
        "2": [" - статистика по товарам.", task_4.goods_statistics],
        "3": [" - добавить товар.", task_4.add_product],
        "4": [" - удалить товар.",  task_4.delete_product],
        "5": [" - изменить товар.", task_4.update_product],
        "0": [" - выход\n", None]
    }

    # Создать каталог и сгенерировать коллекцию
    task_4.prepare_folder_and_list()

    while True:

        try:
            tasks = ""

            for key, values in task04_menu_dict.items():
                tasks += f"\n{key}{values[0]}"

            result = input(f"{tasks}\nВведите номер подзадачи задачи для работы с бинарными файлами: ")

            if result == '0':
                return
            try:

                task04_menu_dict.get(result)[1]()

            except Exception as e:
                raise Exception(e)

        except Exception as e:
            print(f"\n\nПри выполнении обработок в task 04 упало исключение: "
                  f"{console_colors.bright_red} {e} {console_colors.terminate} \n")

    # end while
# end task03
