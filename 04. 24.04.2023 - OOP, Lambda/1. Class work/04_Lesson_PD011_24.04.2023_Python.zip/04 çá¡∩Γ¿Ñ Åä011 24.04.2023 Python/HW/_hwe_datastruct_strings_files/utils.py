# вспомогательные функции задания
import math
import random
import shelve

import main


# вывод меню из словаря menu_task, выбор в меню и выполнение команд меню
def do_menu(menu_task, title):
    while True:
        try:
            # вывести меню
            print(title)
            for key, value in menu_task.items():
                print(f'\t \033[34;1m{key}\033[0m. {value[0]}')
            # end for

            # ввести команду меню
            cmd = input('\t    Введите команду: ')

            # специальная команда - выход из цикла
            # обработки меню
            if cmd == '0':
                print()
                break
            # end if

            # выполнить команду меню, если команды нет - сообщить об ошибке
            if cmd in menu_task:
                # получить запись из словаря по ключу cmd, получить ссылку на функцию
                # [0] - текст пункта меню
                # [1] - функция
                menu_task[cmd][1]()
            else:
                raise Exception(f"нет такого пункта меню \033[4m'{cmd}'\033[0m")
            # end if
        except Exception as e:
            print(f'\n\t\t\033[31;1mОшибка: {e}\033[0m\n')
        # end try-except
    # end while
# end do_menu


# region Функции задачи 1

# генерация множества
def gen_set(n_lo, n_hi, lo, hi):
    # размер множества
    n = random.randint(n_lo, n_hi)

    # список случайных не повторяющихся значений для
    # формирования множества
    list_num =  list(range(lo, hi))  # [-1 0 1 2 3 4]

    # перемешать значения в множестве
    random.shuffle(list_num)  # [2 4 0 -1 3 1]

    # вернуть множество из списка
    return set(list_num[:n]) # [2 4 0 -1 3 1][:3] --> [2 4 0]
# end gen_set


# Удаление всех элементов из множества set_data для которых функция
# predicate() вернет True
def delete_items(set_data, predicate):
    # обходим множество и удаляем из него все отрицательные элементы
    # запишем во вспомогательное множество только те элементы исходного
    # множества, которые соответствуют предикату
    deleted = 0  # счетчик удаленных
    for datum in list(set_data):
        if predicate(datum):
            set_data.remove(datum)
            deleted += 1
        # end if
    # end for

    return deleted
# end delete_negatives
# endregion


#region функции для задачи 2
# запись словаря freq_dict в файл формата CSV с именем freq_dict_file
def write_dict(dict_file, data_dict):
    with open(dict_file, "w", encoding='UTF-8') as file:
        # перебор словаря, пишем каждый элемент словаря
        # отдельной строкой в CSV-файл
        for key in data_dict:
            file.write(f'{key},{data_dict[key]}\n')
    # end file
# end write_dict


# чтение словаря из файла формата CSV
def read_dict(file_name):
    countries = {}
    with open(file_name, "r", encoding='UTF-8') as file:
        for line in file:
            words = line.split(',')
            countries[words[0]] = words[1].replace('\n', '')
    # end file
    return countries
# end read_dict


def show_file(title, file_name):
    print(title)

    # открыть файл file_name для чтения с заданной кодировкой
    with open(file_name, "r", encoding='utf-8') as file:
        # чтение из файла построчно
        for line in file:
            # выводим строку, прочитанную из файла в консоль
            print(line, end='')
        # end for
    # end with
    print()
# end show_file


# разбиение строки на слова, символы-разделители задаются в переменной delimiters
# delimiters: разделители для разбиения строки на слова
def split_line(line, delimiters = ',.!?()-\n\t\r'):
    for delimiter in delimiters:
        line = line.replace(delimiter, ' ')
    # end for

    # удалить пустые строки в коллекции слов, получившихся после
    # разбиения строки
    words = line.split(' ')
    while '' in words:
        words.remove('')
    # end while

    return words
# end split_line


# в параметре words возвращает список слов из файла file_name
# возвращает количество строк в файле file_name
def split_file(file_name, words):
    # открыть файл с именем file_name для чтения
    with open(file_name, "r", encoding='utf-8') as lowers_file:
        lines_counter = 0  # счетчик строк
        for line in lowers_file:
            # увеличить счетчик строк
            lines_counter += 1

            # получить список слов в строке
            words_in_line = split_line(line)

            # добавить список слов строки к списку слов текста
            if len(words_in_line) > 0:
                words += words_in_line
            # end if
        # end for
    # end lowers_file
    return lines_counter
# end split_file


# запись в файл file_name слов длины word_len
def write_file(file_name, words, len_word):
    # открыть файл file_name для записи с заданной кодировкой
    with open(file_name, "w", encoding='utf-8') as file:
        # запись из списка слов тех слов, длина которых совпадает с заданной
        for word in words:
            if len(word) == len_word:
                file.write(f'{word}\n')
        # end for
    # end with
# endregion


# region Вспомогательные функции задачи 3
# формирование словаря с данными для решения задачи
def countries_initialize():
    return {
        "Россия": "Москва",
        "Беларусь": "Минск",
        "Молдова": "Кишинев",
        "Румыния": "Бухарест",
        "Турция": "Анкара",
        "Франция": "Париж",
        "Германия": "Берлин",
        "Италия": "Рим",
        "Швейцария": "Берн",
        "Австрия": "Вена",
        "Куба": "Сантьяго",
        "Израиль": "Тель-Авив"
    }
# end countries_initialize


# вывод словаря для описания страны
def show_countries(title, countries):
    # вывод шапки таблицы
    print(f'\t\t\033[30;1m{title}\n'
          '\t┌─────┬────────────────┬────────────────┐\n'
          '\t│  №  │ Название       │ Столица        │\n'
          '\t│ п/п │         страны │         страны │\n'
          '\t├─────┼────────────────┼────────────────┤')

    i = 1
    for country, capital in countries.items():
        print(f'\t│ {i:3} │ {country:14} │ {capital:14} │')
        i += 1
    # end for

    # выводим подвал таблицы
    print('\t└─────┴────────────────┴────────────────┘\033[0m\n')
# end show_countries
# endregion


# region Вспомогательные функции задачи 4
# возвращает список товаров для обработки
def goods_initializer():
    return [
        ['куртка замшевая', 12000, True],  # 1
        ['ручка шариковая', 45, True],  # 2
        ['фотоаппарат импортный', 4500, False],  # 3
        ['кинокамера отечественная', 8800, True],  # 4
        ['сапоги резиновые', 230, False],  # 5
        ['кеды беговые', 70, True],  # 6
        ['тарелка фаянсовая', 80, True],  # 7
        ['кружка алюминиевая', 280, True],  # 8
        ['полотенце банное', 480, False],  # 9
        ['мыло душистое', 280, True],  # 10
        ['мочалка натуральная', 320, True],  # 11
        ['спирт этиловый', 110, True],  # 12
        ['средство моющее', 350, False],  # 13
        ['инсектицид аэрозольный', 280, True]  # 14
    ]
# end goods_initializer


# чтение списка из бинарного файла при помощи модуля shelve
def read_list(file_name):
    data = []
    with shelve.open(file_name) as data_file:
        for datum in data_file:
            data.append(data_file[datum])  # data_file[datum] - собственно чтение
        # end for
    # end with
    return data
# end read_list


# запись списка товаров в бинарный файл при помощи модуля shelve
def write_list(file_name, data):
    # запись файла при помощи модуля shelve
    with shelve.open(file_name) as data_file:
        i = 1
        for datum in data:
            # 'data_file[str(i)] =' вместе с присваиванием это и есть запись в файл
            # ключом словаря в данном случае может быть строка, не может быть int
            data_file[str(i)] = datum
            i += 1
        # end for
    # end with
# end write_list


# выводим список товаров в табличном формате
def show_list_goods(title, data):
    print(f'\t\t\033[30;1m{title}\n'
          '\t┌─────┬──────────────────────────┬────────────┬───────────────┐\n'
          '\t│  №  │ Наименование             │ Стоимость  │ Наличие       │\n'
          '\t│ п/п │              товара      │ ед. товара │        товара │\n'
          '\t├─────┼──────────────────────────┼────────────┼───────────────┤')
    i = 1
    present = 'в наличии  '
    absent = 'отсутствует'
    for goods in data:
        # индекс 0 - наименование товара
        # индекс 1 - цена товара
        # индекс 2 - признак наличия товара
        print(f'\t│ {i:3} │ {goods[0]:24} │ {goods[1]:7}.00 │  {present if goods[2] else absent}  │')
        i += 1
    print('\t└─────┴──────────────────────────┴────────────┴───────────────┘\033[0m\n')
# end show_list_goods


# возвращает сумму товаров, имеющихся в наличии
def sum_presents(list_goods):
    total = 0
    for goods in list_goods:
        # элемент с индексом 2 - признак наличия товара
        # элемент с индексом 1 - цена единицы товара
        if goods[2]:
            total += goods[1]
    # end for

    return total
# end sum_presents
# endregion


# запуск главной функции приложения
if __name__ == '__main__':
    main.main()
# end if
