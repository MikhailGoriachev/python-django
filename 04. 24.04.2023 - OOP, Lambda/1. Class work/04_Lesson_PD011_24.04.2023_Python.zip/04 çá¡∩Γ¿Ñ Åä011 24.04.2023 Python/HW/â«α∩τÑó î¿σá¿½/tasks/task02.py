﻿from infrastructure import utils as u

# Task2. Обработка строк, текстовых файлов. Для файла text.txt, приведенного в папке задания реализуйте обработки 
# (файл скопируйте в Ваш проект при создании проекта):
#   — Перевести текст из исходного файла в нижний регистр, сохранить в файле lowers.txt
#   — В файле lowers.txt подсчитать количество строк, слов, определить максимальную длину слова и список слов 
#     максимальной длины, минимальную длину слова и список слов минимальной длины, сохраните списки слов в файлах 
#     longest.txt и shortest.txt соответственно для слов максимальной и минимальной длины
#   — Сформируйте словарь из слов файла lowers.txt – ключом является слово, значением – количество вхождений этого слова 
#     в текст. Сохраните этот словарь в формате CSV, имя файла words.csv


# названия файлов
text_file = "app_data/text.txt"
lowers_file = "app_data/lowers.txt"
longest_file = "app_data/longest.txt"
shortest_file = "app_data/shortest.txt"
words_file = "app_data/words.csv"


# перевести текст из исходного файла в нижний регистр, сохранить в файле lowers.txt
def proc01():
    text = get_text(text_file)

    print(u.green_l('\nЗадание 2. Строки > Перевод в нижний регистр\n'))

    # вывод исходного текста
    print(u.green_l(f'Исходный текст из файла {text_file}:\n'))
    print(u.cyan(text), end='\n\n')

    # запись в файл результата обработки
    with open(lowers_file, 'w', encoding='utf-8') as file:
        file.write(text.lower())

    # вывод обработанного текста
    print(u.green_l(f'Обработанный текст в файле {lowers_file}:\n'))
    print(u.cyan(get_text(lowers_file)), end='\n\n')


# получить текст из файла
def get_text(file_name: str):
    with open(file_name, 'r', encoding='utf-8') as file:
        return file.read()


if __name__ == "__main__":
    from main import main

    main()
