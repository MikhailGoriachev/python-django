﻿import tasks.task01 as task01
import tasks.task02 as task02
import infrastructure.utils as u


# Task1. Обработка множеств. Разработайте функцию, в которой используются два множества из случайных целых чисел. 
# Функция должна обеспечивать:
#   — Формирование множеств – используйте операцию добавления в множество, длина каждого множества определяется 
#     генератором случайных чисел (от 5и до 23х элементов), диапазон значений элементов: -20, 20;
#   — Вычисление пересечения множеств;
#   — Вычисление разности множеств;
#   — Вычисление объединения множеств;
#   — Удаление всех отрицательных элементов из множества с меньшим количеством элементов 

# 1. Формирование множеств
def point01():
    print(u.green_l('1. Формирование множеств'))

    task01.set_values_a = task01.create_set()
    task01.set_values_b = task01.create_set()

    task01.show_set('Множество A', task01.set_values_a)
    task01.show_set('Множество B', task01.set_values_b)


# 2. Вычисление пересечения множеств
def point02():
    print(u.green_l('2. Вычисление пересечения множеств'))

    task01.show_set('Множество A', task01.set_values_a)
    task01.show_set('Множество B', task01.set_values_b)

    intersection = task01.get_intersection(task01.set_values_a, task01.set_values_b)

    task01.show_set('Пересечение', intersection)


# 3. Вычисление разности множеств
def point03():
    print(u.green_l('3. Вычисление разности множеств'))

    task01.show_set('Множество A', task01.set_values_a)
    task01.show_set('Множество B', task01.set_values_b)

    different = task01.get_different(task01.set_values_a, task01.set_values_b)

    task01.show_set('Разность', different)


# 4. Вычисление объединения множеств
def point04():
    print(u.green_l('4. Вычисление объединения множеств'))

    task01.show_set('Множество A', task01.set_values_a)
    task01.show_set('Множество B', task01.set_values_b)

    join = task01.get_join(task01.set_values_a, task01.set_values_b)

    task01.show_set('Объединение', join)


# 5. Удаление всех отрицательных элементов из множества с меньшим количеством элементов
def point05():
    print(u.green_l('5. Удаление всех отрицательных элементов из множества с меньшим количеством элементов'))

    task01.show_set('Множество A', task01.set_values_a)
    task01.show_set('Множество B', task01.set_values_b)

    set_and_title = (task01.set_values_a, 'A') \
        if len(task01.set_values_a) > len(task01.set_values_b) \
        else (task01.set_values_b, 'B')

    task01.show_set(f'Множество с наименьшим количеством элементов {set_and_title[1]}', set_and_title[0])

    task01.remove_negative(set_and_title[0])

    task01.show_set('Множество после удаления', set_and_title[0])


# 6. Перевести текст из исходного файла в нижний регистр
def point06():
    task02.proc01()


if __name__ == "__main__":
    from main import main

    main()
