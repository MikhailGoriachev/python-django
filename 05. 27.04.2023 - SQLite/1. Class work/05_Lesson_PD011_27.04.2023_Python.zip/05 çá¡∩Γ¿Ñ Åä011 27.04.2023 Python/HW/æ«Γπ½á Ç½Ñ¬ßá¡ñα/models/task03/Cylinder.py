import math

from models.task03.Figure3D import Figure3D


class Cylinder(Figure3D):
    def __init__(self, radius, height):
        super().__init__(radius, 'Цилиндр')

        self.height = height

    # высота
    @property
    def height(self):
        return self.__height

    @height.setter
    def height(self, value):
        if value <= 0:
            raise Exception('Высота должна быть положительной')

        self.__height = value

    # метод вычисления площади
    def area(self):
        return 2 * math.pi * self.radius * (self.height + self.radius)

    # метод вычисления объема
    def volume(self):
        return math.pi * self.radius * self.radius * self.height

    def __str__(self):
        return f'│ {self.title:17} │ {self.radius:12.2f} │  {self.height:6.2f}  │ {"-"*12} │ {self.volume():9.2f} │ {self.area():11.2f} │'