# •	Базовый класс Фигура3D со свойством радиус
# пустыми методами для вычисления площади и объема (
# имеются в виду объявления вида def area(): pass и
# def volume(): pass)

class Figure3D:

    # конструктор
    def __init__(self, radius, title):
        self.radius = radius
        self.title = title

    # радиус
    @property
    def radius(self):
        return self.__radius

    @radius.setter
    def radius(self, value):
        if value <= 0:
            raise Exception('Радиус должен быть положительным')

        self.__radius = value

    @property
    def title(self):
        return self.__title

    @title.setter
    def title(self, value):
        if not value:
            raise Exception('Название фигуры должно быть указано')
        self.__title = value

    # метод для вычисления площади
    def area(self):
        pass

    # метод для вычисления объема
    def volume(self):
        pass
