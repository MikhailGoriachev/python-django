import math

from models.task03.Figure3D import Figure3D


# чтобы не нарушать спецификацию(да и просто ради интереса) в которой указано
# что в базовом классе должен быть радиус и не
# нарушать логику обращений к атрибутам внутри класса(чтобы не обращаться к радиусу,
# подразумевая под ней сторону треугольника),
# радиус оставляем но при попытке обратиться к нему просто уходим,
# если выбрать путь через генерацию исключения - каждый раз вызывается свойство радиуса
# текущего класса и постоянно получаем исключение
class TrianglePyramid(Figure3D):
    def __init__(self, height, side):
        super().__init__(1, 'Треугольник')

        self.height = height
        self.side = side

    # высота
    @property
    def height(self):
        return self.__height

    @height.setter
    def height(self, value):
        if value <= 0:
            raise Exception('Высота должна быть положительной')
        self.__height = value

    # сторона
    @property
    def side(self):
        return self.__side

    @side.setter
    def side(self, value):
        if value <= 0:
            raise Exception('Сторона должна быть положительной')
        self.__side = value

    # радиус
    @property
    def radius(self):
        return

    @radius.setter
    def radius(self, value):
        return

    # метод вычисления площади
    def area(self):
        aa = self.side ** 2
        bb = aa + self.height ** 2
        return (aa * math.sqrt(3) + 6 * self.side * math.sqrt(bb - aa / 4)) / 4

    # метод вычисления объема
    def volume(self):
        return self.height * self.side ** 2 / (4 * math.sqrt(3))

    def __str__(self):
        return f'│ {self.title:17} │ {"-" * 12} │  {self.height:6.2f}  │ {self.side:12.2f} │ {self.volume():9.2f} │ {self.area():11.2f} │'
