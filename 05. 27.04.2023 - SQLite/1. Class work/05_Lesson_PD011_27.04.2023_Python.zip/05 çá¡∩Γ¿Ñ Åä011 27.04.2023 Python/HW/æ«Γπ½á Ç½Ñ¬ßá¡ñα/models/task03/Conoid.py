import math

from models.task03.Figure3D import Figure3D


class Conoid(Figure3D):
    def __init__(self, radius, height):
        super().__init__(radius, 'Конус')

        self.height = height

    # высота
    @property
    def height(self):
        return self.__height

    @height.setter
    def height(self, value):
        if value <= 0:
            raise Exception('Высота должна быть положительной')
        self.__height = value

    # метод вычисления площади
    def area(self):
        l = math.sqrt(self.height ** 2 + self.radius ** 2)
        return math.pi * self.radius * l + math.pi * self.radius ** 2

    # метод вычисления объема
    def volume(self):
        return (math.pi * self.radius ** 2 * self.height) / 3

    def __str__(self):
        return f'│ {self.title:17} │ {self.radius:12.2f} │  {self.height:6.2f}  │ {"-"*12} │ {self.volume():9.2f} │ {self.area():11.2f} │'