import random


# Разработайте класс Plane со следующими свойствами (
# созданными при помощи декораторов):
# •	тип самолета (Ил-76, Boeing-747, …)
# •	количество пассажирских мест (целое число, от 0 и выше)
# •	текущее количество пассажиров
# •	расход горючего за час полета (вещественное число, от 0 и выше)
# •	количество двигателей (целое число, от 1 до 12)
# •	название авиакомпании владельца самолета (непустая строка)
# В свойствах-сеттерах выбрасывайте исключение при некорректных значениях.
# Разработайте конструктор __init__() и метод формирования
# строкового представления __str__() в виде строки таблицы.


class Plane:

    def __init__(self, company,
                 plane_type, passenger_seat=0,
                 current_passengers=0, fuel_consumption_per_hour=0,
                 count_engines=0,
                 ):
        self.company = company
        self.plane_type = plane_type
        self.passenger_seat = passenger_seat
        self.current_passengers = current_passengers
        self.fuel_consumption_per_hour = fuel_consumption_per_hour
        self.count_engines = count_engines

    # название авиакомпании
    @property
    def company(self):
        return self.__company

    @company.setter
    def company(self, value):
        # PEP8. For sequences, (strings, lists, tuples), use the fact that empty sequences are false
        if not value:
            raise Exception('Название авиакомпании не может быть пустым')

        self.__company = value

    # тип самолета
    @property
    def plane_type(self):
        return self.__plane_type

    @plane_type.setter
    def plane_type(self, value):
        if not value:
            raise Exception('Тип самолета не может быть пустым')

        self.__plane_type = value

    # количество пассажирских мест
    @property
    def passenger_seat(self):
        return self.__passenger_seat

    @passenger_seat.setter
    def passenger_seat(self, value):
        if value < 0:
            raise Exception('Количество пассажирских мест должно быть от 0 и выше')

        self.__passenger_seat = value

    # текущее количество пассажиров
    @property
    def current_passengers(self):
        return self.__current_passengers

    @current_passengers.setter
    def current_passengers(self, value):
        if value < 0 or value > self.__passenger_seat:
            raise Exception(
                f'Количество пассажиров должно быть 0 или больше, но не более чем {self.__passenger_seat}')

        self.__current_passengers = value

    # расход горючего за час полета
    @property
    def fuel_consumption_per_hour(self):
        return self.__fuel_consumption_per_hour

    @fuel_consumption_per_hour.setter
    def fuel_consumption_per_hour(self, value):
        if value < 0:
            raise Exception(f'Расход горючего не может быть меньше нуля')

        self.__fuel_consumption_per_hour = value

    # количество двигателей
    @property
    def count_engines(self):
        return self.__count_engines

    @count_engines.setter
    def count_engines(self, value):
        if 1 > value > 12:
            raise Exception(f'Расход горючего не может быть меньше нуля')

        self.__count_engines = value

    def add_passengers(self, value):
        self.current_passengers += value

    # метод формирования строкового представления
    # в виде строки таблицы
    def __str__(self):
        return f'│ {self.__company:25} ' \
               f'│ {self.__plane_type:25} ' \
               f'│ {self.__passenger_seat:14} ' \
               f'│ {self.__current_passengers:23} ' \
               f'│ {self.__fuel_consumption_per_hour:23.2f} ' \
               f'│ {self.__count_engines:19} │'

    # шапка таблицы
    header = \
        '\t┌─────┬───────────────────────────┬───────────────────────────┬────────────────┬─────────────────────────┬─────────────────────────┬─────────────────────┐\n' \
        '\t│  №  │       Авиакомпания        │       Тип самолета        │   Кол-во мест  │    Кол-во пассажиров    │  Расход топлива т/час   │  Кол-во двигателей  │\n' \
        '\t├─────┼───────────────────────────┼───────────────────────────┼────────────────┼─────────────────────────┼─────────────────────────┼─────────────────────┤'

    # подвал таблицы
    footer = \
        '\t└─────┴───────────────────────────┴───────────────────────────┴────────────────┴─────────────────────────┴─────────────────────────┴─────────────────────┘'

    # генерация самолета
    @staticmethod
    def generate_plane():
        # авиакомпании
        companies = [
            'Nordwind Airlines',
            'Red Wings Airlines',
            'Победа'
        ]

        # типы самолетов
        plane_types = [
            # ('Ил-76', 120, 4, 6500),  # plane_types[i][1]
            'Ил-76',
            'Boeing-747',
            'Ту-134',
            'SSJ-95',
            'Airbus A320',
            'Boeing-777',
            'Ту-154',
            'Boeing-747',
            'Airbus A380',
            'Douglas DC-3'
        ]

        # для генерации пассажирских мест и количества пассажиров
        MIN_PASSENGERS, MAX_PASSENGERS = 100, 500

        # для генерации кол-ва двигателей
        MIN_ENGINES, MAX_ENGINES = 1, 12

        # для генерации расхода топлива
        MIN_FUEL, MAX_FUEL = 0, 30

        # генерация названия авиакомпании
        company = companies[random.randint(0, len(companies) - 1)]

        # генерация типа самолета
        plane_type = plane_types[random.randint(0, len(plane_types) - 1)]

        # генерация кол-ва пассажирских мест
        passenger_seat = random.randint(MIN_PASSENGERS, MAX_PASSENGERS)

        # текущее количество пассажиров
        current_passengers = 0
        # генерация текущего количества пассажирова,
        # но не больше чем кол-во пассажирских мест
        while True:
            generated_curr_passengers = random.randint(MIN_PASSENGERS, MAX_PASSENGERS)
            if generated_curr_passengers <= passenger_seat:
                current_passengers = generated_curr_passengers
                break

        # генерация расхода горючего
        fuel_consumption_per_hour = random.uniform(MIN_FUEL, MAX_FUEL)

        # генерация кол-ва двигателей
        count_engines = random.randint(MIN_ENGINES, MAX_ENGINES)

        return Plane(company, plane_type, passenger_seat, current_passengers, fuel_consumption_per_hour, count_engines)
