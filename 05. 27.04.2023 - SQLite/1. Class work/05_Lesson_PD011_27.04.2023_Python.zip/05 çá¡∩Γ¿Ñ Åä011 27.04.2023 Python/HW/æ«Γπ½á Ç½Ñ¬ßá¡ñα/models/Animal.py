# Создайте класс Animal со свойствами (созданными при помощи декораторов) для хранения:
# •	клички животного,
# •	веса (в кг),
# •	возраста (в полных годах),
# •	цвета (масть) животного,
# •	фамилии и инициалов владельца (Иванов И.И., …).
# Реализуйте конструктор __init__(), свойства, метод __str__()
# метод вывода данных животного в виде строки таблицы.
import random


class Animal:

    # конструктор
    def __init__(self, name,
                 weight, age,
                 color, owner):
        self.name = name
        self.weight = weight
        self.age = age
        self.color = color
        self.owner = owner

    # кличка животного
    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, value):
        if not value:
            raise Exception('Кличка животного должна быть указана')
        self.__name = value

    # вес животного
    @property
    def weight(self):
        return self.__weight

    @weight.setter
    def weight(self, value):
        if value <= 0:
            raise Exception('Вес животного должен быть больше 0')
        self.__weight = value

    # возраст животного
    @property
    def age(self):
        return self.__age

    @age.setter
    def age(self, value):
        if value <= 0:
            raise Exception('Возраст животного должен быть больше 0')
        self.__age = value

    # цвет животного
    @property
    def color(self):
        return self.__color

    @color.setter
    def color(self, value):
        if not value:
            raise Exception('Цвет животного должен быть указан')
        self.__color = value

    # владелец животного
    @property
    def owner(self):
        return self.__owner

    @owner.setter
    def owner(self, value):
        if not value:
            raise Exception('Владелец животного должен быть указан')
        self.__owner = value

    # метод формирования строкового представления
    def __str__(self):
        return f'\tКличка  : {self.__name}' \
               f'\tВес     : {self.__weight} кг.' \
               f'\tВозраст : {self.__age}' \
               f'\tЦвет    : {self.__color}' \
               f'\tВладелец: {self.__owner}'

    def to_table_row(self, n):
        return f'\t│ {n:3} ' \
               f'│ {self.__name:25} ' \
               f'│ {self.__weight:13.2f} ' \
               f'│ {self.__age:9} ' \
               f'│ {self.__color:26} ' \
               f'│ {self.__owner:19} │'

    # шапка таблицы
    header = \
        '\t┌─────┬───────────────────────────┬───────────────┬───────────┬────────────────────────────┬─────────────────────┐\n' \
        '\t│  №  │     Кличка животного      │    Вес, кг    │  Возраст  │    Цвет(масть) животного   │       Владелец      │\n' \
        '\t├─────┼───────────────────────────┼───────────────┼───────────┼────────────────────────────┼─────────────────────┤'

    # подвал таблицы
    footer = \
        '\t└─────┴───────────────────────────┴───────────────┴───────────┴────────────────────────────┴─────────────────────┘'

    @staticmethod
    def generate_animal():
        # клички животных
        names = [
            'Барон', 'Дымок', 'Феликс',
            'Кекс', 'Персик', 'Аврора',
            'Плотва', 'Бусинка', 'Афина',
            'Маркиз',
        ]

        # цвета животных
        colors = [
            'Белый', 'Шоколадный', 'Чёрный',
            'Кремовый', 'Пегий', 'Смокинг',
            'Дымчатый',
        ]

        # владельцы животных
        owners = [
            'Лукина М. М.', 'Козловский В. Г.', 'Назаров А. Т.',
            'Гаврилова Е. Д.', 'Сидорова С. С.', 'Лопатина Л. А.',
            'Семенов М. Т.', 'Самойлова В. М.', 'Еремин П. А.',
            'Агеев А. И.',
        ]

        # диапазон для генерации
        MIN_WEIGHT, MAX_WEIGHT = 1, 10
        MIN_AGE, MAX_AGE = 1, 10

        return Animal(names[random.randint(0, len(names) - 1)], random.uniform(MIN_WEIGHT, MAX_WEIGHT),
                     random.randint(MIN_AGE, MAX_AGE), colors[random.randint(0, len(colors) - 1)],
                     owners[random.randint(0, len(owners) - 1)])
