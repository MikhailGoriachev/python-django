import utils
from controllers.Task01Controller import Task01Controller
from controllers.Task02Controller import Task02Controller
from controllers.Task03Controller import Task03Controller


def main():

    menu = {
        '1': ['Класс Plane', Task01Controller().run],
        '2': ['Класс Animal', Task02Controller().run],
        '3': ['Иерархия классов', Task03Controller().run],
        '0': ['Выход', 0]
    }

    utils.process_menu('МЕНЮ ПРИЛОЖЕНИЯ',menu)

if __name__ == '__main__':
    main()
