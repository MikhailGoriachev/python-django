import random

from models.Animal import Animal
from models.Plane import Plane

# генерация списка самолетов
def get_planes_list():
    planes = []
    MIN_SIZE, MAX_SIZE = 10, 15

    for i in range(0, random.randint(MIN_SIZE, MAX_SIZE)):
        planes.append(Plane.generate_plane())

    return planes

# генерация списка животных
def get_animals_list():
    animals = []
    SIZE = 10

    for i in range(0, SIZE):
        animals.append(Animal.generate_animal())

    return animals


def process_menu(title, menu_task):
    while True:
        try:
            print(f'\n\t\t~~~~ {title} ~~~~')
            # вывод строк меню
            for key, value in menu_task.items():
                print(f'{key}. {value[0]}')

            # получить пункт меню от пользователя
            cmd = input('\nВаш выбор: ')

            # выход из меню
            if cmd == '0':
                break

            if cmd in menu_task:
                menu_task[cmd][1]()
            else:
                raise Exception(f'\n\t\t\t\t~~~~~~~~ Нет такого пункта меню ~~~~~~~~\n')
        except Exception as ex:
            print(ex)
