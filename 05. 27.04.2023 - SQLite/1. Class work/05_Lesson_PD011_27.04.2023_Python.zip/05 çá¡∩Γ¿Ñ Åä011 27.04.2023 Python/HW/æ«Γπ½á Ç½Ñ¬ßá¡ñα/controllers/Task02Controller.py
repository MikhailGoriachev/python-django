import random

import utils
from models.Animal import Animal


# Создайте при помощи конструкторов список из 10 животных,
# выведите список в консоль.
# Разработайте функцию, при помощи цикла находящую всех животных,
# возраст которых больше заданного с клавиатуры.
# Поместить найденных животных в дополнительный список, удалив животных из
# исходного списка. Выводите в консоль списки до и после вызова этой функции.
# Реализуйте сортировки списка животных:
# •	По убыванию возраста
# •	По кличке
# •	По возрасту и по цвету (сортировка по двум полям)
# •	По фамилии и инициалам владельца


class Task02Controller:

    # конструктор
    def __init__(self):
        self.__animals = None

    def run(self):
        # начальная инициализация, если вынести в конструктор
        # при повторном запуске работаем со старой коллекцией
        self.__animals = utils.get_animals_list()

        print(f'\n\033[36;1mЗадача 2.\n\033[0m')

        self.__show_animals('Вывод списка животных в виде таблицы', self.__animals)

        # сортировка по убыванию возраста
        self.__sort_by_desc_age()

        # сортировка по кличке
        self.__sort_by_name()

        # сортировка по возрасту и цвету
        self.__sort_by_age_and_color()

        # сортировка по владельцу
        self.__sort_by_owner()

        # перемешать список после сортировок
        random.shuffle(self.__animals)

        # вывод перемешанного списка
        self.__show_animals('Список животных до обработки', self.__animals)

        # после обработки получаем список отобранных животных
        # и значение введенное пользователем
        old_animals, age = self.__process_list_animals()

        # вывод списков после обработки
        self.__show_animals('Исходный список животных после обработки', self.__animals)
        self.__show_animals(f'Список отобранных животных старше {age}', old_animals)

    # вывод в таблицу
    def __show_animals(self, title, animals):
        print(f'\n\t\033[36;1m{title}\033[0m')
        print(Animal.header)

        for i in range(0, len(animals)):
            print(animals[i].to_table_row(i + 1))

        print(Animal.footer)

    # сортировка по убыванию возраста
    def __sort_by_desc_age(self):
        self.__animals.sort(key=lambda animal: animal.age, reverse=True)

        self.__show_animals('Cписок животных отсортированных по убыванию возраста', self.__animals)

    # сортировка по кличке
    def __sort_by_name(self):
        self.__animals.sort(key=lambda animal: animal.name)

        self.__show_animals('Cписок животных отсортированных по кличке', self.__animals)

    # сортировка по возрасту и цвету
    def __sort_by_age_and_color(self):
        self.__animals.sort(key=lambda animal: (animal.age, animal.color))

        self.__show_animals('Cписок животных отсортированных по возрасту и цвету', self.__animals)

    # сортировка по фамилии и инициалам владельца
    def __sort_by_owner(self):
        self.__animals.sort(key=lambda animal: animal.owner)

        self.__show_animals('Cписок животных отсортированных по фамилии и инициалам владельца', self.__animals)

    # отбор животных старше введеного возрасту
    def __process_list_animals(self):
        # ввод пользователя
        age = 0
        while True:
            age = input(f'\tВведите возраст для отбора животных: ')
            if age.isnumeric():
                break
            print('\n\tНеобходимо ввести целое, числовое значение\n')

        # список для хранения выбранных животных
        selected_animals = []

        # удаление животных из исходной колекции
        # и запись в результирующую
        age = int(age)
        for i in range(len(self.__animals) - 1, -1, -1):
            if self.__animals[i].age > age:
                selected_animals.append(self.__animals.pop(i))

        return selected_animals, age
