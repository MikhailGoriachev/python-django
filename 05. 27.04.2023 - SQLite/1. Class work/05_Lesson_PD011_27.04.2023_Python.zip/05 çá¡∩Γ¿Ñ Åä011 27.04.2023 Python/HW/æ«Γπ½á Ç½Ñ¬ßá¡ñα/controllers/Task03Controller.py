import random

from models.task03.Conoid import Conoid
from models.task03.Cylinder import Cylinder
from models.task03.TrianglePyramid import TrianglePyramid


class Task03Controller:
    def __init__(self):
        self.__figures = None

    def run(self):
        print(f'\n\033[36;1mЗадача 3.\n\033[0m')

        # диапазон генерации
        MIN_VALUE, MAX_VALUE = 1, 10

        # инициализация списка фигур
        self.__figures = [
            Conoid(random.uniform(MIN_VALUE, MAX_VALUE), random.uniform(MIN_VALUE, MAX_VALUE)),
            Conoid(random.uniform(MIN_VALUE, MAX_VALUE), random.uniform(MIN_VALUE, MAX_VALUE)),
            Cylinder(random.uniform(MIN_VALUE, MAX_VALUE), random.uniform(MIN_VALUE, MAX_VALUE)),
            Cylinder(random.uniform(MIN_VALUE, MAX_VALUE), random.uniform(MIN_VALUE, MAX_VALUE)),
            TrianglePyramid(random.uniform(MIN_VALUE, MAX_VALUE), random.uniform(MIN_VALUE, MAX_VALUE)),
            TrianglePyramid(random.uniform(MIN_VALUE, MAX_VALUE), random.uniform(MIN_VALUE, MAX_VALUE))
        ]

        # вывод фигур
        self.__show_figures()

        # суммарные площадь и объем фигур
        total_volume = self.__calc_total_volume()
        total_area = self.__calc_total_area()

        # вывод результата подсчета
        self.__show_calc_result(total_volume, total_area)

    # вывести фигуры
    def __show_figures(self):
        print(
            '\t┌─────┬───────────────────┬──────────────┬──────────┬──────────────┬───────────┬─────────────┐\n' \
            '\t│  №  │     Название      │    Радиус    │  Высота  │    Сторона   │   Объем   │   Площадь   │\n' \
            '\t├─────┼───────────────────┼──────────────┼──────────┼──────────────┼───────────┼─────────────┤')

        for i in range(0, len(self.__figures) - 1):
            print(f'\t│ {i + 1:3} {self.__figures[i]}')

        print('\t└─────┴───────────────────┴──────────────┴──────────┴──────────────┴───────────┴─────────────┘')

    # суммарная площадь фигур
    def __calc_total_area(self):
        total_area = 0

        for figure in self.__figures:
            total_area += figure.area()

        return total_area

    # суммарный объем фигур
    def __calc_total_volume(self):
        total_volume = 0

        for figure in self.__figures:
            total_volume += figure.volume()

        return total_volume

    def __show_calc_result(self, total_volume, total_area):
        print(f'{" " * 65} Итого: {total_volume:9.2f}  {total_area:12.2f}')
