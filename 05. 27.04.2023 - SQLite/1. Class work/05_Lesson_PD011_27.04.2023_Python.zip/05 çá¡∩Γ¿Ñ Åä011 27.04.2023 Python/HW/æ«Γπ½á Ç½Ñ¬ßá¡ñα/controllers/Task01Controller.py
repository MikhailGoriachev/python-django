import random

import utils
from models.Plane import Plane


# Создайте список самолетов (не менее 10 элементов).Разработайте функции для обработки списка:
# •	Вывод списка самолетов в виде таблицы
# •	Увеличение количества пассажиров на введенное с клавиатуры значение
# •	Удаление выбранного по номеру в списке самолета
# •	Реализуйте сортировки списка самолетов:
#   o	По типу самолета
#   o	По убыванию количества двигателей
#   o	По названию авиакомпании владельца самолета
#   o	По убыванию расхода горючего за час полета


class Task01Controller:

    # конструктор
    def __init__(self):
        self.__planes = None

    def run(self):
        # начальная инициализация, если вынести в конструктор
        # при повторном запуске работаем со старой коллекцией
        self.__planes = utils.get_planes_list()

        print(f'\n\033[36;1mЗадача 1.\n\033[0m')
        print(f'\t\033[36;1mВывод списка самолетов в виде таблицы\033[0m')
        self.__show_planes()

        # Увеличение количества пассажиров
        self.__increase_passengers()

        # Удаление самолета
        self.__delete_plane()

        # сортировка по типу самолета
        self.__sort_by_plane_type()

        # сортировка по убыванию кол-ва двигателей
        self.__sort_by_desc_count_engines()

        # сортировка по названию авиакомпании
        self.__sort_by_company()

        # сортировка по убыванию расхода горючего
        self.__sort_by_desc_fuel_consumption()

    # вывод в таблицу
    def __show_planes(self):
        print(Plane.header)

        for i in range(0, len(self.__planes)):
            print(f'\t│ {i + 1:3} {self.__planes[i]}')

        print(Plane.footer)

    # Увеличение количества пассажиров
    def __increase_passengers(self):
        while True:
            try:
                print(f'\n\t\033[36;1mУвеличение количества пассажиров\033[0m')

                select_number_plane = int(
                    input(f'\tВведите порядковый номер самолета для увеличения количества пассажиров: ')) - 1

                if 0 <= select_number_plane < len(self.__planes):
                    count_add_passengers = int(input(f'\n\tВведите количество пассажиров для добавления: '))
                    self.__planes[select_number_plane].add_passengers(count_add_passengers)

                    print(f'\n\t\033[36;1mCписок самолетов после увеличения количества пассажиров\033[0m')
                    self.__show_planes()
                    break
                else:
                    print('\n\tСамолет с таким порядковым номером отсутствует')
            except Exception as ex:
                print(f'\t{ex}')

    # Удаление самолета
    def __delete_plane(self):
        print(f'\n\t\033[36;1mУдаление самолета\033[0m')

        select_number_plane = int(
            input(f'\tВведите порядковый номер самолета для удаления: ')) - 1

        if 0 < select_number_plane < len(self.__planes):

            self.__planes.pop(select_number_plane)

            print(f'\n\t\033[36;1mCписок самолетов после удаления\033[0m')
            self.__show_planes()
        else:
            print('\nСамолет с таким порядковым номером отсутствует')

    # сортировка по типу самолета
    def __sort_by_plane_type(self):
        self.__planes.sort(key=lambda plane: plane.plane_type)

        print(f'\n\t\033[36;1mCписок самолетов отсортированных по типу самолета\033[0m')
        self.__show_planes()

    # сортировка по убыванию кол-ва двигателей
    def __sort_by_desc_count_engines(self):
        self.__planes.sort(key=lambda plane: plane.count_engines, reverse=True)

        print(f'\n\t\033[36;1mCписок самолетов отсортированных по убыванию количества двигателей\033[0m')
        self.__show_planes()

    # сортировка по названию авиакомпании
    def __sort_by_company(self):
        self.__planes.sort(key=lambda plane: plane.company)

        print(f'\n\t\033[36;1mCписок самолетов отсортированных по названию авиакомпании\033[0m')
        self.__show_planes()

    # сортировка по убыванию расхода горючего
    def __sort_by_desc_fuel_consumption(self):
        self.__planes.sort(key=lambda plane: plane.fuel_consumption_per_hour, reverse=True)

        print(f'\n\t\033[36;1mCписок самолетов отсортированных по убыванию расхода горючего\033[0m')
        self.__show_planes()
