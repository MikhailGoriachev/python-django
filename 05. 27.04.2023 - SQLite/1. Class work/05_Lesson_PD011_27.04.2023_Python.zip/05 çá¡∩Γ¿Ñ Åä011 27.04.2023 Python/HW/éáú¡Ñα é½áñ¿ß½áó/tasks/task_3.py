import main
import console_colors
import utils
from models.figures.Figure3D import Figure3D

if __name__ == '__main__':
    main.main()

figures_list = utils.get_figures()

# Вывод коллекции фигур
def show_figures_list():

    print("\nКоллекция фигур")
    utils.show_objects(figures_list, Figure3D.header, Figure3D.footer)

    # Ожидать нажатия enter
    utils.wait_for_enter_press("Для продолжения выполннения задачи нажмите enter...")


# Вычисление суммы площадей и объёмов фигур
def calculate():

    print("\nВычисление суммы площадей и объёмов фигур ")

    areas_summ = 0
    for figure in figures_list:
        areas_summ += figure.area()

    volumes_summ = 0
    for figure in figures_list:
        volumes_summ += figure.volume()

    print(f"\n\tСумма площадей:{console_colors.blue_back_highlight} {areas_summ:.3f} {console_colors.terminate}")
    print(f"\n\tСумма объемов: {console_colors.blue_back_highlight} {volumes_summ:.3f} {console_colors.terminate}")

    # Ожидать нажатия enter
    utils.wait_for_enter_press("Для выхода в меню нажмите enter...")
