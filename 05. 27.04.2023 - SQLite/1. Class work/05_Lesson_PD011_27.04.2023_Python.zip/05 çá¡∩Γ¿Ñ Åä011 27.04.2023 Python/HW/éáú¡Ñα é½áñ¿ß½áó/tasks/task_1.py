import main
import console_colors
import utils
from models.Plane import Plane

if __name__ == '__main__':
    main.main()

planes_list = list()


def show_planes_list():
    planes_list.sort(key=lambda plane: plane.id)

    print("\nВывод коллекции самолётов:\n")
    utils.show_objects(planes_list, Plane.header, Plane.footer)

    # Ожидать нажатия enter
    utils.wait_for_enter_press("Для продолжения выполннения задачи нажмите enter...")


# Увеличение количества пассажиров на введенное с клавиатуры значение
def increase_passengers_amount():

    # Ввести id самолёта для изменения
    plane_id = int(input("\nВведите id изменяемого самолёта: "))

    selected_plane = None
    index = 1

    # Найти выбранный самолёт
    for i in range(0, len(planes_list)):
        if planes_list[i].id == plane_id:
            selected_plane = planes_list[i]
            index = i
            break

    if selected_plane is None or index < 0:
        raise Exception(f"самолёт с id: {plane_id} не существует")

    # Получить доступное количество мест
    available_places = selected_plane.capacity - selected_plane.passengers_amount

    # Проверить заполненность самолёта
    if available_places > 0:
        passengers_amount = int(input(f"\nВведите кол-во пассажиров >= 0 и <= {available_places}: "))
    else:
        raise Exception(f"Все места в самолете заняты! Добавить пассажиров невозможно")

    # Запомнить предыдущее количество пассажиров
    amount_prev = selected_plane.passengers_amount

    planes_list[index].passengers_amount += passengers_amount

    print(f"\nВывод коллекции самолётов после изменения записи с id: {selected_plane.id}"
          f"\n\nКоличество пассажиров увеличено с {amount_prev} до {planes_list[index].passengers_amount}:")
    utils.show_planes(planes_list, lambda plane: plane.id == selected_plane.id)

    # Ожидать нажатия enter
    utils.wait_for_enter_press("Для продолжения выполннения задачи нажмите enter...")


# Удаление выбранного по номеру в списке самолета
def delete_plane_by_id():

    # Ввести id самолёта для удаления
    plane_id = int(input("\nВведите id удаляемого самолёта: "))

    is_found = False

    # Найти и удалить выбранный самолёт
    for i in range(0, len(planes_list)):
        if planes_list[i].id == plane_id:
            planes_list.remove(planes_list[i])
            is_found = True
            break

    if not is_found:
        raise Exception(f"самолёт с id: {plane_id} не существует!")

    print(f"\nВывод коллекции самолётов после удаления записи с id: {plane_id}")
    utils.show_objects(planes_list, Plane.header, Plane.footer)

    # Ожидать нажатия enter
    utils.wait_for_enter_press("Для продолжения выполннения задачи нажмите enter...")


# Сортировки списка самолетов по заданию
def sort_planes_list():

    print(f"\nСортировка коллекции самолётов {console_colors.blue_back_highlight} по типу {console_colors.terminate}")

    planes_list.sort(key=lambda plane: plane.plane_type)

    utils.show_objects(planes_list, Plane.header, Plane.footer)

    print(f"\nСортировка коллекции самолётов  "
          f"{console_colors.blue_back_highlight} по убыванию количества двигателей {console_colors.terminate}")

    planes_list.sort(key=lambda plane: plane.engines_amount, reverse=True)

    utils.show_objects(planes_list, Plane.header, Plane.footer)

    print(f"\nСортировка коллекции самолётов {console_colors.blue_back_highlight} по названию авиакомпании {console_colors.terminate}")

    planes_list.sort(key=lambda plane: plane.airline)

    utils.show_objects(planes_list, Plane.header, Plane.footer)

    print(f"\nСортировка коллекции самолётов "
          f"{console_colors.blue_back_highlight} по убыванию расхода горючего {console_colors.terminate}")

    planes_list.sort(key=lambda plane: plane.consumption, reverse=True)

    utils.show_objects(planes_list, Plane.header, Plane.footer)
