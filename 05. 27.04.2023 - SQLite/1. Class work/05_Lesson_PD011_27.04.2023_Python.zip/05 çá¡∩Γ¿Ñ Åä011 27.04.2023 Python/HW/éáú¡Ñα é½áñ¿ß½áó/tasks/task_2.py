import main
import console_colors
import utils
from models.Animal import Animal

if __name__ == '__main__':
    main.main()

animals_list = list()


def show_animals_list():
    animals_list.sort(key=lambda animal: animal.id)

    print("\nИсходная коллекция животных")
    utils.show_objects(animals_list, Animal.header, Animal.footer)


# Поиск всех животных, возраст которых больше заданного
def find_by_age():
    # Ввести возраст животного
    animal_age = int(input("\nВведите возраст животного (в годах): "))

    matching_list = list()

    if animal_age < 0:
        raise Exception(f"Возраст животного задан некорректно!")

    # Найти животных с возрастом > заданного
    for i in range(0, len(animals_list)):
        if animals_list[i].age > animal_age:
            matching_list.append(animals_list[i])

    if len(matching_list) <= 0:
        raise Exception(f"животные с возрастом > {animal_age} не найдены в списке!")

    # Удалить животных из основного списка
    for i in range(len(animals_list)-1, -1, -1):
        if animals_list[i] in matching_list:
            animals_list.remove(animals_list[i])
            #animals_list.pop(i)

    # Вывести два списка
    print(f"\nСписок животных с возрастом > {animal_age}:")
    utils.show_objects(matching_list, Animal.header, Animal.footer)

    print(f"\nИсходный список животных после удаления")
    utils.show_objects(animals_list, Animal.header, Animal.footer)

    # Ожидать нажатия enter
    utils.wait_for_enter_press("Для запуска сортировок нажмите enter...")


# Сортировки списка животных по заданию
def sort_animals_list():

    if len(animals_list) <= 1:
        raise Exception(f"В коллекции животных слишком мало значений для сортировок!")

    print(f"\nСортировка коллекции животных {console_colors.blue_back_highlight} по убыванию возраста {console_colors.terminate}")

    animals_list.sort(key=lambda animal: animal.age, reverse=True)

    utils.show_objects(animals_list, Animal.header, Animal.footer)

    print(f"\nСортировка коллекции животных  "
          f"{console_colors.blue_back_highlight} по кличке {console_colors.terminate}")

    animals_list.sort(key=lambda animal: animal.name)

    utils.show_objects(animals_list, Animal.header, Animal.footer)

    print(f"\nСортировка коллекции животных "
          f"{console_colors.blue_back_highlight} возрасту и по цвету {console_colors.terminate}")

    animals_list.sort(key=lambda animal: (animal.age, animal.color))

    utils.show_objects(animals_list, Animal.header, Animal.footer)

    print(f"\nСортировка коллекции животных "
          f"{console_colors.blue_back_highlight} по владельцу {console_colors.terminate}")

    animals_list.sort(key=lambda animal: animal.owner)

    utils.show_objects(animals_list, Animal.header, Animal.footer)

