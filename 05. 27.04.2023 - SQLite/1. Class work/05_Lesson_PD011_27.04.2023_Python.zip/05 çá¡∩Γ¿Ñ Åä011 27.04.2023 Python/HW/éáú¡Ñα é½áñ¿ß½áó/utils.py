import random

import main
import console_colors
from models.Animal import Animal
from models.Plane import Plane
from models.figures.Cylinder import Cylinder
from models.figures.Cone import Cone
from models.figures.Pyramid import Pyramid

if __name__ == '__main__':
    main.main()


def get_random_float(lo, hi):
    if lo > hi:
        return 0

    return random.uniform(lo, hi)


# end get_random_float


def get_random_int(lo, hi):
    if lo > hi:
        return 0

    return random.randrange(lo, hi)


# end get_random_int


# Сгенерировать список целых чисел
def generate_int_list(size, lo, hi):
    generating_list = []

    for i in range(size):
        generating_list.append(get_random_int(lo, hi))

    # end for

    return generating_list


# Сгенерировать множество целых чисел
def generate_int_set(size, lo, hi):
    generating_set = set()

    while len(generating_set) < size:
        generating_set.add(get_random_int(lo, hi))

    # end while

    return generating_set


# Сгенерировать список вещественных чисел
def generate_float_list(size, lo, hi):
    generating_list = []

    for i in range(size):
        generating_list.append(get_random_float(lo, hi))

    # end for

    return generating_list


def show_container(source, line_break_count=15):
    if len(source) == 0:
        print("\nВ контейнере нет значений!")
        return

    list_str = ""

    index = 0
    # Выделить повторяющиеся элементы
    for item in source:
        line_break = "\n\n" if (index + 1) % line_break_count == 0 and (index + 1) < len(source) else ""

        list_str += f" {console_colors.light_magenta} " \
                    f"{item: ^3} {console_colors.terminate}{line_break}"

        index += 1

    # end for

    print(list_str)


def show_dictionary(source):
    if len(source) == 0:
        print("\nВ словаре нет значений!")
        return

    dict_str = ""

    # Выделить повторяющиеся элементы
    for key in source:
        dict_str += f"{console_colors.light_magenta} " \
                    f"{key: ^3} {console_colors.terminate} - {source[key]}\n"

    # end for

    print(dict_str)


# Генерация списка самолётов
def get_planes():

    max_consumption = 500
    Plane.last_id = 0

    return [
        Plane("Airbus A300-B4",          300, get_random_int(0, 300), get_random_int(0, max_consumption), 2, "PANAM"),
        Plane("Boeing 737 MAX 8",        200, get_random_int(0, 200), get_random_int(0, max_consumption), 2, "American Airlines"),
        Plane("Boeing 777-300ER",        365, get_random_int(0, 365), get_random_int(0, max_consumption), 2, "American Airlines"),
        Plane("Boeing 737-900ER",        220, get_random_int(0, 220), get_random_int(0, max_consumption), 2, "United Express"),
        Plane("Boeing 737 MAX 10",       230, get_random_int(0, 230), get_random_int(0, max_consumption), 2, "United Express"),
        Plane("Airbus_A320",             180, get_random_int(0, 180), get_random_int(0, max_consumption), 2, "United Express"),
        Plane("Boeing 787-8 Dreamliner", 290, get_random_int(0, 290), get_random_int(0, max_consumption), 2, "Ryanair"),
        Plane("Airbus A380",             555, get_random_int(0, 555), get_random_int(0, max_consumption), 4, "Lufthansa"),
        Plane("Airbus A350",             480, get_random_int(0, 480), get_random_int(0, max_consumption), 2, "Lufthansa"),
        Plane("Airbus A350-900",         440, get_random_int(0, 440), get_random_int(0, max_consumption), 2, "Air France-KLM"),
        Plane("Boeing 777-9X",           375, get_random_int(0, 375), get_random_int(0, max_consumption), 2, "Air France-KLM"),
    ]

# Генерация списка животных
def get_animals():

    return [
        Animal(1,  "Фрида",   get_random_float(2, 8), get_random_int(1, 18), "Черный", "Юрковский П.С."),
        Animal(2,  "Шерри",   get_random_float(2, 8), get_random_int(1, 18), "Белый", "Якубовская В.А."),
        Animal(3,  "Вальдо",  get_random_float(2, 8), get_random_int(1, 18), "Черный", "Шапиро В.П."),
        Animal(4,  "Данте",   get_random_float(2, 8), get_random_int(1, 18), "Рыжий", "Вожжаев В.Б."),
        Animal(5,  "Зефир",   get_random_float(2, 8), get_random_int(1, 18), "Серый", "Хроменко Е.М."),
        Animal(6,  "Клеон",   get_random_float(2, 8), get_random_int(1, 18), "Дымчатый", "Потемкина Н.П."),
        Animal(7,  "Баффи",   get_random_float(2, 8), get_random_int(1, 18), "Дымчатый", "Гритченко С.Р."),
        Animal(8,  "Викки",   get_random_float(2, 8), get_random_int(1, 18), "Белый", "Селиванов Л.И."),
        Animal(9,  "Вспышка", get_random_float(2, 8), get_random_int(1, 18), "Белый", "Пономаренко В.Д."),
        Animal(10, "Генрих",  get_random_float(2, 8), get_random_int(1, 18), "Серый", "Хавалджи Л.А.")
    ]


# Генерация списка фигур
def get_figures():

    # Мин. и макс. значения для генерации
    min_val = 1
    max_val = 15

    return [
        Cylinder(get_random_float(min_val, max_val), get_random_float(min_val, max_val)),
        Cylinder(get_random_float(min_val, max_val), get_random_float(min_val, max_val)),

        Cone(get_random_float(min_val, max_val), get_random_float(min_val, max_val)),
        Cone(get_random_float(min_val, max_val), get_random_float(min_val, max_val)),

        Pyramid(get_random_float(min_val, max_val), get_random_float(min_val, max_val)),
        Pyramid(get_random_float(min_val, max_val), get_random_float(min_val, max_val)),
    ]


# Вывести коллекцию самолётов с выделением по предикату
def show_planes(collection, predicate):

    if len(collection) == 0:
        print("\nВ самолётов коллекции нет значений!")
        return

    list_str = Plane.header

    # Вывод с выделением нужного элемента
    for item in collection:
        if predicate(item):
            list_str += item.to_table_row(console_colors.blue_back_highlight)
        else:
            list_str += item.to_table_row()

    # end for

    print(f"{list_str}{Plane.footer}")


# Вывести коллекцию объектов
def show_objects(collection, header, footer):

    if len(collection) == 0:
        print("\nВ коллекции нет значений!")
        return

    list_str = header

    for item in collection:
        list_str += item.to_table_row()

    # end for

    print(f"{list_str}{footer}")


# Ожидать нажатия enter
def wait_for_enter_press(title="Для входа в меню нажмите enter..."):
    print(f"\n{title}")

    import keyboard
    keyboard.wait("enter", True)
