import app
import console_colors


def main():
    main_menu_dict = {
        1: ["1 - задача 1. Коллекция самолетов.",  app.task01],
        2: ["2 - задача 2. Коллекция животных.",   app.task02],
        3: ["3 - задача 3. Геометрические фигуры.", app.task03],
        0: ["0 - выход\n", exit]
    }

    while True:

        try:
            tasks = ""

            for value in main_menu_dict.values():
                tasks += f"\n{value[0]}"

            # Выбрать номер задачи
            task_number = input(f"{tasks}\nВведите номер задачи: ")

            if task_number == "0":
                exit(0)

            task_number = int(task_number)

            # Нахождение элемента словаря и вызов метода
            main_menu_dict.get(task_number)[1]()

        except Exception as e:
            print(
                f"\n\nПри выполнении операции возникло исключение: {console_colors.bright_red} {e} {console_colors.terminate} \n")

    # end while


# end main


if __name__ == '__main__':
    main()
