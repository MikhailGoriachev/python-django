import console_colors


class Plane:

    header = "┌───────┬─────────────────────────┬──────────────────────┬───────────────────────┬────────────────┬───────────────────┬───────────────────┐\n" \
             "│  Id   │       Тип самолёта      │ Пассажировместимость │ Количество пассажиров │ Расход топлива │ Кол-во двигателей │    Авиакомпания   │\n" \
             "│       │                         │                      │                       │ (л/час)        │                   │                   │\n"
    footer = "└───────┴─────────────────────────┴──────────────────────┴───────────────────────┴────────────────┴───────────────────┴───────────────────┘"

    last_id = 0

    # конструктор
    def __init__(self, plane_type, capacity, passengers_amount, consumption, engines_amount, airline):

        # Задать id
        Plane.last_id += 1
        self.__id = Plane.last_id

        self.__plane_type = plane_type
        self.__capacity = capacity

        if passengers_amount > capacity:
            raise AttributeError("__init__. Количество пассажиров не может быть > вместительности самолёта!")

        self.__passengers_amount = passengers_amount
        self.__consumption = consumption
        self.__engines_amount = engines_amount
        self.__airline = airline

    # region Accessors
    # id самолёта
    @property
    def id(self):
        return self.__id

    # Тип самолёта
    @property
    def plane_type(self):
        return self.__plane_type

    @plane_type.setter
    def plane_type(self, plane_type):
        if plane_type is None or plane_type == "":
            raise AttributeError("Тип самолёта задан некорректно!")

        self.__plane_type = plane_type

    # количество пассажирских мест
    @property
    def capacity(self):
        return self.__capacity

    @capacity.setter
    def capacity(self, capacity):
        if capacity < 0:
            raise AttributeError("Количество пассажирских мест задано некорректно!")

        self.__capacity = capacity

    # текущее количество пассажиров
    @property
    def passengers_amount(self):
        return self.__passengers_amount

    @passengers_amount.setter
    def passengers_amount(self, passengers_amount):
        if passengers_amount > self.__capacity:
            raise AttributeError("Текущее количество пассажиров не может быть > пассажировместимости самолета!")

        self.__passengers_amount = passengers_amount

    # расход горючего
    @property
    def consumption(self):
        return self.__consumption

    @consumption.setter
    def consumption(self, consumption):
        if consumption < 0:
            raise AttributeError("Расход горючего задан некорректно!")

        self.__consumption = consumption

    # количество двигателей
    @property
    def engines_amount(self):
        return self.__engines_amount

    @engines_amount.setter
    def engines_amount(self, engines_amount):
        if engines_amount < 0:
            raise AttributeError("Количество двигателей задано некорректно!")
        self.__engines_amount = engines_amount

    # название авиакомпании
    @property
    def airline(self):
        return self.__airline

    @airline.setter
    def airline(self, airline):
        if airline is None or airline == "":
            raise AttributeError("Авиакомпания задана некорректно!")
        self.__airline = airline
    # endregion

    def __str__(self) -> str:
        return f"Тип самолёта: {self.__plane_type}\n Пассажировместимость: {self.capacity}\n" \
               f"Текущее количество пассажиров: {self.__passengers_amount}\n " \
               f"Расход топлива (л/час): {self.__consumption}\n Количество двигателей: {self.__engines_amount}\n "\
               f"Авиакомпания: {self.__airline}"

    def to_table_row(self, color=""):
        return f"├───────┼─────────────────────────┼──────────────────────┼───────────────────────┼────────────────┼───────────────────┼───────────────────┤\n" \
            f"|{color}{self.__id: ^7}| {self.__plane_type: <23} | {self.__capacity: >20} | {self.__passengers_amount: >21} | " \
            f"{self.__consumption: >14} | {self.__engines_amount: >17} | {self.__airline: >17} {console_colors.terminate}|\n"

