class Animal:

    header = "┌───────┬─────────────────────────┬───────────┬───────────┬──────────────┬────────────────────┐\n" \
             "│  Id   │     Кличка животного    │    Вес    │  Возраст  │     Цвет     │ Владелец животного │\n" \

    footer = "└───────┴─────────────────────────┴───────────┴───────────┴──────────────┴────────────────────┘"

    # конструктор
    def __init__(self, animal_id, name, weight, age, color, owner):

        self.__id = animal_id
        self.__name = name
        self.__weight = weight

        self.__age = age
        self.__color = color
        self.__owner = owner

    # region Accessors
    # id животного
    @property
    def id(self):
        return self.__id

    # кличка
    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, name):
        if name is None or name == "":
            raise AttributeError("Кличка животного задана некорректно!")

        self.__name = name

    # вес (кг),
    @property
    def weight(self):
        return self.__weight

    @weight.setter
    def weight(self, weight):
        if weight < 0:
            raise AttributeError("Вес животного задан некорректно!")

        self.__weight = weight

    # возраст (лет)
    @property
    def age(self):
        return self.__age

    @age.setter
    def age(self, age):
        if age > self.__weight:
            raise AttributeError("Возраст животного задан некорректно!")

        self.__age = age

    # цвет животного
    @property
    def color(self):
        return self.__color

    @color.setter
    def color(self, color):
        if color is None or color == "":
            raise AttributeError("Цвет животного задан некорректно!")

        self.__color = color

    # ФИО владельца
    @property
    def owner(self):
        return self.__owner

    @owner.setter
    def owner(self, owner):
        if owner is None or owner == "":
            raise AttributeError("Владелец животного задан некорректно!")

        self.__owner = owner

    # endregion

    def __str__(self) -> str:
        return f"Кличка животного: {self.__name}\n Вес животного: {self.__weight}\n" \
               f"Возраст животного: {self.__age}\n Цвет животного: {self.__color}\n " \
               f"Владелец животного: {self.__owner}\n "

    def to_table_row(self):
        return f"├───────┼─────────────────────────┼───────────┼───────────┼──────────────┼────────────────────┤\n" \
               f"|{self.__id: ^7}| {self.__name: <23} | {self.__weight: >9.3f} | {self.__age: >9} | " \
               f"{self.__color: >12} | {self.__owner: >18} |\n"

