import math

from models.figures.Figure3D import Figure3D

# Пирамида
class Pyramid(Figure3D):

    # конструктор
    def __init__(self, a, h):
        super().__init__("Пирамида", 0)
        self.__side_a = a
        self.__h = h

    # region Accessors
    # сторона a
    @property
    def side_a(self):
        return self.__side_a

    @side_a.setter
    def side_a(self, a):
        if a <= 0:
            raise AttributeError("Сторона пирамиды задана некорректно!")

        self.__side_a = a

    # высота
    @property
    def height(self):
        return self.__h

    @height.setter
    def height(self, height):
        if height <= 0:
            raise AttributeError("Высота пирамиды задана некорректно!")

        self.__h = height

    # endregion

    def __str__(self) -> str:
        return f"{super().__str__()}\n Сторона пирамиды: {self.__side_a}\n Высота пирамиды: {self.__h}\n"

    def to_table_row(self):
        return f"├────────────────────┼────────────┼────────────────────┼───────────┼───────────┤\n" \
               f"|                    |            | сторона a: {self.__side_a: >7.3f} |           |           |\n"\
               f"| {self._figure_type: <18} | {'----': ^10} | высота: {self.__h: >10.3f} | {self.area(): >9.3f} | {self.volume(): >9.3f} |\n"\
               f"|                    |            |                    |           |           |\n"

    def area(self):
        return math.sqrt(3)*self.__side_a**2

    def volume(self):
        return self.__h * self.side_a**2 / (4 * math.sqrt(3))
