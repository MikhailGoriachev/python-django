class Figure3D:

    header = "┌────────────────────┬────────────┬────────────────────┬───────────┬───────────┐\n" \
             "│     Тип фигуры     │   Радиус   │ Доп.свойство (h,a) │  Площадь  │   Объём   │\n"
    footer = "└────────────────────┴────────────┴────────────────────┴───────────┴───────────┘"

    # конструктор
    def __init__(self, figure_type, radius):

        self._figure_type = figure_type
        self._radius = radius

    # region Access

    # Радиус фигуры
    @property
    def radius(self):
        return self._radius

    @radius.setter
    def radius(self, radius):

        if radius < 0:
            raise Exception("Радиус задан некорректно!")

        self._radius = radius

    # Тип фигуры
    @property
    def figure_type(self):
        return self._figure_type

    @figure_type.setter
    def figure_type(self, figure_type):

        if figure_type is None or figure_type == "":
            raise Exception("Тип фигуры задан некорректно!")

        self._figure_type = figure_type

    # endregion

    def __str__(self) -> str:
        return f"Тип фигуры: {self._figure_type}" \
               f"Радиус фигуры: {self._radius}"

    # Вывод в строку таблицы
    def to_table_row(self):
        pass

    # Площадь фигуры
    def area(self):
        pass

    # Объем фигуры
    def volume(self):
        pass
