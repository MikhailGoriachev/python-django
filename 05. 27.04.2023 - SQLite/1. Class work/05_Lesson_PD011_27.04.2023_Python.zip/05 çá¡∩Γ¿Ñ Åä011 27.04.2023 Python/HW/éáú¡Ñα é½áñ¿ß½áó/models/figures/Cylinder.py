import math

from models.figures.Figure3D import Figure3D


# Цилиндр
class Cylinder(Figure3D):

    # конструктор
    def __init__(self, radius, height):
        super().__init__("Цилиндр", radius)
        self.__h = height

    # region Accessors
    # высота цилиндра
    @property
    def height(self):
        return self.__h

    @height.setter
    def height(self, height):
        if height <= 0:
            raise AttributeError("Высота цилиндра задана некорректно!")

        self.__h = height

    # endregion

    def __str__(self) -> str:
        return f"{super().__str__()}\n Высота цилиндра: {self.__h}\n"

    def to_table_row(self):
        return f"├────────────────────┼────────────┼────────────────────┼───────────┼───────────┤\n" \
               f"| {self._figure_type: <18} | {self._radius: >10.3f} | {self.__h: >18.3f} | " \
               f"{self.area(): >9.3f} | {self.volume(): >9.3f} |\n"

    def area(self):
        return 2 * math.pi * self.radius * (self.radius + self.__h)

    def volume(self):
        return math.pi * self.radius**2 * self.__h


