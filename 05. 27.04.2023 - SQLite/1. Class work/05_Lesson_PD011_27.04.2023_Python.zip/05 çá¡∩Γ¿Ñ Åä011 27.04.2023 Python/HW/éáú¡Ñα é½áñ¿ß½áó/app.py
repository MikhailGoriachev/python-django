import main
import utils


from tasks import task_1
from tasks import task_2
from tasks import task_3

if __name__ == '__main__':
    main.main()


# Задача 1: коллекция объектов класса Plane
def task01():

    task_1.planes_list = utils.get_planes()

    task_1.show_planes_list()

    task_1.increase_passengers_amount()

    task_1.delete_plane_by_id()

    task_1.sort_planes_list()

# end task01


# Задача 2: коллекция объектов класса Animal
def task02():

    task_2.animals_list = utils.get_animals()

    task_2.show_animals_list()

    task_2.find_by_age()

    task_2.sort_animals_list()

# end task02


# Задача 3: иерархия классов геометрических фигур
def task03():
    task_3.show_figures_list()

    task_3.calculate()

# end task03

