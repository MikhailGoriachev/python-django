import utils
from models.Plane import Plane

# Создайте список самолетов (не менее 10 элементов).
planes = [
    Plane('Ту-134', 80, 50, 2500, 1, 'Dexter'),
    Plane('Ту-154', 180, 100, 5400, 3, 'Авиа-Май'),
    Plane('Ту-204', 214, 100, 3420, 5, 'Авиа-Сибирь'),
    Plane('Суперджет-100', 146, 81, 1700, 3, 'Авиабаза'),
    Plane('ИЛ-62', 198, 92, 5300, 5, 'Авиаскан'),
    Plane('ИЛ-86 ', 234, 34, 10400, 5, 'АВИАТРЕК'),
    Plane('ИЛ-96 ', 300, 199, 7500, 6, 'АвиаТИС'),
    Plane('Airbus A320', 149, 100, 2700, 2, 'АвисКом'),
    Plane('Airbus A330', 440, 405, 10000, 2, 'Аврора'),
    Plane('Боинг -737', 114, 12, 2600, 5, 'Агат'),
    Plane('Боинг-747', 425, 323, 12000, 4, 'Азимут'),
    Plane('Боинг-767', 252, 151, 4450, 3, 'Azur Air')
]


def show(title, data):
    utils.show(title, data, Plane.header, Plane.footer)


def sort_list(predicate, title, reverse):
    my_list = utils.sort_list(planes, predicate, reverse)
    show(title, my_list)


# Увеличение количества пассажиров на введенное с клавиатуры значение
def inc_number_passengers(value):
    for item in planes:
        item.number_passengers += value


# Удаление выбранного по номеру в списке самолета
# удаляет элементы с конца списка (не знаю почему)
def delete_plane(index):
    del planes[index - 1]
    return True
