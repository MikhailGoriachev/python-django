import math
from models.task03.Shape3D import Shape3D

import utils
from models.task03.Cylinder import Cylinder
from models.task03.Cone import Cone
from models.task03.Pyramid import Pyramid

# реализовать по два объекта каждого типа в списке наследников класса Фигура3D
init = [
    Cylinder(5, 8),
    Cylinder(5, 10),
    Cone(3, 6),
    Cone(10, 16),
    Pyramid(1, math.sqrt(3)),
    Pyramid(3, 10)
]


# вывод коллекции фигур
def show(title, data):
    utils.show(title, data, Shape3D.header, Shape3D.footer)


# вычислить суммарную площадь фигур
def sum_areas():
    sum_value = 0
    for item in init:
        sum_value += item.area()

    return sum_value


# суммарный объем фигур
def sum_volume():
    sum_value = 0
    for item in init:
        sum_value += item.volume()

    return sum_value
