import utils
from models.Animal import Animal

init = [
        Animal('Тaйсон', 200, 25, 'гнедая', 'Ермаков А. М.'),
        Animal('Джек', 450, 20, 'вороная', 'Князева В. Д.'),
        Animal('Рекс', 350, 35, 'рыжая', 'Артамонова Я. Е.'),
        Animal('Джеси', 300, 24, 'серая', 'Кононов М. М.'),
        Animal('Хатико', 500, 28, 'подласая', 'Попова А. А.'),
        Animal('Дик', 600, 20, 'бурая', 'Цветков И. В.'),
        Animal('Лорд', 340, 18, 'игреневая', 'Матвеев Е. А.'),
        Animal('Альма', 456, 26, 'соловая', 'Устинов В. О.'),
        Animal('Рич', 258, 30, 'сабино', 'Кулешова К. А.'),
        Animal('Барон', 567, 34, 'чалая', 'Смирнов А. Г.'),
        Animal('Вольт', 406, 19, 'леопардовая', 'Воробьев Н. С.'),
        Animal('Каспер', 670, 36, 'снежная', 'Александрова С. Д.'),
        Animal('Грай', 1400, 30, 'мраморная', 'Волков Ф. К.'),
        Animal('Чарли', 1004, 31, 'тобиано', 'Панин Т. Г.'),
        Animal('Багира', 809, 25, 'оверо', 'Черных И. В.')
    ]


def show(title, data):
    utils.show(title, data, Animal.header, Animal.footer)


def sort_list(predicate, title, reverse):
    my_list = utils.sort_list(init, predicate, reverse)
    show(title, my_list)
