from tasks import task01, task02, task03


# Вывод списка самолетов в виде таблицы
def do_task01_show_planes():
    task01.show('\n\tСписок самолетов для обработки:', task01.planes)


# Увеличение количества пассажиров на введенное с клавиатуры значение
def do_task01_inc_number_passengers():
    cmd = int(input('\n\tВведите количество пассажиров на которое хотите увеличить: '))
    task01.inc_number_passengers(cmd)
    print('\tОбработка завершена.')


# Удаление выбранного по номеру в списке самолета
def do_task01_delete_plane_by_index():
    task01.show('\n\tСписок самолетов для обработки:', task01.planes)
    cmd = int(input('\n\tВведите номер самолета в списке для удаления: '))

    flag = task01.delete_plane(cmd)
    if flag:
        print('\tУдаление завершено.')


# Реализуйте сортировки списка самолетов:
# По типу самолета
def do_task01_sort_asc_by_type():
    task01.sort_list(lambda item: item.type_plane, '\n\tСписок самолетов отсортирован по типу:', False)


# По убыванию количества двигателей
def do_task01_sort_desc_by_engines():
    task01.sort_list(lambda item: item.number_engines, '\n\tСписок самолетов отсортирован по убыванию количества '
                                                       'двигателей:', True)


# По названию авиакомпании владельца самолета
def do_task01_sort_asc_by_airline():
    task01.sort_list(lambda item: item.airline, '\n\tСписок самолетов отсортирован по названию авиакомпаний:', False)


# По убыванию расхода горючего за час полета
def do_task01_sort_desc_by_expense():
    task01.sort_list(lambda item: item.expense, '\n\tСписок самолетов отсортирован по убыванию расхода:', True)


# ----------------------------------------------------------------------------------------------------------------------

# Вывод списка животных в виде таблицы
def do_task02_show_animals():
    task02.show('\n\tСписок животных для обработки:', task02.init)


# Реализуйте сортировки списка животных:
# По убыванию возраста
def do_task02_sort_desc_by_age():
    task02.sort_list(lambda item: item.age, '\n\tСписок животных отсортирован по убыванию возраста:', True)


# По кличке
def do_task02_sort_asc_by_name():
    task02.sort_list(lambda item: item.name, '\n\tСписок животных отсортирован по кличке:', False)


# По возрасту и по цвету
def do_task02_sort_asc_by_age_and_color():
    task02.sort_list(lambda item: (item.age, item.color), '\n\tСписок животных отсортирован по возрасту и по цвету:',
                     False)


# По фамилии и инициалам владельца
def do_task02_sort_asc_by_owner():
    task02.sort_list(lambda item: item.owner, '\n\tСписок животных отсортирован по владельцу:',
                     False)


# ----------------------------------------------------------------------------------------------------------------------


# Вывод списка фигур в виде таблицы
def do_task03_show_shapes():
    task03.show('\n\tСписок фигур для обработки:', task03.init)
    print(f'\tCуммарная площадь фигур: {task03.sum_areas():.3f}')
    print(f'\tCуммарный объем фигур: {task03.sum_volume():.3f}')
