import math

from models.task03.Shape3D import Shape3D


class Cylinder(Shape3D):

    def __init__(self, radius, height):
        super().__init__(radius)
        self.__height = height

    @property
    def height(self): return self.__height

    @height.setter
    def height(self, value):
        if value <= 0:
            raise AttributeError("Было задано недопустимое значение высоты!")

        self.__height = value

    def area(self): return 2*(math.pi * self.radius * self.__height + math.pi * self.radius * self.radius)

    def volume(self): return math.pi * self.radius * self.radius * self.__height

    def to_table_row(self, index):
        return f'\t│{index:3}│ {"Цилиндр":13}│{self.radius:7.3f} │{"Нет данных".rjust(18)} │{self.__height:8.3f} │' \
               f'{self.area():9.3f} │{self.volume():8.3f} │'
    
