import math

from models.task03.Shape3D import Shape3D


class Cone(Shape3D):

    def __init__(self, radius, height):
        super().__init__(radius)
        self.__height = height

    @property
    def height(self): return self.__height

    @height.setter
    def height(self, value):
        if value <= 0:
            raise AttributeError("Было задано недопустимое значение высоты!")

        self.__height = value

    # использовала т. о. Пифагора для нахождения образующей
    def forming(self): return math.sqrt(self.radius * self.radius + self.__height * self.__height)

    def area(self): return math.pi * (self.radius * self.radius + self.radius * self.forming())

    def volume(self): return math.pi * self.radius * self.radius * self.__height / 3

    def to_table_row(self, index):
        return f'\t│{index:3}│ {"Конус":13}│{self.radius:7.3f} │{"Нет данных".rjust(18)} │{self.__height:8.3f} │' \
               f'{self.area():9.3f} │{self.volume():8.3f} │'
