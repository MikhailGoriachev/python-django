class Shape3D:

    def __init__(self, radius):
        self.__radius = radius

    @property
    def radius(self): return self.__radius

    @radius.setter
    def radius(self, value):
        if value <= 0:
            raise AttributeError("Было задано недопустимое значение радиуса!")

        self.__radius = value

    def area(self): pass

    def volume(self): pass
    def to_table_row(self, index): pass

    header = \
        '\t┌───┬──────────────┬────────┬───────────────────┬─────────┬──────────┬─────────┐\n' \
        '\t│ № │  Тип фигуры  │ Радиус │ Сторона основания │ Высота  │ Площадь  │  Объём  │\n' \
        '\t├───┼──────────────┼────────┼───────────────────┼─────────┼──────────┼─────────┤'

    footer = \
        '\t└───┴──────────────┴────────┴───────────────────┴─────────┴──────────┴─────────┘'
