import math

from models.task03.Shape3D import Shape3D
import utils


class Pyramid(Shape3D):

    def __init__(self, radius, height):
        super().__init__(radius)
        self.__height = height

    @property
    def height(self): return self.__height

    @height.setter
    def height(self, value):
        if value <= 0:
            raise AttributeError("Было задано недопустимое значение высоты!")

        self.__height = value

    # находим площадь через апофему
    # Формула взята с иcточника: https://max-calc.ru/Kalkulyator/Apofema/Pravilnoi_treugolnoi_piramidi.html?ysclid=lgxsk125uc822479051
    # апофема:
    def apopheme(self):
        tg = 2*utils.deg
        return math.sqrt(self.__height * self.__height + (self.radius/tg) * (self.radius/tg))

    # radius - сторона треугольника лежащего в основании
    # Формула взята с иcточника: https://microexcel.ru/ploshad-pravilnoy-piramidy/?ysclid=lgxpnsma3g351142250
    def area(self): return (self.radius * self.radius * math.sqrt(3) + 6 * self.radius * self.apopheme()) / 4

    # Формула взята с иcточника: https://microexcel.ru/obyom-piramidy/?ysclid=lgxq0wkntc776625977
    def volume(self): return self.radius * self.radius * math.sqrt(3) * self.__height / 12

    def to_table_row(self, index):
        return f'\t│{index:3}│ {"Пирамида":13}│{"-".center(7)} │{self.radius:18.3f} │{self.__height:8.3f} │' \
               f'{self.area():9.3f} │{self.volume():8.3f} │'
