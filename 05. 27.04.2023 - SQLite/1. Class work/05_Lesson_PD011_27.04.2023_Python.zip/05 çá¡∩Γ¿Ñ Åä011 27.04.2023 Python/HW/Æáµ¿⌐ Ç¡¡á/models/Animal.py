class Animal:

    def __init__(self, name, weight, age, color, owner):
        self.__name = name  # клички животного
        self.__weight = weight  # веса
        self.__age = age  # возраста
        self.__color = color  # цвета
        self.__owner = owner  # фамилии и инициалов владельца

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, value):
        if len(value) <= 0 or value.isspace():
            raise AttributeError("Было задано недопустимое имя животного!")

        self.__name = value

    @property
    def weight(self):
        return self.__weight

    @weight.setter
    def weight(self, value):
        if value <= 0:
            raise AttributeError("Был задан недопустимый вес животного!")

        self.__weight = value

    @property
    def age(self):
        return self.__age

    @age.setter
    def age(self, value):
        if value < 0 or not isinstance(value, int):
            raise AttributeError("Был задан недопустимый возраст животного!")

        self.__age = value

    @property
    def color(self):
        return self.__color

    @color.setter
    def color(self, value):
        if len(value) <= 0 or value.isspace():
            raise AttributeError("Был задан недопустимый цвет животного!")

        self.__color = value

    @property
    def owner(self):
        return self.__owner

    @owner.setter
    def owner(self, value):
        if len(value) <= 0 or value.isspace():
            raise AttributeError("Были заданы недопустимые инициалы владельца животного!")

        self.__owner = value

    def __str__(self) -> str:
        return f'\t│ {self.__name:13}│{self.__weight:11} │{self.__age:8} │ {self.__color:12}│' \
               f' {self.__owner:13}│'

    def to_table_row(self, index):
        return f'\t│{index:3}│ {self.__name:13}│{self.__weight:11} │{self.__age:8} │ {self.__color:12}│' \
               f' {self.__owner:19}│'

    header = \
        '\t┌───┬──────────────┬────────────┬─────────┬─────────────┬────────────────────┐\n' \
        '\t│ № │    Кличка    │ Вес (в кг) │ Возраст │    Масть    │      Владелец      │\n' \
        '\t├───┼──────────────┼────────────┼─────────┼─────────────┼────────────────────┤'

    footer = \
        '\t└───┴──────────────┴────────────┴─────────┴─────────────┴────────────────────┘'
