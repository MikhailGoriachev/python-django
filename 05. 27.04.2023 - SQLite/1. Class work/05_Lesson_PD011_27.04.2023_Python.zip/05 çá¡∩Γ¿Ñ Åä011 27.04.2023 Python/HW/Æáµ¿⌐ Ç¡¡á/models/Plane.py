class Plane:

    def __init__(self, type_plane, number_seats, number_passengers, expense, number_engines, airline):
        self.__type_plane = type_plane  # тип самолета
        self.__number_seats = number_seats  # количество пассажирских мест
        self.__number_passengers = number_passengers  # текущее количество пассажиров
        self.__expense = expense  # расход горючего за час полета
        self.__number_engines = number_engines  # количество двигателей
        self.__airline = airline  # название авиакомпании владельца самолета

    @property
    def type_plane(self):
        return self.__type_plane

    @type_plane.setter
    def type_plane(self, value):
        if len(value) <= 0 or value.isspace():
            raise AttributeError("Был задан недопустимый тип самолета!")

        self.__type_plane = value

    @property
    def number_seats(self):
        return self.__number_seats

    # количество пассажирских мест (целое число, от 0 и выше)
    @number_seats.setter
    def number_seats(self, value):
        if value < 0 or not isinstance(value, int):
            raise AttributeError("Было задано недопустимое количество пассажирских мест!")

        self.__number_seats = value

    @property
    def number_passengers(self):
        return self.__number_passengers

    @number_passengers.setter
    def number_passengers(self, value):
        if value < 0 or not isinstance(value, int):
            raise AttributeError("Было задано недопустимое количество пассажиров!")

        if value > self.__number_seats:
            raise AttributeError("Количество пассажиров должно быть <= количеству мест!")

        self.__number_passengers = value

    @property
    def expense(self):
        return self.__expense

    @expense.setter
    def expense(self, value):
        if value < 0:
            raise AttributeError("Был задан недопустимый расход горючего!")

        self.__expense = value

    @property
    def number_engines(self):
        return self.__number_engines

    @number_engines.setter
    def number_engines(self, value):
        if not isinstance(value, int):
            raise AttributeError("Было задано недопустимое количество двигателей!")

        if value < 1 or value > 12:
            raise AttributeError("Было задано недопустимое количество двигателей: меньше 1 или больше 12!")

        self.__number_engines = value

    @property
    def airline(self):
        return self.__airline

    @airline.setter
    def airline(self, value):
        if len(value) <= 0 or value.isspace():
            raise AttributeError("Было задано недопустимое название авиакомпании !")

        self.__airline = value

    # метод формирования строкового представления в виде строки таблицы.
    def __str__(self) -> str:
        return f'\t {self.__type_plane:13}│{self.__number_seats:12} │{self.__number_passengers:18} │{self.__expense:7} │' \
               f'{self.__number_engines:19} │ {self.__airline:15}│'

    def to_table_row(self, index):
        return f'\t│{index:3}│ {self.__type_plane:13}│{self.__number_seats:12} │{self.__number_passengers:18} │{self.__expense:7} │' \
               f'{self.__number_engines:19} │ {self.__airline:15}│'

    header = \
        '\t┌───┬──────────────┬─────────────┬───────────────────┬────────┬────────────────────┬────────────────┐\n' \
        '\t│ № │ Тип самолета │ Кол-во мест │ Кол-во пассажиров │ Расход │ Кол-во двигателей  │  Авиакомпания  │\n' \
        '\t├───┼──────────────┼─────────────┼───────────────────┼────────┼────────────────────┼────────────────┤'
    footer = \
        '\t└───┴──────────────┴─────────────┴───────────────────┴────────┴────────────────────┴────────────────┘'
