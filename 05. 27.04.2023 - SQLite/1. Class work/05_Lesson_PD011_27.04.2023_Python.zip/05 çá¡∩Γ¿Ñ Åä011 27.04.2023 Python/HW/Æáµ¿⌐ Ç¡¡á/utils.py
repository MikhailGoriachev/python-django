import app
import main


deg = 0.5773502692  # tg(60°)


# вывод меню из словаря menu_task, выбор в меню и выполнение команд меню
def do_menu(menu_task, title):

    while True:
        try:

            # вывести меню
            print(f'\n{title}')
            for key, value in menu_task.items():
                print(f'\t \033[34;1m{key}\033[0m. {value}')
            # end for

            # ввести команду меню
            cmd = input('\t    Введите команду: ')

            if cmd == '1':
                app.do_task01_show_planes()

            elif cmd == '2':
                app.do_task01_inc_number_passengers()

            elif cmd == '3':
                app.do_task01_delete_plane_by_index()

            elif cmd == '4':
                app.do_task01_sort_asc_by_type()

            elif cmd == '5':
                app.do_task01_sort_desc_by_engines()

            elif cmd == '6':
                app.do_task01_sort_asc_by_airline()

            elif cmd == '7':
                app.do_task01_sort_desc_by_expense()

            elif cmd == '8':
                app.do_task02_show_animals()

            elif cmd == '9':
                print("\n\tВ разработке...")

            elif cmd == '10':
                app.do_task02_sort_desc_by_age()

            elif cmd == '11':
                app.do_task02_sort_asc_by_name()

            elif cmd == '12':
                app.do_task02_sort_asc_by_age_and_color()

            elif cmd == '13':
                app.do_task02_sort_asc_by_owner()

            elif cmd == '14':
                app.do_task03_show_shapes()

            elif cmd == '0':
                return
            else:
                raise Exception("\n\t\033[31;1mОшибка: нет такого пункта меню\033[0m")

        except Exception as e:
            print(f'\n\t\033[31;1mОшибка: {e}\033[0m')

# end do_menu


# выводим список
def show(title, data, header, footer):
    # вывод заголовка таблицы
    print(f'\t\t{title}\n{header}')

    # вывод основной части таблицы
    i = 1
    for item in data:
        print(f'{item.to_table_row(i)}')
        i += 1

    # вывод подвала таблицы
    print(f'{footer}\n')


# сортировка списка по условию
def sort_list(data, predicate, reverse):
    return sorted(data, key=predicate, reverse=reverse)


if __name__ == '__main__':
    main.main()
