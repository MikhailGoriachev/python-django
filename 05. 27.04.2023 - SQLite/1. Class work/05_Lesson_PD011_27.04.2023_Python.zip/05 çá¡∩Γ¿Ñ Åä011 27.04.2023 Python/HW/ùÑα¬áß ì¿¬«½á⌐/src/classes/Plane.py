class Plane:
    def __init__(self, type_plane, seats, passengers, fuel_consumption, number_engines, airline_name='Россия'):
        self.type_plane = type_plane                    # тип самолета
        self.seats = seats                              # количество пассажирских мест
        self.passengers = passengers                    # текущее количество пассажиров
        self.fuel_consumption = fuel_consumption        # расход горючего
        self.number_engines = number_engines            # количество двигателей
        self.airline_name = airline_name                # название авиакомпании

    @property
    def type_plane(self):
        return self.__type_plane

    @type_plane.setter
    def type_plane(self, value):
        self.__type_plane = value

    @property
    def seats(self):
        return self.__seats

    @seats.setter
    def seats(self, value):
        if value < 0:
            raise ValueError("\033[93mКоличество мест должно быть больше 0\033[0m")
        self.__seats = value

    @property
    def passengers(self):
        return self.__passengers

    @passengers.setter
    def passengers(self, value):
        if value > self.__seats:
            raise ValueError(f"\033[93mУ самолета {self.__type_plane}. Некорректное количество пассажиров\033[0m")
        self.__passengers = value

    @property
    def fuel_consumption(self):
        return self.__fuel_consumption

    @fuel_consumption.setter
    def fuel_consumption(self, value):
        if value < 0:
            raise ValueError("\033[93mтопливо некорректное значение\033[0m")
        self.__fuel_consumption = value

    @property
    def number_engines(self):
        return self.__number_engines

    @number_engines.setter
    def number_engines(self, value):
        if 0 > value > 12:
            raise ValueError("\033[93mНекорректное количество длигателей\033[0m")
        self.__number_engines = value

    @property
    def airline_name(self):
        return self.__airline_name

    @airline_name.setter
    def airline_name(self, value):
        if not value:
            raise ValueError("\033[93mНет названия\033[0m")
        self.__airline_name = value

    def __str__(self):
        return f'\t\t│  {self.type_plane:16} │  {self.seats:11} │ {self.passengers:11} │ {self.fuel_consumption:15} │ {self.number_engines:12} │ {self.airline_name:19} │'

