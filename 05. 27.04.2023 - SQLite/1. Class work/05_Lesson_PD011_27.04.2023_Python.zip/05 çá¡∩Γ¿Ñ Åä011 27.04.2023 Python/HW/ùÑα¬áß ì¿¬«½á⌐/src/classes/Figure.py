import math


class Figure:
    def __init__(self, title, radius):
        self.title = title
        self.radius = radius

    @property
    def title(self):
        return self.__title

    @title.setter
    def title(self, value):
        self.__title = value

    @property
    def radius(self):
        return self.__radius

    @radius.setter
    def radius(self, value):
        self.__radius = value

    def area(self):
        pass

    def volume(self):
        pass

    def __str__(self):
        return f'Фигура {self.title}, радиус: {self.radius}'


class Cylinder(Figure):
    def __init__(self, radius, height, title='Цилиндр'):
        Figure.__init__(self, title, radius)
        self.height = height

    @property
    def height(self):
        return self.__height

    @height.setter
    def height(self, value):
        if value <= 0:
            raise Exception("Неверная высота")
        self.__height = value

    def area(self):
        return 2 * math.pi * self.radius * (self.height + self.radius)

    def volume(self):
        return math.pi * pow(self.radius, 2) * self.height

    def __str__(self):
        return f'{super().__str__()} высота: {self.height} площадь: \033[94m{self.area():.3f}\033[0m объем: \033[94m{self.volume():.3f}\033[0m '


class Cone(Figure):
    def __init__(self, radius, height, title='Конус'):
        Figure.__init__(self, title, radius)
        self.height = height

    @property
    def height(self):
        return self.__height

    @height.setter
    def height(self, value):
        if value <= 0:
            raise Exception("Неверная высота")
        self.__height = value

    def area(self):
        return math.pi * self.radius * math.sqrt(self.radius ** 2 + self.height)

    def volume(self):
        return 1 / 3 * math.pi * pow(self.radius, 2) * self.height

    def __str__(self):
        return f'{super().__str__()} высота: {self.height} площадь: \033[94m{self.area():.3f}\033[0m объем: \033[94m{self.volume():.3f}\033[0m'


class Pyramid(Figure):
    def __init__(self, side, title='трехгранная пирамида'):
        Figure.__init__(self, title, side)

    def area(self):
        return math.sqrt(3.0 * pow(self.radius, 2))

    def volume(self):
        return pow(self.radius, 3) * math.sqrt(2) / 12

    def __str__(self):
        return f'{super().__str__()} площадь: \033[94m{self.area():.3f}\033[0m объем: \033[94m{self.volume():.3f} \033[0m '

