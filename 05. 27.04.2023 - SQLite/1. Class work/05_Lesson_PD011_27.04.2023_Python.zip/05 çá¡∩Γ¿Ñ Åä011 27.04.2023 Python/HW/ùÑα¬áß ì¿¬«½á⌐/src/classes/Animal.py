class Animal:
    def __init__(self, nick, weight, age, color, owner):
        self.nick = nick          # кличка
        self.weight = weight      # вес
        self.age = age            # возраст
        self.color = color        # цвет
        self.owner = owner        # владелец

    @property
    def nick(self):
        return self.__nick

    @nick.setter
    def nick(self, value):
        if not value:
            raise ValueError("\033[93mНет названия\033[0m")
        self.__nick = value

    @property
    def weight(self):
        return self.__weight

    @weight.setter
    def weight(self, value):
        if value < 0.2:
            raise ValueError("\033[93mНе верный вес")
        self.__weight = value

    @property
    def age(self):
        return self.__age

    @age.setter
    def age(self, value):
        if value < 0:
            raise ValueError("\033[93mНе верный возраст")
        self.__age = value

    @property
    def color(self):
        return self.__color

    @color.setter
    def color(self, value):
        self.__color = value

    @property
    def owner(self):
        return self.__owner

    @owner.setter
    def owner(self, value):
        self.__owner = value

    def __str__(self):
        return f'\t\t│  {self.nick:16} │  {self.weight:11} │ {self.age:11} │ {self.color:15} │ {self.owner:19} │'

