import utils
from src import app


def name():
    menu = {'1': ["Задача 1", app.task1],
            '2': ["Задача 2", app.task2],
            '3': ["Задача 3", app.task3]}
    while True:
        try:
            cmd = utils.show_menu(menu)
            if cmd == '0':
                break
            elif cmd in menu:
                menu[cmd][1]()
            else:
                print('Нет такого пункта')
        except ValueError as e:
            print(e)
        except Exception as e:
            print(e)


if __name__ == '__main__':
    name()
