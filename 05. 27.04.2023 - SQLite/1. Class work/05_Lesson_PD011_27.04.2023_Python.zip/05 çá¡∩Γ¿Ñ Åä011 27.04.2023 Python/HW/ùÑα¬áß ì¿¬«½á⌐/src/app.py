from src.classes.Animal import Animal
from src.classes.Figure import *
from src.classes.Plane import Plane
import time
import utils


def task1():
    planes = [Plane('Ил-76', 150, 150, 100.0, 2),
              Plane('Ty-134', 80, 70, 150.0, 4, 'Аэрофлот'),
              Plane('Ty-154', 158, 130, 200.0, 8, 'Победа'),
              Plane('Ту-204', 150, 150, 150.0, 4),
              Plane('Суперджет-100', 86, 85, 100.0, 10),
              Plane('Ил-62', 70, 70, 90.0, 2, 'Аэрофлот'),
              Plane('Ил-86', 234, 230, 300.0, 12, 'Азимут'),
              Plane('Ил-96', 350, 320, 350.0, 12, 'Азимут'),
              Plane('Airbus A310', 352, 350, 400.0, 10, 'Победа'),
              Plane('Боинг-767', 252, 180, 450.0, 8, 'Азимут')]
    print('\n\t\tсамолеты в виде таблицы')
    utils.table_plane(planes)

    print('Увеличение количества пассажиров')
    num = utils.get_number()
    utils.add_passengers_all_plane(planes, num)
    utils.table_plane(planes)

    # удалить самолет  по номеру
    print('\nУдалить самолет по номеру в списке')
    num = utils.get_number()
    utils.delete_plane(planes, num)
    utils.table_plane(planes)
    time.sleep(3)

    # сортировка По типу самолета
    planes.sort(key=lambda plane: plane.type_plane)
    print("\nСортировка по типу самолета")
    utils.table_plane(planes)
    time.sleep(3)

    # сортировка	По убыванию количества двигателей
    planes.sort(reverse=True, key=lambda plane: plane.number_engines)
    print("\nСортировка по убыванию количества двигателей")
    utils.table_plane(planes)
    time.sleep(3)

    # По названию авиакомпании владельца самолета
    planes.sort(key=lambda plane: plane.airline_name)
    print('\nСортировка по названию авиакомпании владельца')
    utils.table_plane(planes)
    time.sleep(3)

    # По убыванию расхода горючего за час полета
    planes.sort(reverse=True, key=lambda plane: plane.fuel_consumption)
    print('\nСортировка по убыванию расхода горючего за час полета')
    utils.table_plane(planes)
    time.sleep(3)


def task2():
    animals = [Animal('Жучка', 5, 3, 'серая', 'Ефремов С.И.'),
               Animal('Мурка', 7, 10, 'белая', 'Иванов И.И.'),
               Animal('Барсик', 2, 5, 'черная', 'Курзин А.С.'),
               Animal('Рекс', 55, 8, 'коричневый', 'Лошманов А.И.'),
               Animal('Кара', 25, 5, 'коричневый', 'Мазурчак Ф.Ф.'),
               Animal('Жучка', 2, 2, 'белая', 'Проценко И.И.'),
               Animal('Горда', 15, 33, 'коричневая', 'Капитонов И.И.'),
               Animal('Моська', 1, 3, 'серая', 'Метунова Н.А.'),
               Animal('Берта', 9, 28, 'пестрая', 'Фадеев А.И.'),
               Animal('Аза', 15, 9, 'серая', 'Меньшиков С.О.')]

    utils.table_animal(animals)

    print('\nвозраст животных больше заданного')
    num = utils.get_number()
    animals_more_age = utils.get_animal_more_age(animals, num)
    print('животных с возрастом больше заданного')
    utils.table_animal(animals_more_age)
    print('животные из начального списка')
    utils.table_animal(animals)
    time.sleep(3)

    # •	По убыванию возраста
    print('сортировка по убыванию возраста')
    animals.sort(reverse=True, key=lambda animal: animal.age)
    utils.table_animal(animals)
    time.sleep(3)

    # •	По кличке
    print('сортировка по кличке')
    animals.sort(key=lambda animal: animal.nick)
    utils.table_animal(animals)
    time.sleep(3)

    # •	По кличке
    print('сортировка по возрасту и по цвету')
    animals.sort(key=lambda animal: (animal.age, animal.color))
    utils.table_animal(animals)
    time.sleep(3)

    # •	По кличке
    print('сортировка по фамилии и инициалам')
    animals.sort(key=lambda animal: animal.owner)
    utils.table_animal(animals)
    time.sleep(3)


def task3():
    figures = [Cylinder(3, 5),
               Cylinder(8, 10),
               Cone(5, 10),
               Cone(2, 25),
               Pyramid(5),
               Pyramid(3)]
    print()
    # суммарная площадь фигур
    all_area = utils.get_total_area_figures(figures)
    # суммарный объем фигур
    all_volume = utils.get_amount_volume(figures)
    for figure in figures:
        print(figure)
    print(f"\nсуммарная площадь фигур = \033[94m{all_area:.3f}\033[0m")
    print(f"суммарный объем фигур = \033[94m{all_volume:.3f}\033[0m")

