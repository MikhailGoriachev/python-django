HEADER = '\033[95m'
OKBLUE = '\033[94m'
OKCYAN = '\033[96m'
OKGREEN = '\033[92m'
WARNING = '\033[93m'
FAIL = '\033[91m'
ENDC = '\033[0m'
BOLD = '\033[1m'
UNDERLINE = '\033[4m'

TOP = '''\033[94m
        ┌───────────────────┬──────────────┬─────────────┬─────────────────┬──────────────┬─────────────────────┐
        │        тип        │     мест     │ пассажиров  │ расход горючего │  двигателей  │    авиакомпания     │
        ├───────────────────┼──────────────┼─────────────┼─────────────────┼──────────────┼─────────────────────┤'''
BOTTOM = '\t\t└───────────────────┴──────────────┴─────────────┴─────────────────┴──────────────┴─────────────────────┘'

# шапка таблицы для животных
TOP_ANIMAL = '''\033[94m
        ┌───────────────────┬──────────────┬─────────────┬─────────────────┬─────────────────────┐
        │      кличка       │      вес     │   возраст   │     цвет        │       владелец      │
        ├───────────────────┼──────────────┼─────────────┼─────────────────┼─────────────────────┤'''

BOTTOM_ANIMAL = '\t\t└───────────────────┴──────────────┴─────────────┴─────────────────┴─────────────────────┘'


# вывод в консоль самолетов в виде таблицы
def table_plane(planes):
    num = 1
    print(TOP)
    for plane in planes:
        print(f'{plane}  № {num}')
        num += 1
    print(BOTTOM)


# увеличение пассажиров у всех самолетов
def add_passengers_all_plane(planes, num):
    error_seats = []
    for plane in planes:

        if plane.passengers + num <= plane.seats:
            plane.passengers += num
        else:
            error_seats.append(plane.type_plane)
    for er in error_seats:
        print(f'\033[93m{er} нет мест\033[0m', end=' ')


# удаление самолета по номеру в списке
def delete_plane(planes, num):
    try:
        if num > 0:
            num -= 1
        result = planes.pop(num).type_plane
        print(f'Удален самолет {result}')
    except Exception:
        print('\033[93mВ списке самолета нет такого номера\033[0m')


# получение числа с клавиатуры
def get_number():
    while True:
        try:
            num = int(input('Введите число: '))
            break
        except ValueError:
            print("Это не число")
    return num


def show_menu(menu):
    print(OKBLUE)
    for key, value in menu.items():
        print(f'\033[92m{key} {value[0]}\033[0m')
    print('0 - выход')
    return input('Выберите пункт: ')

# -------------------------------------------------------


# вывод в консоль животных в виде таблицы
def table_animal(animals):
    num = 1
    print(TOP_ANIMAL)
    for plane in animals:
        print(f'{plane}  № {num}')
        num += 1
    print(BOTTOM_ANIMAL)


# возраст животных больше заданного
def get_animal_more_age(animals, num):
    animals_more_age = []
    for animal in animals:
        if animal.age > num:
            animals_more_age.append(animal)
            animals.remove(animal)
    return animals_more_age


# ----------------задача 3--------------------------
# суммарная площадь фигур
def get_total_area_figures(figures):
    amount_area = 0
    for figure in figures:
        amount_area += figure.area()
    return amount_area


# суммарный объем фигур
def get_amount_volume(figures):
    amount_volume = 0
    for figure in figures:
        amount_volume += figure.volume()
    return amount_volume

