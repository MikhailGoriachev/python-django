import math


# Базовый класс Фигура3D со свойствами и пустыми методами для
# вычисления площади и объема в производных классах
class Figure3D:
    # статический атрибут класса - заголовок таблицы
    header = \
        '\t┌─────┬───────────────────────────┬─────────────────────────┬────────────┬───────────────┐\n'\
        '\t│  №  │ Наименование              │ Параметры               │ Площадь    │ Объем         │\n'\
        '\t│ п/п │              фигуры       │            фигуры       │     фигуры │        фигуры │\n'\
        '\t├─────┼───────────────────────────┼─────────────────────────┼────────────┼───────────────┤'

    # статический атрибут класса - подвал таблицы
    footer = \
        '\t└─────┴───────────────────────────┴─────────────────────────┴────────────┴───────────────┘'

    # конструктор
    def __init__(self, r, h):
        self._r = r     # радиус или сторона основания пирамиды
        self._h = h     # высота
    # end __init__()

    # радиус
    @property
    def r(self):
        return self._r

    @r.setter
    def r(self, value):
        if value <= 0:
            raise AttributeError('Недопустимое значение атрибута')
        # end if

        self._r = value
    # end r

    # высота
    @property
    def h(self):
        return self._h

    @h.setter
    def h(self, value):
        if value <= 0:
            raise AttributeError('Недопустимое значение высоты')
        # end if

        self._h = value
    # end h

    # пустой метод для вычисления площади поверхности в объектах производных классов
    def area(self):
        pass

    # пустой метод для вычисления объема в объектах производных классов
    def volume(self):
        pass

    # вывод объекта в строковом формате
    def __str__(self):
        return f'r: {self._r:.3f}  h: {self._h:.3f}'

    # пустой метод для вывода строки таблицы
    def tr(self, row):
        pass
    # end tr
# end class Figure3D


# Класс Цилиндр, наследует от Фигура3D с методами для вычисления площади
# и объема
class Cylinder(Figure3D):
    def __init__(self, r, h):
        super().__init__(r, h)
    # end __init__

    # вычисление площади
    # https://www.fxyz.ru/%D1%84%D0%BE%D1%80%D0%BC%D1%83%D0%BB%D1%8B_%D0%BF%D0%BE_%D0%B3%D0%B5%D0%BE%D0%BC%D0%B5%D1%82%D1%80%D0%B8%D0%B8/%D1%84%D0%BE%D1%80%D0%BC%D1%83%D0%BB%D1%8B_%D0%BF%D0%BB%D0%BE%D1%89%D0%B0%D0%B4%D0%B8/%D0%BF%D0%BB%D0%BE%D1%89%D0%B0%D0%B4%D1%8C_%D0%BF%D0%BE%D0%B2%D0%B5%D1%80%D1%85%D0%BD%D0%BE%D1%81%D1%82%D0%B8_%D1%86%D0%B8%D0%BB%D0%B8%D0%BD%D0%B4%D1%80%D0%B0/
    def area(self):
        return 2*math.pi*self._r*(self._h + self._r)
    # end area

    # вычисление объема
    # https://www.fxyz.ru/%D1%84%D0%BE%D1%80%D0%BC%D1%83%D0%BB%D1%8B_%D0%BF%D0%BE_%D0%B3%D0%B5%D0%BE%D0%BC%D0%B5%D1%82%D1%80%D0%B8%D0%B8/%D1%84%D0%BE%D1%80%D0%BC%D1%83%D0%BB%D1%8B_%D0%BE%D0%B1%D1%8A%D0%B5%D0%BC%D0%B0/%D0%BE%D0%B1%D1%8A%D0%B5%D0%BC_%D1%86%D0%B8%D0%BB%D0%B8%D0%BD%D0%B4%D1%80%D0%B0/
    def volume(self):
        return math.pi*self._h*self._r**2
    # end volume

    # строковое представление
    def __str__(self):
        return f'Цилиндр: {super().__str__()}, площадь = {self.area():.3f}, объем = {self.volume():.3f}'
    # end __str__

    # представление данных цилиндра в формате строки таблицы
    def tr(self, row):
        param = f'r: {self.r:7.3f}, h: {self.h:7.3f}'
        return f'│ {row:3} │ Цилиндр                   │ {param:23} │ {self.area():10.3f} │  {self.volume():12.3f} │'
    # end tr
# end class Cylinder


# Класс Конус, наследует от Фигура3D с методами для вычисления площади
# и объема
class Cone(Figure3D):
    def __init__(self, r, h):
        super().__init__(r, h)
    # end __init__

    # вычисление площади
    # https://www.fxyz.ru/%D1%84%D0%BE%D1%80%D0%BC%D1%83%D0%BB%D1%8B_%D0%BF%D0%BE_%D0%B3%D0%B5%D0%BE%D0%BC%D0%B5%D1%82%D1%80%D0%B8%D0%B8/%D1%84%D0%BE%D1%80%D0%BC%D1%83%D0%BB%D1%8B_%D0%BF%D0%BB%D0%BE%D1%89%D0%B0%D0%B4%D0%B8/%D0%BF%D0%BB%D0%BE%D1%89%D0%B0%D0%B4%D1%8C_%D0%BF%D0%BE%D0%B2%D0%B5%D1%80%D1%85%D0%BD%D0%BE%D1%81%D1%82%D0%B8_%D0%BA%D0%BE%D0%BD%D1%83%D1%81%D0%B0/
    def area(self):
        l = math.sqrt(self._r**2 + self._h**2)
        return math.pi*self._r*(self._r + l)
    # end area

    # вычисление объема
    # https://www.fxyz.ru/%D1%84%D0%BE%D1%80%D0%BC%D1%83%D0%BB%D1%8B_%D0%BF%D0%BE_%D0%B3%D0%B5%D0%BE%D0%BC%D0%B5%D1%82%D1%80%D0%B8%D0%B8/%D1%84%D0%BE%D1%80%D0%BC%D1%83%D0%BB%D1%8B_%D0%BE%D0%B1%D1%8A%D0%B5%D0%BC%D0%B0/%D0%BE%D0%B1%D1%8A%D0%B5%D0%BC_%D0%BA%D0%BE%D0%BD%D1%83%D1%81%D0%B0/
    def volume(self):
        return math.pi * self._h * self._r**2/3
    # end volume

    # строковое представление
    def __str__(self):
        return f'Конус: {super().__str__()}, площадь = {self.area():.3f}, объем = {self.volume():.3f}'
    # end __str__

    # представление данных конуса в формате строки таблицы
    def tr(self, row):
        param = f'r: {self.r:7.3f}, h: {self.h:7.3f}'
        return f'│ {row:3} │ Конус                     │ {param:23} │ {self.area():10.3f} │  {self.volume():12.3f} │'
    # end tr
# end class Cone


# Класс ТрехграннаяПирамида, наследует от Фигура3D с методами для
# вычисления площади и объема (правильная трехгранная пирамида для
# упрощения вычислений)
class Pyramid(Figure3D):
    def __init__(self, a, h):
        super().__init__(a, h)
    # end __init__

    # вычисление площади
    # https://www.fxyz.ru/%D1%84%D0%BE%D1%80%D0%BC%D1%83%D0%BB%D1%8B_%D0%BF%D0%BE_%D0%B3%D0%B5%D0%BE%D0%BC%D0%B5%D1%82%D1%80%D0%B8%D0%B8/%D1%84%D0%BE%D1%80%D0%BC%D1%83%D0%BB%D1%8B_%D0%BF%D0%BB%D0%BE%D1%89%D0%B0%D0%B4%D0%B8/%D0%BF%D0%BB%D0%BE%D1%89%D0%B0%D0%B4%D1%8C_%D0%BF%D1%80%D0%B0%D0%B2%D0%B8%D0%BB%D1%8C%D0%BD%D0%BE%D0%B9_%D1%82%D1%80%D0%B5%D1%83%D0%B3%D0%BE%D0%BB%D1%8C%D0%BD%D0%BE%D0%B9_%D0%BF%D0%B8%D1%80%D0%B0%D0%BC%D0%B8%D0%B4%D1%8B/
    def area(self):
        s_base = math.sqrt(3)*(self._r**2)/4
        s_sides = 3*self._r*math.sqrt(self._h**2 - (self._r**2)/6)/2
        return s_base + s_sides
    # end area

    # вычисление объема
    # https://www.fxyz.ru/%D1%84%D0%BE%D1%80%D0%BC%D1%83%D0%BB%D1%8B_%D0%BF%D0%BE_%D0%B3%D0%B5%D0%BE%D0%BC%D0%B5%D1%82%D1%80%D0%B8%D0%B8/%D1%84%D0%BE%D1%80%D0%BC%D1%83%D0%BB%D1%8B_%D0%BE%D0%B1%D1%8A%D0%B5%D0%BC%D0%B0/%D0%BE%D0%B1%D1%8A%D0%B5%D0%BC_%D0%BF%D1%80%D0%B0%D0%B2%D0%B8%D0%BB%D1%8C%D0%BD%D0%BE%D0%B9_%D1%82%D1%80%D0%B5%D1%83%D0%B3%D0%BE%D0%BB%D1%8C%D0%BD%D0%BE%D0%B9_%D0%BF%D0%B8%D1%80%D0%B0%D0%BC%D0%B8%D0%B4%D1%8B/
    def volume(self):
        return (self._h * self._r**2)/(4*math.sqrt(3))
    # end volume

    # строковое представление
    def __str__(self):
        return f'Треугольная пирамида: a = {self._r:.3f} h = {self._h:.3f}, площадь = {self.area():.3f}, объем = {self.volume():.3f}'
    # end __str__

    # представление данных треугольной пирамиды в формате строки таблицы
    def tr(self, row):
        param = f'a: {self.r:7.3f}, h: {self.h:7.3f}'
        return f'│ {row:3} │ Треугольная пирамида      │ {param:23} │ {self.area():10.3f} │  {self.volume():12.3f} │'
    # end tr

# end class Pyramid
