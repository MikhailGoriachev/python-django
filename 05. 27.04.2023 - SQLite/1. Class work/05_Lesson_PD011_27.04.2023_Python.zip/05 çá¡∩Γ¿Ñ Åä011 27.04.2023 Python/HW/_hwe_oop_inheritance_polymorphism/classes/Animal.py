# Класс Animal со свойствами (созданными при помощи декораторов) для
# хранения:
#     • клички животного,
#     • веса (в кг),
#     • возраста (в полных годах),
#     • цвета (масть) животного,
#     • фамилии и инициалов владельца (Иванов И.И., …).
# Реализован конструктор __init__(), свойства для доступа к атрибутам класса,
# метод __str__(), метод вывода данных животного в виде строки таблицы.

class Animal:

    # конструктор класс
    def __init__(self, name, weight, age, color, owner):
        self.__name = name      # кличка животного
        self.__weight = weight  # вес животного
        self.__age = age        # возраст животного
        self.__color = color    # масть животного
        self.__owner = owner    # фамилия и инициалы владельца
    # end __init__

    # свойства для доступа к атрибутам класса
    @property     # кличка животного - геттер
    def name(self):
        return self.__name
    # end name

    @name.setter  # кличка животного - сеттер
    def name(self, value):
        # проверка корректности значения кличкм животного
        if len(value) == 0:
            raise ValueError("Пустая строка в качестве клички животного")
        # end if
        self.__name = value
    # end name

    @property  # вес животного - геттер
    def weight(self):
        return self.__weight
    # end weight

    @weight.setter  # вес животного - сеттер
    def weight(self, value):
        # проверка корректности значения веса животного
        if value <= 0 or value > 16_000:
            raise ValueError("Недопустимый вес животного")
        # end if
        self.__weight = value
    # end weight

    @property  # возраст животного - геттер
    def age(self):
        return self.__age
    # end age

    @age.setter  # возраст животного - сеттер
    def age(self, value):
        # проверка корректности значения возраста животного
        if value <= 0 or value > 200:
            raise ValueError("Недопустимый возраст животного")
        # end if
        self.__age = value
    # end age

    @property  # масть животного - геттер
    def color(self):
        return self.__color
    # end color

    @color.setter  # масть животного - сеттер
    def color(self, value):
        # проверка корректности значения масти животного
        if len(value) == 0:
            raise ValueError("Пустая строка в качестве масти животного")
        # end if
        self.__color = value
    # end color

    @property     # фамилия и инициалы владельца - геттер
    def owner(self):
        return self.__name
    # end owner

    @owner.setter  # фамилия и инициалы владельца - сеттер
    def owner(self, value):
        # проверка корректности значения фамилии и инициалов владельца животного
        if len(value) == 0:
            raise ValueError("Пустая строка в качестве фамилии и инициалов владельца животного")
        # end if
        self.__owner = value
    # end owner

    # метод формирования строкового представления объекта
    def __str__(self):
        return f'кличка {self.__name}, вес {self.__weight} кг, возраст {self.__age} лет, ' \
               f'масть "{self.__color} владелец {self.__owner}'
    # end __str__

    # метод возвращает строковое представление данных объекта для вывода в строку таблицы
    # i - номер строки таблицы
    def to_table_row(self, i):
        return f'│ {i:3} │ {self.__name:15} │ {self.__age:6}   │ {self.__weight:7.2f} ' \
               f'│ {self.__color:16} │ {self.__owner:18} │'
    # end to_table_row
# end class Animal

