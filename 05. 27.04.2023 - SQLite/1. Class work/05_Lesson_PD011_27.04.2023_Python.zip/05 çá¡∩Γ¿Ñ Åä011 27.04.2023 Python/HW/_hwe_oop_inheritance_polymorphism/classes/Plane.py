# Класс Plane со следующими свойствами (созданными при помощи декораторов):
#     • тип самолета (Ил-76, Boeing-747, …)
#     • количество пассажирских мест (целое число, от 0 и выше)
#     • текущее количество пассажиров
#     • расход горючего за час полета (вещественное число, от 0 и выше)
#     • количество двигателей (целое число, от 1 до 12)
#     • название авиакомпании – владельца (непустая строка)
# В свойствах-сеттерах выбрасывайте исключение при некорректных значениях.
# Разработайте конструктор __init__() и метод формирования строкового
# представления __str__() в виде строки таблицы.

import main


class Plane:
    # конструктор класса
    def __init__(self, aircraft_type, passengers, current_paxes, consumption, engines, company):
        self.__aircraft_type = aircraft_type       # тип самолета (Ил-76, Boeing-747, …)
        self.__passengers = passengers             # количество пассажирских мест (целое число, от 0 и выше)
        self.__current_passengers = current_paxes  # текущее количество пассажиров
        self.__consumption = consumption           # расход горючего за час полета (вещественное число, от 0 и выше)
        self.__engines = engines                   # количество двигателей (целое число, от 1 до 12)
        self.__company = company                   # название авиакомпании – владельца (непустая строка)
    # end __init__

    # тип самолета (Ил-76, Boeing-747, …)
    @property
    def aircraft_type(self):
        return self.__aircraft_type
    # end aircraft_type

    @aircraft_type.setter
    def aircraft_type(self, value):
        if len(value) == 0:
            raise ValueError("Тип самолета - пустая строка")
        # end if

        self.__aircraft_type = value
    # end aircraft_type

    # количество пассажирских мест (целое число, от 0 и выше)
    @property
    def passengers(self):
        return self.__passengers
    # end passengers

    @passengers.setter
    def passengers(self, value):
        if value < 0:
            raise ValueError('Отрицательное количество пассажиров')
        # end if

        self.__passengers = value
    # end passengers

    # текущее количество пассажиров
    @property
    def current_passengers(self):
        return self.__current_passengers
    # end current_passengers

    @current_passengers.setter
    def current_passengers(self, value):
        if value < 0:
            raise ValueError('Отрицательное текущее количество пассажиров')
        # end if

        if value > self.__passengers:
            raise ValueError('Текущее количество пассажиров больше пассажировместимости самолета')
        # end if

        self.__current_passengers = value
    # end current_passengers

    # расход горючего за час полета (вещественное число, от 0 и выше)
    @property
    def consumption(self):
        return self.__consumption
    # end consumption

    @consumption.setter
    def consumption(self, value):
        if value < 0:
            raise ValueError('Отрицательный часовой расход топлива')
        # end if

        self.__consumption = value
    # end consumption

    # количество двигателей (целое число, от 1 до 12)
    @property
    def engines(self):
        return self.__engines
    # end engines

    @engines.setter
    def engines(self, value):
        if value < 1 or value > 12:
            raise ValueError('Недопустимое количество двигателей')
        # end if

        self.__engines = value
    # end engines

    # название авиакомпании – владельца (непустая строка)
    @property
    def company(self):
        return self.__company
    # end company

    @company.setter
    def company(self, value):
        if len(value) == 0:
            raise ValueError("Название авиакомпании - пустая строка")
        # end if

        self.__company = value
    # end company

    # Методы класса
    # Увеличить количество пассажиров на value
    def increase_current_passengers(self, value=1):
        # отрицательное value не допустимо
        if value < 0:
            raise ValueError('Отрицательное приращение числа пассажиров')
        # end if

        # новое значение текущего количества пассажиров
        self.current_passengers += value
    # end increase_current_passengers

    # формирование строкового представления объекта в виде строки таблицы
    def __str__(self):
        return f'│ {self.__company:12} │ {self.__aircraft_type:12} │ {self.__engines:7}    ' \
               f'│ {self.__consumption:10}    │ {self.__passengers:8}    │ {self.__current_passengers:9}    │'
    # end __str__
# end class Plane


# запуск главной функции приложения
if __name__ == '__main__':
    main.main()
# end if

