import random
from django import template

register = template.Library()


# Случайное вещественное значение
@register.simple_tag
def get_random_float(lo, hi):
    return random.uniform(lo, hi)


# Случайное целочисленное значение
@register.simple_tag
def get_random_int(lo, hi):
    return random.randrange(lo, hi)

# Выбрать случайный тип сортировки для задания в маршрут
@register.simple_tag
def get_sort_type():
    return "ascend" if get_random_int(0, 2) == 1 else "descend"


# region Работники
employees = [
    "1/Кирилл/90000",
    "2/Георгий/40000",
    "3/Юлия/75000",
    "4/Василий/120000",
]


@register.simple_tag
def get_random_employee():

    index = get_random_int(0, len(employees))
    return employees[index]
# endregion


# region Товары
products = [
    "1/Samsung s22 ultra",
    "2/Samsung s10 plus",
    "3/Xiaomi 13",
    "4/Apple watch 6",
    "5/Lenovo v15 g2",
]


@register.simple_tag
def get_random_product():

    # Пришлось добавлять 1 в конце, поскольку в противном случае последний элемент в диапазон не попадал
    index = get_random_int(0, len(employees)+1)

    product = f"{products[index]}/{get_random_int(1,12)}/{get_random_int(40_000,95_000)}"

    return product
# endregion


