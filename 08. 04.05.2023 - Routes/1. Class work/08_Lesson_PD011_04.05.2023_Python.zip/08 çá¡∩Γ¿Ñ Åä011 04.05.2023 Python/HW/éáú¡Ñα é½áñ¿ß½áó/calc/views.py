from django.conf import settings
from django.shortcuts import render


# Главная страница
def index(request):
    # Пришлось задать имя таким образом, поскольку
    # в нескольких приложениях могут быть представления с именем index
    template_path = f"{settings.BASE_DIR}/calc/templates/index.html"

    return render(request, template_path)

# about/ - вывода информации о разработчике
def about(request):
    return render(request, "about.html")


# sort/string/number1/number2/number3/
def sort(request, sort_type, number1, number2, number3):

    num1_sorted, num2_sorted, num3_sorted = number1, number2, number3

    # По возрастанию
    if sort_type == "ascend":
        if num1_sorted > num2_sorted:
            num1_sorted, num2_sorted = num2_sorted, num1_sorted
        if num2_sorted > num3_sorted:
            num2_sorted, num3_sorted = num3_sorted, num2_sorted
        if num1_sorted > num2_sorted:
            num1_sorted, num2_sorted = num2_sorted, num1_sorted
    # По убыванию
    elif sort_type == "descend":
        if num1_sorted < num2_sorted:
            num1_sorted, num2_sorted = num2_sorted, num1_sorted
        if num2_sorted < num3_sorted:
            num2_sorted, num3_sorted = num3_sorted, num2_sorted
        if num1_sorted < num2_sorted:
            num1_sorted, num2_sorted = num2_sorted, num1_sorted

    data = {"sort_type": sort_type,
            "number1": number1, "number2": number2, "number3": number3,
            "num1_sorted": num1_sorted, "num2_sorted": num2_sorted, "num3_sorted": num3_sorted
            }

    return render(request, "sort.html", data)


# nod/number1/number2/
def gcd(request, number1, number2):

    result = gcd_count(number1, number2)

    data = {"gcd": result, "number1": number1, "number2": number2}

    return render(request, "gcd.html", data)


# Рекурсивный поиск наибольшего общего делителя
def gcd_count(num1, num2):

    if num1 == 0:
        return num2
    return gcd_count(num2 % num1, num1)


# region Работа со строками

# insertlast/string1/string2/string3/
def inset_last(request, string1, string2, string3):

    entry_ind = string1.rfind(string2)
    offset = entry_ind+len(string2)

    data = {"str1": string1, "str2": string2, "str3": string3}

    # Если вхождения не найдены
    if entry_ind < 0:
        data["result"] = "Не найдено вхождений string 2 в string 1!"
        return render(request, "strings/insert_last.html", data)

    # Вставка подстроки после последнего вхождения строки 2 в строку 1
    data["result"] = f"{string1[:offset]} <b class='highlight-substring'>{string3}</b>{string1[offset:]}"

    return render(request, "strings/insert_last.html", data)


# replacefirst/string1/string2/string3/
def replace_first(request, string1, string2, string3):

    entry_ind = string1.find(string2)
    offset = entry_ind+len(string2)

    data = {"str1": string1, "str2": string2, "str3": string3}

    # Если вхождения не найдены
    if entry_ind < 0:
        data["result"] = "Не найдено вхождений string 2 в string 1!"
        return render(request, "strings/replace_first.html", data)

    # Замена первого вхождения строки 2 на строку 3
    data["result"] = f"{string1[:entry_ind]}  <b class='highlight-substring'>{string3}</b>{string1[offset:]}"

    return render(request, "strings/replace_first.html", data)


# deletelast/string1/string2/
def delete_last(request, string1, string2):

    entry_ind = string1.rfind(string2)

    data = {"str1": string1, "str2": string2}

    # Если вхождения не найдены
    if entry_ind < 0:
        data["result"] = "Не найдено вхождений string 2 в string 1!"
        return render(request, "strings/delete_last.html", data)

    # Удаление последнего вхождения строки 2 в строку 1
    data["result"] = f"{string1[:entry_ind]}{string1[entry_ind + len(string2):]}"

    return render(request, "strings/delete_last.html", data)
# endregion


# employee/id/name/salary/
def employee(request, emp_id, name, salary):

    data = {"emp_id": emp_id, "emp_name": name, "emp_salary": salary, "file_path": f"images/employees/employee_{emp_id}.jpg"}

    return render(request, "employee.html", data)


# product/id/name/quantity/price/
def product(request, prod_id, prod_name, quantity, price):

    data = {"prod_id": prod_id, "prod_name": prod_name, "quantity": quantity, "price": price, "file_path": f"images/products/product_{prod_id}.jpg"}

    return render(request, "product.html", data)

