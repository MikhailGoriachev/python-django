"""
URL configuration for home_work_project project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.urls import path, include, re_path
from calc import views as calc_views

urlpatterns = [
    path('', calc_views.index),
    path('', calc_views.index),
    path('index/', calc_views.index),

    # sort/string/number1/number2/number3/ - сортировка 3-х чисел
    path('sort/<str:sort_type>/<int:number1>/<int:number2>/<int:number3>/', calc_views.sort),
    # re_path(r'sort/<str:sort_type>/(?P<number1>[-\d]+)/(?P<number2>[-\d]+)/(?P<number3>[-\d]+)', calc_views.sort),

    # nod/number1/number2/ - вычисление НОД
    path('nod/<int:number1>/<int:number2>/', calc_views.gcd),

    # insertlast/string1/string2/string3/ - вставка подстроки после последнего вхождения строки 2 в строку 1
    path('insertlast/<str:string1>/<str:string2>/<str:string3>/', calc_views.inset_last),

    # replacefirst/string1/string2/string3/ - замена первого вхождения строки 2 на строку 3
    path('replacefirst/<str:string1>/<str:string2>/<str:string3>/', calc_views.replace_first),

    # deletelast/string1/string2/ - даление последнего вхождения строки 2 в строку 1
    path('deletelast/<str:string1>/<str:string2>/', calc_views.delete_last),

    # employee/id/name/salary/ - вывод инфомрации о работнике
    path('employee/<int:emp_id>/<str:name>/<str:salary>/', calc_views.employee),

    # product/id/name/quantity/price/ - вывод инфомрации о товаре
    path('product/<int:prod_id>/<str:prod_name>/<str:quantity>/<str:price>/', calc_views.product),

    # about/ - вывода информации о разработчике
    path('about/', calc_views.about),
]
