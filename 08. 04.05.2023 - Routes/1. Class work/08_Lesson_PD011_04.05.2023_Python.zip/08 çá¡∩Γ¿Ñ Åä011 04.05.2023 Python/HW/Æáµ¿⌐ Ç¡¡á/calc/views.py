from django.shortcuts import render


# Переход по маршруту /index/
def index(request):
    return render(request, 'index.html')


# Переход по маршруту /about/
def about(request):
    return render(request, 'about.html')


# sort/string/number1/number2/number3/ – в зависимости от значения строкового параметра
# ("ascend" или "descend") сортировка трех чисел по возрастанию или по убыванию
# соответственно. Не используйте агрегатные типы данных
def sort(request, string, number1, number2, number3):
    a = number1
    b = number2
    c = number3

    if string == 'ascend':
        string = 'возрастанию'

        if a > b:
            a, b = b, a
        if a > c:
            a, c = c, a
        if b > c:
            b, c = c, b
    else:

        string = 'убыванию'
        if a < b:
            a, b = b, a
        if a < c:
            a, c = c, a
        if b < c:
            b, c = c, b

    return render(request, 'sort.html', context={
        "type": string,
        "a0": number1, "b0": number2, "c0": number3,
        "a": a, "b": b, "c": c})


# nod/number1/number2/ – вычисление наибольшего общего делителя по алгоритму Евклида (примените рекурсивную реализацию
# алгоритма, в шаблоне выведите изображение этого самого Евклида)
def nod(request, number1, number2):
    value = gcd_recursion(number1, number2)
    return render(request, 'nod.html', context={"number1": number1, "number2": number2, "nod": value})


# вычисление наибольшего общего делителя по алгоритму Евклида
def gcd_recursion(num1=100, num2=5):
    # if num1 == 0:
    #     return num2
    # return gcd_recursion(num2 % num1, num1)
    return num2 if num1 == 0 else gcd_recursion(num2 % num1, num1)



# insertlast/string1/string2/string3/ – в строку string1 вставляет подстроку string3 после
# последнего вхождения подстроки string2
def insert_last(request, string1, string2, string3):
    pos = string1.rfind(string2)

    if pos == -1:
        return render(request, 'insertlast.html',
                      context={"string1": string1, "string2": string2, "string3": string3,
                               "result": f"Подстрока '{string2}' в строке '{string1}' не найдена!"})

    sub_string1 = string1[pos:len(string1)]
    sub_string1 = sub_string1.replace(string2, f"{string2} {string3}")

    return render(request, 'insertlast.html',
                  context={"string1": string1, "string2": string2, "string3": string3,
                           "result": f"{string1[0:pos]} {sub_string1}"})


# replacefirst/string1/string2/string3/ – в строке string1 заменяет первое вхождение подстроки string2 на подстроку
# string3
def replace_first(request, string1, string2, string3):
    pos = string1.find(string2)

    if pos == -1:
        context={"string1": string1, "string2": string2, "string3": string3,
                               "result": f"Подстрока '{string2}' в строке '{string1}' не найдена!"}
    else:
        pos += len(string2)
        sub_string1 = string1[0:pos]
        sub_string1 = sub_string1.replace(string2, string3)
        context = {"string1": string1, "string2": string2, "string3": string3,
                "result": f"{sub_string1}{string1[pos:len(string1)]}"}
    return render(request, 'replacefirst.html', context=context)


# deletelast/string1/string2/ – из строки string1 удаляет последнее вхождение подстроки string2
def delete_last(request, string1, string2):
    pos = string1.rfind(string2)

    if pos == -1:
        return render(request, 'deletelast.html',
                      context={"string1": string1, "string2": string2,
                               "result": f"Подстрока '{string2}' в строке '{string1}' не найдена!"})

    sub_string1 = string1[pos:len(string1)]
    sub_string1 = sub_string1.replace(string2, "")

    return render(request, 'deletelast.html',
                  context={"string1": string1, "string2": string2,
                           "result": f"{string1[0:pos]} {sub_string1}"})


# employee/id/name/salary/ – выводит данные работника, в том числе и фото из статического файла (имя файла формируйте
# в представлении, из id)
def employee(request, id, name, salary):

    if id == 1:
        image = "employee001.jpg"
    else:
        image = "not_found.jpg"

    return render(request, 'employee.html',
                  context={"photo": f"images/{image}", "name": name, "salary": salary})


# product/id/name/quantity/price/ – выводит данные товара, в том числе и фото из статического файла
# (имя файла формируйте в представлении, из id)
def product(request, id, name, quantity, price):

    if id == 1:
        image = "kapusta.jpg"
    else:
        image = "not_found.jpg"

    return render(request, 'product.html',
                  context={"photo": f"images/{image}", "name": name, "quantity": quantity, "price": price})
