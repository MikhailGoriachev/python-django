
# from django.contrib import admin
from django.urls import path
from django.views.generic import TemplateView
from calc.views import index, about, sort, nod, insert_last, replace_first, delete_last, employee, product

urlpatterns = [
    path('', TemplateView.as_view(template_name='index.html')),
    path('index/', index),
    path('about/', about),

    # sort/string/number1/number2/number3/
    path('sort/<str:string>/<int:number1>/<int:number2>/<int:number3>/', sort),

    # nod/number1/number2/
    path('nod/', nod),
    path('nod/<int:number1>/', nod),
    path('nod/<int:number1>/<int:number2>/', nod),

    # insertlast/string1/string2/string3/
    path('insertlast/<str:string1>/<str:string2>/<str:string3>/', insert_last),

    # replacefirst/string1/string2/string3/
    path('replacefirst/<str:string1>/<str:string2>/<str:string3>/', replace_first),

    # deletelast/string1/string2/
    path('deletelast/<str:string1>/<str:string2>/', delete_last),

    # employee/id/name/salary/
    path('employee/<int:id>/<str:name>/<int:salary>/', employee),

    #product/id/name/quantity/price/
    path('product/<int:id>/<str:name>/<int:quantity>/<int:price>/', product),
]
