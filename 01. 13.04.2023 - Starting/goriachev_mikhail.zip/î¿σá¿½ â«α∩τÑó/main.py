﻿import app


def main():
    app.proc17()
    app.proc21()
    app.proc28()


if __name__ == '__main__':
    main()
